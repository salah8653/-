import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface SavedProduct {
  id: number;
  name: string;
  price: number;
  imageUrl?: string;
  description?: string;
}

interface SavedProductsContextType {
  savedProducts: SavedProduct[];
  addToSaved: (product: any) => void;
  removeFromSaved: (productId: number) => void;
  isSaved: (productId: number) => boolean;
  clearSaved: () => void;
}

const SavedProductsContext = createContext<SavedProductsContextType | undefined>(undefined);

export const SavedProductsProvider = ({ children }: { children: ReactNode }) => {
  const [savedProducts, setSavedProducts] = useState<SavedProduct[]>([]);

  // تحميل المحفوظات من localStorage عند البداية
  useEffect(() => {
    const saved = localStorage.getItem('savedProducts');
    if (saved) {
      setSavedProducts(JSON.parse(saved));
    }
  }, []);

  // حفظ المحفوظات في localStorage عند التغيير
  useEffect(() => {
    localStorage.setItem('savedProducts', JSON.stringify(savedProducts));
  }, [savedProducts]);

  const addToSaved = (product: any) => {
    setSavedProducts(prev => {
      const isAlreadySaved = prev.some(p => p.id === product.id);
      if (!isAlreadySaved) {
        return [...prev, {
          id: product.id,
          name: product.name,
          price: product.price,
          imageUrl: product.imageUrl,
          description: product.description
        }];
      }
      return prev;
    });
  };

  const removeFromSaved = (productId: number) => {
    setSavedProducts(prev => prev.filter(p => p.id !== productId));
  };

  const isSaved = (productId: number) => {
    return savedProducts.some(p => p.id === productId);
  };

  const clearSaved = () => {
    setSavedProducts([]);
  };

  return (
    <SavedProductsContext.Provider value={{
      savedProducts,
      addToSaved,
      removeFromSaved,
      isSaved,
      clearSaved
    }}>
      {children}
    </SavedProductsContext.Provider>
  );
};

export const useSavedProducts = () => {
  const context = useContext(SavedProductsContext);
  if (context === undefined) {
    throw new Error('useSavedProducts must be used within a SavedProductsProvider');
  }
  return context;
};