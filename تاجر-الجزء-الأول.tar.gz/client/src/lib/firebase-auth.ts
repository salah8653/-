import { initializeApp } from 'firebase/app';
import { 
  getAuth, 
  RecaptchaVerifier, 
  signInWithPhoneNumber,
  ConfirmationResult 
} from 'firebase/auth';

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: `${import.meta.env.VITE_FIREBASE_PROJECT_ID}.firebaseapp.com`,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: `${import.meta.env.VITE_FIREBASE_PROJECT_ID}.firebasestorage.app`,
  messagingSenderId: "123456789",
  appId: import.meta.env.VITE_FIREBASE_APP_ID
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// تكوين reCAPTCHA
let recaptchaVerifier: RecaptchaVerifier | null = null;

export const initializeRecaptcha = (): RecaptchaVerifier => {
  if (!recaptchaVerifier) {
    try {
      // التأكد من وجود العنصر في DOM قبل تهيئة reCAPTCHA
      const container = document.getElementById('recaptcha-container');
      if (!container) {
        throw new Error('reCAPTCHA container not found');
      }
      
      recaptchaVerifier = new RecaptchaVerifier(auth, 'recaptcha-container', {
        size: 'invisible',
        callback: () => {
          console.log('reCAPTCHA resolved');
        },
        'expired-callback': () => {
          console.log('reCAPTCHA expired');
          recaptchaVerifier = null; // إعادة تعيين للمحاولة مرة أخرى
        }
      });
    } catch (error) {
      console.error('خطأ في تهيئة reCAPTCHA:', error);
      throw error;
    }
  }
  return recaptchaVerifier;
};

export const sendSMSVerification = async (phoneNumber: string): Promise<ConfirmationResult> => {
  const appVerifier = initializeRecaptcha();
  
  // تنسيق رقم الهاتف (إضافة رمز الدولة إذا لم يكن موجوداً)
  const formattedPhone = phoneNumber.startsWith('+') ? phoneNumber : `+964${phoneNumber.slice(1)}`;
  
  try {
    const confirmationResult = await signInWithPhoneNumber(auth, formattedPhone, appVerifier);
    console.log('تم إرسال رمز التحقق بنجاح');
    return confirmationResult;
  } catch (error: any) {
    console.error('خطأ في إرسال رمز التحقق:', error);
    throw error;
  }
};

export const verifyPhoneCode = async (
  confirmationResult: ConfirmationResult, 
  code: string
): Promise<boolean> => {
  try {
    await confirmationResult.confirm(code);
    console.log('تم التحقق من الرمز بنجاح');
    return true;
  } catch (error: any) {
    console.error('خطأ في التحقق من الرمز:', error);
    return false;
  }
};

export { auth };