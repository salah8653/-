import React, { createContext, useContext, useState, useEffect } from 'react';

type Language = 'ar' | 'en';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  dir: 'rtl' | 'ltr';
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

// Translation dictionaries
const translations = {
  ar: {
    // Navigation and General
    'ecommerce.platform': 'منصة التجارة الإلكترونية',
    'home': 'الرئيسية',
    'products': 'المنتجات',
    'orders': 'الطلبات',
    'customers': 'العملاء',
    'categories': 'الفئات',
    'profile': 'الملف الشخصي',
    'settings': 'الإعدادات',
    'logout': 'تسجيل الخروج',
    'login': 'تسجيل الدخول',
    'register': 'إنشاء حساب',
    'search': 'البحث',
    'filter': 'التصفية',
    'sort': 'الترتيب',
    'add': 'إضافة',
    'edit': 'تعديل',
    'delete': 'حذف',
    'save': 'حفظ',
    'cancel': 'إلغاء',
    'confirm': 'تأكيد',
    'back': 'رجوع',
    'next': 'التالي',
    'previous': 'السابق',
    'loading': 'جارٍ التحميل...',
    'error': 'خطأ',
    'success': 'نجح',
    'warning': 'تحذير',
    'info': 'معلومة',
    
    // Authentication
    'auth.welcome': 'مرحباً بك',
    'auth.email': 'البريد الإلكتروني',
    'auth.password': 'كلمة المرور',
    'auth.confirm.password': 'تأكيد كلمة المرور',
    'auth.username': 'اسم المستخدم',
    'auth.forgot.password': 'نسيت كلمة المرور؟',
    'auth.no.account': 'ليس لديك حساب؟',
    'auth.have.account': 'لديك حساب بالفعل؟',
    'auth.login.here': 'سجل دخولك هنا',
    'auth.register.here': 'أنشئ حساباً هنا',
    
    // Products
    'products.title': 'المنتجات',
    'products.add': 'إضافة منتج',
    'products.edit': 'تعديل المنتج',
    'products.name': 'اسم المنتج',
    'products.description': 'الوصف',
    'products.price': 'السعر',
    'products.stock': 'المخزون',
    'products.category': 'الفئة',
    'products.image': 'الصورة',
    'products.status': 'الحالة',
    'products.active': 'نشط',
    'products.inactive': 'غير نشط',
    'products.out.of.stock': 'نفد المخزون',
    'products.in.stock': 'متوفر',
    'products.low.stock': 'مخزون منخفض',
    
    // Orders
    'orders.title': 'الطلبات',
    'orders.new': 'طلب جديد',
    'orders.id': 'رقم الطلب',
    'orders.customer': 'العميل',
    'orders.total': 'المجموع',
    'orders.status': 'الحالة',
    'orders.date': 'التاريخ',
    'orders.pending': 'معلق',
    'orders.processing': 'قيد المعالجة',
    'orders.completed': 'مكتمل',
    'orders.cancelled': 'ملغى',
    'orders.delivered': 'تم التوصيل',
    'orders.shipped': 'تم الشحن',
    'orders.delivery.status': 'حالة التوصيل',
    'orders.payment.status': 'حالة الدفع',
    'orders.paid': 'مدفوع',
    'orders.unpaid': 'غير مدفوع',
    
    // Customers
    'customers.title': 'العملاء',
    'customers.name': 'الاسم',
    'customers.email': 'البريد الإلكتروني',
    'customers.phone': 'الهاتف',
    'customers.address': 'العنوان',
    'customers.orders.count': 'عدد الطلبات',
    'customers.total.spent': 'إجمالي المبلغ المدفوع',
    
    // Categories
    'categories.title': 'الفئات',
    'categories.add': 'إضافة فئة',
    'categories.name': 'اسم الفئة',
    'categories.description': 'الوصف',
    'categories.products.count': 'عدد المنتجات',
    
    // AI Assistant
    'ai.assistant': 'المساعد الذكي',
    'ai.ecommerce.assistant': 'المساعد الذكي للتجارة الإلكترونية',
    'ai.ask.question': 'اطرح سؤالك هنا...',
    'ai.send': 'إرسال',
    'ai.thinking': 'جارٍ التفكير...',
    'ai.business.analysis': 'تحليل الأعمال',
    'ai.performance.analysis': 'تحليل الأداء',
    'ai.winning.products': 'المنتجات الرابحة',
    'ai.marketing.tips': 'نصائح التسويق',
    'ai.customer.service': 'خدمة العملاء',
    
    // Settings
    'settings.title': 'الإعدادات',
    'settings.language': 'اللغة',
    'settings.arabic': 'العربية',
    'settings.english': 'الإنجليزية',
    'settings.theme': 'المظهر',
    'settings.light': 'فاتح',
    'settings.dark': 'داكن',
    'settings.notifications': 'الإشعارات',
    'settings.email.notifications': 'إشعارات البريد الإلكتروني',
    'settings.push.notifications': 'الإشعارات المنبثقة',
    
    // Dashboard
    'dashboard.title': 'لوحة التحكم',
    'dashboard.total.orders': 'إجمالي الطلبات',
    'dashboard.total.customers': 'إجمالي العملاء',
    'dashboard.total.products': 'إجمالي المنتجات',
    'dashboard.total.revenue': 'إجمالي الإيرادات',
    'dashboard.recent.orders': 'الطلبات الحديثة',
    'dashboard.top.products': 'أفضل المنتجات',
    'dashboard.analytics': 'التحليلات',
    
    // Business Analysis
    'analysis.business.health': 'صحة الأعمال',
    'analysis.user.engagement': 'تفاعل المستخدمين',
    'analysis.revenue.analysis': 'تحليل الإيرادات',
    'analysis.order.analysis': 'تحليل الطلبات',
    'analysis.delivery.analysis': 'تحليل التوصيل',
    'analysis.profit.analysis': 'تحليل الأرباح',
    'analysis.strategic.recommendations': 'التوصيات الاستراتيجية',
    'analysis.risk.assessment': 'تقييم المخاطر',
    
    // Common Messages
    'messages.no.data': 'لا توجد بيانات',
    'messages.loading.data': 'جارٍ تحميل البيانات...',
    'messages.error.loading': 'خطأ في تحميل البيانات',
    'messages.success.save': 'تم الحفظ بنجاح',
    'messages.success.delete': 'تم الحذف بنجاح',
    'messages.confirm.delete': 'هل أنت متأكد من الحذف؟',
    'messages.operation.failed': 'فشلت العملية',
    
    // Forms
    'form.required': 'مطلوب',
    'form.invalid.email': 'بريد إلكتروني غير صالح',
    'form.password.too.short': 'كلمة المرور قصيرة جداً',
    'form.passwords.dont.match': 'كلمات المرور غير متطابقة',
    'form.select.option': 'اختر خياراً',
    
    // Currency
    'currency.dinar': 'دينار',
    'currency.symbol': 'د.ك'
  },
  
  en: {
    // Navigation and General
    'ecommerce.platform': 'E-Commerce Platform',
    'home': 'Home',
    'products': 'Products',
    'orders': 'Orders',
    'customers': 'Customers',
    'categories': 'Categories',
    'profile': 'Profile',
    'settings': 'Settings',
    'logout': 'Logout',
    'login': 'Login',
    'register': 'Register',
    'search': 'Search',
    'filter': 'Filter',
    'sort': 'Sort',
    'add': 'Add',
    'edit': 'Edit',
    'delete': 'Delete',
    'save': 'Save',
    'cancel': 'Cancel',
    'confirm': 'Confirm',
    'back': 'Back',
    'next': 'Next',
    'previous': 'Previous',
    'loading': 'Loading...',
    'error': 'Error',
    'success': 'Success',
    'warning': 'Warning',
    'info': 'Info',
    
    // Authentication
    'auth.welcome': 'Welcome',
    'auth.email': 'Email',
    'auth.password': 'Password',
    'auth.confirm.password': 'Confirm Password',
    'auth.username': 'Username',
    'auth.forgot.password': 'Forgot Password?',
    'auth.no.account': "Don't have an account?",
    'auth.have.account': 'Already have an account?',
    'auth.login.here': 'Login here',
    'auth.register.here': 'Register here',
    
    // Products
    'products.title': 'Products',
    'products.add': 'Add Product',
    'products.edit': 'Edit Product',
    'products.name': 'Product Name',
    'products.description': 'Description',
    'products.price': 'Price',
    'products.stock': 'Stock',
    'products.category': 'Category',
    'products.image': 'Image',
    'products.status': 'Status',
    'products.active': 'Active',
    'products.inactive': 'Inactive',
    'products.out.of.stock': 'Out of Stock',
    'products.in.stock': 'In Stock',
    'products.low.stock': 'Low Stock',
    
    // Orders
    'orders.title': 'Orders',
    'orders.new': 'New Order',
    'orders.id': 'Order ID',
    'orders.customer': 'Customer',
    'orders.total': 'Total',
    'orders.status': 'Status',
    'orders.date': 'Date',
    'orders.pending': 'Pending',
    'orders.processing': 'Processing',
    'orders.completed': 'Completed',
    'orders.cancelled': 'Cancelled',
    'orders.delivered': 'Delivered',
    'orders.shipped': 'Shipped',
    'orders.delivery.status': 'Delivery Status',
    'orders.payment.status': 'Payment Status',
    'orders.paid': 'Paid',
    'orders.unpaid': 'Unpaid',
    
    // Customers
    'customers.title': 'Customers',
    'customers.name': 'Name',
    'customers.email': 'Email',
    'customers.phone': 'Phone',
    'customers.address': 'Address',
    'customers.orders.count': 'Orders Count',
    'customers.total.spent': 'Total Spent',
    
    // Categories
    'categories.title': 'Categories',
    'categories.add': 'Add Category',
    'categories.name': 'Category Name',
    'categories.description': 'Description',
    'categories.products.count': 'Products Count',
    
    // AI Assistant
    'ai.assistant': 'AI Assistant',
    'ai.ecommerce.assistant': 'E-Commerce AI Assistant',
    'ai.ask.question': 'Ask your question here...',
    'ai.send': 'Send',
    'ai.thinking': 'Thinking...',
    'ai.business.analysis': 'Business Analysis',
    'ai.performance.analysis': 'Performance Analysis',
    'ai.winning.products': 'Winning Products',
    'ai.marketing.tips': 'Marketing Tips',
    'ai.customer.service': 'Customer Service',
    
    // Settings
    'settings.title': 'Settings',
    'settings.language': 'Language',
    'settings.arabic': 'Arabic',
    'settings.english': 'English',
    'settings.theme': 'Theme',
    'settings.light': 'Light',
    'settings.dark': 'Dark',
    'settings.notifications': 'Notifications',
    'settings.email.notifications': 'Email Notifications',
    'settings.push.notifications': 'Push Notifications',
    
    // Dashboard
    'dashboard.title': 'Dashboard',
    'dashboard.total.orders': 'Total Orders',
    'dashboard.total.customers': 'Total Customers',
    'dashboard.total.products': 'Total Products',
    'dashboard.total.revenue': 'Total Revenue',
    'dashboard.recent.orders': 'Recent Orders',
    'dashboard.top.products': 'Top Products',
    'dashboard.analytics': 'Analytics',
    
    // Business Analysis
    'analysis.business.health': 'Business Health',
    'analysis.user.engagement': 'User Engagement',
    'analysis.revenue.analysis': 'Revenue Analysis',
    'analysis.order.analysis': 'Order Analysis',
    'analysis.delivery.analysis': 'Delivery Analysis',
    'analysis.profit.analysis': 'Profit Analysis',
    'analysis.strategic.recommendations': 'Strategic Recommendations',
    'analysis.risk.assessment': 'Risk Assessment',
    
    // Common Messages
    'messages.no.data': 'No data available',
    'messages.loading.data': 'Loading data...',
    'messages.error.loading': 'Error loading data',
    'messages.success.save': 'Successfully saved',
    'messages.success.delete': 'Successfully deleted',
    'messages.confirm.delete': 'Are you sure you want to delete?',
    'messages.operation.failed': 'Operation failed',
    
    // Forms
    'form.required': 'Required',
    'form.invalid.email': 'Invalid email',
    'form.password.too.short': 'Password too short',
    'form.passwords.dont.match': 'Passwords do not match',
    'form.select.option': 'Select an option',
    
    // Currency
    'currency.dinar': 'Dinar',
    'currency.symbol': 'KD'
  }
};

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem('language');
    return (saved as Language) || 'ar';
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('language', lang);
    document.documentElement.setAttribute('lang', lang);
    document.documentElement.setAttribute('dir', lang === 'ar' ? 'rtl' : 'ltr');
    document.documentElement.classList.toggle('rtl', lang === 'ar');
    document.documentElement.classList.toggle('ltr', lang === 'en');
    
    // إعادة تحميل الصفحة لضمان تطبيق التغييرات على كامل التطبيق
    setTimeout(() => {
      window.location.reload();
    }, 100);
  };

  const t = (key: string): string => {
    return (translations[language] as Record<string, string>)[key] || key;
  };

  useEffect(() => {
    document.documentElement.setAttribute('lang', language);
    document.documentElement.setAttribute('dir', language === 'ar' ? 'rtl' : 'ltr');
    document.documentElement.classList.toggle('rtl', language === 'ar');
    document.documentElement.classList.toggle('ltr', language === 'en');
  }, [language]);

  const value: LanguageContextType = {
    language,
    setLanguage,
    t,
    dir: language === 'ar' ? 'rtl' : 'ltr'
  };

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};