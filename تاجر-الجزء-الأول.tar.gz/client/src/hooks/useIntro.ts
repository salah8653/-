import { useState, useEffect } from 'react';

export function useIntro() {
  const [showIntro, setShowIntro] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // إظهار الانترو في كل دخول للتطبيق
    const appEntryTime = sessionStorage.getItem('appEntryTime');
    
    if (!appEntryTime) {
      // أول دخول في هذه الجلسة
      sessionStorage.setItem('appEntryTime', Date.now().toString());
      setShowIntro(true);
    }
    
    setIsLoading(false);
  }, []);

  const completeIntro = () => {
    setShowIntro(false);
  };

  const resetIntro = () => {
    // حذف وقت الدخول لإجبار الانترو على الظهور
    sessionStorage.removeItem('appEntryTime');
    setShowIntro(true);
  };

  return {
    showIntro,
    isLoading,
    completeIntro,
    resetIntro
  };
}