import { useState, useEffect } from 'react';

interface User {
  id: number;
  username: string;
  role: string;
  email?: string;
  fullName?: string;
  phone?: string;
  address?: string;
  profileImage?: string;
  isBanned?: boolean;
  banExpiresAt?: string;
  banReason?: string;
}

export const useAuth = () => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const checkUserStatus = async () => {
      // Check if user is stored in localStorage
      const storedUser = localStorage.getItem('user');
      if (storedUser) {
        try {
          const parsedUser = JSON.parse(storedUser);
          console.log('تم تسجيل الدخول التلقائي للمستخدم:', parsedUser.phone);
          
          // التحقق من حالة المستخدم الحالية في الخادم
          try {
            const response = await fetch(`/api/users/${parsedUser.id}`);
            if (response.ok) {
              const currentUserData = await response.json();
              
              // إذا كان المستخدم محظور، قم بتسجيل الخروج وتوجيهه لصفحة الحظر
              if (currentUserData.status === 'banned') {
                console.log('المستخدم محظور، تسجيل خروج تلقائي');
                localStorage.removeItem('user');
                setUser(null);
                window.location.href = '/banned';
                return;
              }
              
              // تحديث البيانات المحلية بالبيانات الحديثة
              setUser(currentUserData);
              localStorage.setItem('user', JSON.stringify(currentUserData));
            } else {
              // إذا فشل جلب البيانات، احذف البيانات المحلية الخاطئة
              console.log('المستخدم غير موجود، حذف البيانات المحلية');
              localStorage.removeItem('user');
              setUser(null);
            }
          } catch (error) {
            console.error('خطأ في التحقق من حالة المستخدم:', error);
            // في حالة عدم وجود اتصال، استخدم البيانات المحفوظة
            setUser(parsedUser);
          }
        } catch (error) {
          console.log('خطأ في تحليل بيانات المستخدم المحفوظة');
          localStorage.removeItem('user');
        }
      }
      setIsLoading(false);
    };

    checkUserStatus();

    // نظام تسجيل الخروج التلقائي للمدير (معطل)
    const handleVisibilityChange = () => {
      // تم تعطيل النظام بناءً على طلب المستخدم
    };

    // مراقبة تغيير المسار
    const handlePopState = () => {
      setTimeout(handleVisibilityChange, 100);
    };

    // معطل مؤقتاً - مراقبة فقدان التركيز 
    const handleBlur = () => {
      // معطل مؤقتاً
    };

    // معطل مؤقتاً - مراقبة استعادة التركيز
    const handleFocus = () => {
      // معطل مؤقتاً
    };

    // إضافة المستمعات
    window.addEventListener('popstate', handlePopState);
    window.addEventListener('blur', handleBlur);
    window.addEventListener('focus', handleFocus);
    document.addEventListener('visibilitychange', handleVisibilityChange);

    // تنظيف المستمعات
    return () => {
      window.removeEventListener('popstate', handlePopState);
      window.removeEventListener('blur', handleBlur);
      window.removeEventListener('focus', handleFocus);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, []);

  const login = async (phoneOrEmail: string, password: string) => {
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ phoneOrEmail, password }),
    });

    if (!response.ok) {
      const error = await response.json();
      
      // إذا كان المستخدم محظور، أرفق معلومات الحظر للخطأ
      if (response.status === 403 && error.banned) {
        const banError = new Error(error.message || 'تم حظر الحساب');
        (banError as any).status = 403;
        (banError as any).banned = true;
        (banError as any).redirectTo = error.redirectTo;
        throw banError;
      }
      
      throw new Error(error.message);
    }

    const { user } = await response.json();
    setUser(user);
    localStorage.setItem('user', JSON.stringify(user));
    return { user };
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
    // إعادة التوجيه لصفحة تسجيل الدخول دون مسح البيانات الأخرى
    window.location.href = '/login';
  };

  const updateUser = (updatedUserData: Partial<User>) => {
    if (user) {
      const updatedUser = { ...user, ...updatedUserData };
      setUser(updatedUser);
      localStorage.setItem('user', JSON.stringify(updatedUser));
      console.log('تم تحديث بيانات المستخدم محلياً:', updatedUser);
    }
  };

  return {
    user,
    isLoading,
    login,
    logout,
    updateUser,
    isAuthenticated: !!user,
  };
};
