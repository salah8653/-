import { createContext, useContext, useState, useEffect, ReactNode } from "react";

interface CartItem {
  id: number;
  productId: number;
  quantity: number;
  product: {
    id: number;
    name: string;
    price: string;
    imageUrl?: string;
  };
}

interface CartContextType {
  items: CartItem[];
  addItem: (product: any, quantity: number) => void;
  removeItem: (id: number) => void;
  updateQuantity: (id: number, quantity: number) => void;
  clearCart: () => void;
  getTotalItems: () => number;
  getTotalPrice: () => number;
  refreshCart: () => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider = ({ children }: { children: ReactNode }) => {
  const [items, setItems] = useState<CartItem[]>([]);

  // جلب السلة من Firebase عند التحميل
  useEffect(() => {
    refreshCart();
  }, []);

  const refreshCart = async () => {
    try {
      const response = await fetch('/api/cart');
      if (response.ok) {
        const data = await response.json();
        setItems(data);
      }
    } catch (error) {
      console.error('خطأ في جلب السلة:', error);
    }
  };

  const addItem = async (product: any, quantity: number) => {
    try {
      const response = await fetch('/api/cart', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          productId: product.id,
          quantity
        })
      });

      if (response.ok) {
        // تحديث السلة محلياً
        setItems(prev => {
          const existingItem = prev.find(item => item.productId === product.id);
          
          if (existingItem) {
            return prev.map(item =>
              item.productId === product.id
                ? { ...item, quantity: item.quantity + quantity }
                : item
            );
          }
          
          return [...prev, {
            id: Date.now(),
            productId: product.id,
            quantity,
            product: {
              id: product.id,
              name: product.name,
              price: product.price,
              imageUrl: product.imageUrl
            }
          }];
        });
      }
    } catch (error) {
      console.error('خطأ في إضافة المنتج للسلة:', error);
    }
  };

  const removeItem = async (productId: number) => {
    try {
      const response = await fetch(`/api/cart/${productId}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        setItems(prev => prev.filter(item => item.productId !== productId));
      }
    } catch (error) {
      console.error('خطأ في حذف المنتج من السلة:', error);
    }
  };

  const updateQuantity = async (productId: number, quantity: number) => {
    if (quantity <= 0) {
      removeItem(productId);
      return;
    }

    try {
      const response = await fetch(`/api/cart/${productId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ quantity })
      });

      if (response.ok) {
        setItems(prev =>
          prev.map(item =>
            item.productId === productId ? { ...item, quantity } : item
          )
        );
      }
    } catch (error) {
      console.error('خطأ في تحديث الكمية:', error);
    }
  };

  const clearCart = async () => {
    try {
      const response = await fetch('/api/cart', {
        method: 'DELETE'
      });
      if (response.ok) {
        setItems([]);
      }
    } catch (error) {
      console.error('خطأ في إفراغ السلة:', error);
      setItems([]); // إفراغ محلي في حالة فشل الطلب
    }
  };

  const getTotalItems = () => {
    return items.reduce((total, item) => total + item.quantity, 0);
  };

  const getTotalPrice = () => {
    return items.reduce((total, item) => total + (parseFloat(item.product.price) * item.quantity), 0);
  };

  return (
    <CartContext.Provider value={{
      items,
      addItem,
      removeItem,
      updateQuantity,
      clearCart,
      getTotalItems,
      getTotalPrice,
      refreshCart
    }}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error("useCart must be used within CartProvider");
  }
  return context;
};