import { useState, useEffect } from 'react';

export const useNetwork = () => {
  const [isOnline, setIsOnline] = useState(true); // افتراض الاتصال متوفر في البداية
  const [wasOffline, setWasOffline] = useState(false);
  const [showOfflineMessage, setShowOfflineMessage] = useState(false);

  useEffect(() => {
    // تأخير لمنع ظهور رسالة الانقطاع عند تحميل الصفحة
    let initialLoadTimeout: NodeJS.Timeout;
    
    const handleOnline = () => {
      setIsOnline(true);
      setShowOfflineMessage(false);
      if (wasOffline) {
        // إعادة تحميل الصفحة عند العودة للاتصال
        setTimeout(() => {
          window.location.reload();
        }, 1000);
      }
    };

    const handleOffline = () => {
      setIsOnline(false);
      setWasOffline(true);
      // تأخير لتجنب إظهار الرسالة عند تغيير الصفحات
      setTimeout(() => {
        if (!navigator.onLine) {
          setShowOfflineMessage(true);
        }
      }, 3000);
    };

    // فحص الاتصال بعد تحميل الصفحة بـ 5 ثوان
    initialLoadTimeout = setTimeout(async () => {
      try {
        const response = await fetch('/api/health', {
          method: 'HEAD',
          cache: 'no-cache',
          signal: AbortSignal.timeout(5000)
        });
        
        if (!response.ok) {
          throw new Error('Server unreachable');
        }
      } catch (error) {
        console.log('Initial connection check failed, but not showing message during load');
        // لا نظهر رسالة خطأ عند التحميل الأولي
      }
    }, 5000);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // فحص دوري للاتصال (كل 30 ثانية بدلاً من 10)
    const checkConnection = async () => {
      // تجاهل الفحص إذا كان المتصفح يشير لوجود اتصال
      if (!navigator.onLine) {
        setIsOnline(false);
        setShowOfflineMessage(true);
        return;
      }

      try {
        const response = await fetch('/api/health', {
          method: 'HEAD',
          cache: 'no-cache',
          signal: AbortSignal.timeout(8000)
        });
        
        const newStatus = response.ok;
        if (newStatus !== isOnline) {
          setIsOnline(newStatus);
          if (!newStatus) {
            setWasOffline(true);
            setShowOfflineMessage(true);
          } else {
            setShowOfflineMessage(false);
          }
        }
      } catch (error) {
        // فقط إظهار رسالة الخطأ إذا كان الاتصال متاحاً حسب المتصفح
        if (isOnline && navigator.onLine) {
          console.log('Connection check failed:', error);
          setIsOnline(false);
          setWasOffline(true);
          setShowOfflineMessage(true);
        }
      }
    };

    const interval = setInterval(checkConnection, 30000);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(interval);
      clearTimeout(initialLoadTimeout);
    };
  }, [isOnline, wasOffline]);

  return { isOnline: isOnline && !showOfflineMessage ? true : false, showOfflineMessage };
};