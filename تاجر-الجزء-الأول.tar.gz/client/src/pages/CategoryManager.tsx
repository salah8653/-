import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import { ArrowLeft, Plus, Edit, Trash2 } from "lucide-react";

interface Category {
  id: number;
  name: string;
  description?: string;
  createdAt: string;
}

export default function CategoryManager() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [formData, setFormData] = useState({
    name: '',
    description: ''
  });

  // جلب الفئات الحالية
  const { data: categories, isLoading } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  // إضافة فئة جديدة
  const createCategoryMutation = useMutation({
    mutationFn: async (data: { name: string; description?: string }) => {
      const response = await fetch('/api/categories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!response.ok) throw new Error('فشل في إضافة الفئة');
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم الإنشاء! ✅",
        description: "تم إضافة الفئة بنجاح",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/categories'] });
      setFormData({ name: '', description: '' });
    },
    onError: () => {
      toast({
        title: "خطأ في الإضافة ❌",
        description: "حاول مرة أخرى",
        variant: "destructive",
      });
    }
  });

  // حذف فئة
  const deleteCategoryMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/categories/${id}`, {
        method: 'DELETE'
      });
      if (!response.ok) throw new Error('فشل في حذف الفئة');
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم الحذف! ✅",
        description: "تم حذف الفئة بنجاح",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/categories'] });
    },
    onError: () => {
      toast({
        title: "خطأ في الحذف ❌",
        description: "حاول مرة أخرى",
        variant: "destructive",
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      toast({
        title: "بيانات ناقصة",
        description: "يرجى إدخال اسم الفئة",
        variant: "destructive",
      });
      return;
    }
    
    createCategoryMutation.mutate({
      name: formData.name.trim(),
      description: formData.description.trim() || undefined
    });
  };

  const handleDelete = (id: number, name: string) => {
    if (confirm(`هل أنت متأكد من حذف فئة "${name}"؟`)) {
      deleteCategoryMutation.mutate(id);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <Link href="/products">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 ml-2" />
                العودة للمنتجات
              </Button>
            </Link>
            <h1 className="text-2xl font-bold text-gray-900">إدارة الفئات</h1>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* نموذج إضافة فئة جديدة */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="w-5 h-5" />
                إضافة فئة جديدة
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">اسم الفئة *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="أدخل اسم الفئة"
                    className="text-right"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">الوصف (اختياري)</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="أدخل وصف الفئة"
                    className="text-right"
                    rows={3}
                  />
                </div>

                <Button 
                  type="submit" 
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  disabled={createCategoryMutation.isPending}
                >
                  {createCategoryMutation.isPending ? 'جاري الإضافة...' : 'إضافة الفئة'}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* قائمة الفئات الحالية */}
          <Card>
            <CardHeader>
              <CardTitle>الفئات الحالية ({categories?.length || 0})</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="text-center py-4">
                  <div className="animate-spin w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full mx-auto"></div>
                  <p className="mt-2 text-gray-600">جاري تحميل الفئات...</p>
                </div>
              ) : !categories || categories.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <p>لا توجد فئات حتى الآن</p>
                  <p className="text-sm">ابدأ بإضافة فئة جديدة</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {categories.map((category) => (
                    <div 
                      key={category.id}
                      className="border border-gray-200 rounded-lg p-3 bg-white"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-900">{category.name}</h3>
                          {category.description && (
                            <p className="text-sm text-gray-600 mt-1">{category.description}</p>
                          )}
                        </div>
                        <div className="flex gap-2">
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleDelete(category.id, category.name)}
                            disabled={deleteCategoryMutation.isPending}
                            className="text-red-600 hover:text-red-700 hover:bg-red-50"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}