import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { 
  Plus, 
  Edit2, 
  Trash2, 
  Image as ImageIcon, 
  Upload,
  Eye,
  EyeOff,
  Smartphone,
  Monitor
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Banner {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  isActive: boolean;
  createdAt: string;
  updatedAt?: string;
}

export const BannerManagement = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingBanner, setEditingBanner] = useState<Banner | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');

  // Form states
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [isActive, setIsActive] = useState(true);

  const { data: banners = [], isLoading } = useQuery({
    queryKey: ['/api/banners'],
    queryFn: () => fetch('/api/banners').then(res => res.json())
  });

  const createBannerMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await fetch('/api/banners', {
        method: 'POST',
        body: formData,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/banners'] });
      toast({
        title: "تم إنشاء البانر",
        description: "تم إضافة البانر الجديد بنجاح",
      });
      resetForm();
      setIsAddDialogOpen(false);
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "حدث خطأ أثناء إنشاء البانر",
        variant: "destructive",
      });
    },
  });

  const updateBannerMutation = useMutation({
    mutationFn: async ({ id, formData }: { id: string; formData: FormData }) => {
      const response = await fetch(`/api/banners/${id}`, {
        method: 'PUT',
        body: formData,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/banners'] });
      toast({
        title: "تم تحديث البانر",
        description: "تم تحديث البانر بنجاح",
      });
      resetForm();
      setIsEditDialogOpen(false);
      setEditingBanner(null);
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "حدث خطأ أثناء تحديث البانر",
        variant: "destructive",
      });
    },
  });

  const toggleBannerMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: string; isActive: boolean }) => {
      const response = await fetch(`/api/banners/${id}/toggle`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ isActive }),
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/banners'] });
      toast({
        title: "تم تحديث الحالة",
        description: "تم تحديث حالة البانر بنجاح",
      });
    },
  });

  const deleteBannerMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await fetch(`/api/banners/${id}`, {
        method: 'DELETE',
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/banners'] });
      toast({
        title: "تم حذف البانر",
        description: "تم حذف البانر بنجاح",
      });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "حدث خطأ أثناء حذف البانر",
        variant: "destructive",
      });
    },
  });

  const handleImageSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedImage(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        setImagePreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const resetForm = () => {
    setTitle('');
    setDescription('');
    setIsActive(true);
    setSelectedImage(null);
    setImagePreview('');
  };

  const handleSubmit = () => {
    if (!title.trim()) {
      toast({
        title: "خطأ",
        description: "يرجى إدخال عنوان البانر",
        variant: "destructive",
      });
      return;
    }

    const formData = new FormData();
    formData.append('title', title);
    formData.append('description', description);
    formData.append('isActive', isActive.toString());
    
    if (selectedImage) {
      formData.append('image', selectedImage);
    }

    if (editingBanner) {
      updateBannerMutation.mutate({ id: editingBanner.id, formData });
    } else {
      createBannerMutation.mutate(formData);
    }
  };

  const handleEdit = (banner: Banner) => {
    setEditingBanner(banner);
    setTitle(banner.title);
    setDescription(banner.description);
    setIsActive(banner.isActive);
    setImagePreview(banner.imageUrl);
    setIsEditDialogOpen(true);
  };

  const handleToggle = (banner: Banner) => {
    toggleBannerMutation.mutate({ id: banner.id, isActive: !banner.isActive });
  };

  const handleDelete = (id: string) => {
    if (window.confirm('هل أنت متأكد من حذف هذا البانر؟')) {
      deleteBannerMutation.mutate(id);
    }
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-4 lg:p-6">
        <div className="text-center py-8">جاري التحميل...</div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 lg:p-6 space-y-6">
      {/* Header - Responsive */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">إدارة البانرات</h1>
          <p className="text-gray-600 mt-1">إدارة البانرات الترويجية في التطبيق</p>
        </div>
        
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button 
              className="bg-purple-600 hover:bg-purple-700 w-full sm:w-auto"
              onClick={resetForm}
            >
              <Plus className="w-4 h-4 ml-2" />
              إضافة بانر جديد
            </Button>
          </DialogTrigger>
        </Dialog>
      </div>

      {/* Stats Cards - Responsive Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">إجمالي البانرات</p>
                <p className="text-2xl font-bold text-purple-600">{banners.length}</p>
              </div>
              <ImageIcon className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">البانرات النشطة</p>
                <p className="text-2xl font-bold text-green-600">
                  {banners.filter((b: Banner) => b.isActive).length}
                </p>
              </div>
              <Eye className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">البانرات المخفية</p>
                <p className="text-2xl font-bold text-red-600">
                  {banners.filter((b: Banner) => !b.isActive).length}
                </p>
              </div>
              <EyeOff className="w-8 h-8 text-red-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">نوع العرض</p>
                <div className="flex items-center gap-2 mt-1">
                  <Monitor className="w-4 h-4 text-blue-600" />
                  <Smartphone className="w-4 h-4 text-blue-600" />
                </div>
              </div>
              <div className="text-xs text-gray-500">متجاوب</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Banners List - Responsive */}
      <div className="space-y-4">
        {banners.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <ImageIcon className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 mb-4">لا توجد بانرات</p>
              <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                <DialogTrigger asChild>
                  <Button 
                    className="bg-purple-600 hover:bg-purple-700"
                    onClick={resetForm}
                  >
                    <Plus className="w-4 h-4 ml-2" />
                    إضافة أول بانر
                  </Button>
                </DialogTrigger>
              </Dialog>
            </CardContent>
          </Card>
        ) : (
          banners.map((banner: Banner) => (
            <Card key={banner.id} className="overflow-hidden">
              <CardContent className="p-0">
                <div className="flex flex-col lg:flex-row">
                  {/* Image Section - Responsive */}
                  <div className="lg:w-80 h-48 lg:h-auto">
                    {banner.imageUrl ? (
                      <img 
                        src={banner.imageUrl} 
                        alt={banner.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full bg-gray-100 flex items-center justify-center">
                        <ImageIcon className="w-12 h-12 text-gray-400" />
                      </div>
                    )}
                  </div>

                  {/* Content Section - Responsive */}
                  <div className="flex-1 p-4 lg:p-6">
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                      <div className="flex-1 space-y-3">
                        <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                          <h3 className="text-lg lg:text-xl font-bold text-gray-900">
                            {banner.title}
                          </h3>
                          <Badge 
                            variant={banner.isActive ? 'default' : 'secondary'}
                            className={banner.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}
                          >
                            {banner.isActive ? 'نشط' : 'مخفي'}
                          </Badge>
                        </div>

                        {banner.description && (
                          <p className="text-gray-600 text-sm lg:text-base">
                            {banner.description}
                          </p>
                        )}

                        <div className="text-xs lg:text-sm text-gray-500">
                          تم الإنشاء: {new Date(banner.createdAt).toLocaleDateString('ar-SA')}
                          {banner.updatedAt && (
                            <span className="block sm:inline sm:ml-4">
                              آخر تحديث: {new Date(banner.updatedAt).toLocaleDateString('ar-SA')}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Actions - Responsive */}
                      <div className="flex flex-row sm:flex-col gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEdit(banner)}
                          className="flex-1 sm:flex-none"
                        >
                          <Edit2 className="w-4 h-4 sm:ml-2" />
                          <span className="hidden sm:inline">تعديل</span>
                        </Button>

                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleToggle(banner)}
                          className={`flex-1 sm:flex-none ${
                            banner.isActive 
                              ? 'text-red-600 border-red-200 hover:bg-red-50' 
                              : 'text-green-600 border-green-200 hover:bg-green-50'
                          }`}
                        >
                          {banner.isActive ? (
                            <>
                              <EyeOff className="w-4 h-4 sm:ml-2" />
                              <span className="hidden sm:inline">إخفاء</span>
                            </>
                          ) : (
                            <>
                              <Eye className="w-4 h-4 sm:ml-2" />
                              <span className="hidden sm:inline">إظهار</span>
                            </>
                          )}
                        </Button>

                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDelete(banner.id)}
                          className="flex-1 sm:flex-none text-red-600 border-red-200 hover:bg-red-50"
                        >
                          <Trash2 className="w-4 h-4 sm:ml-2" />
                          <span className="hidden sm:inline">حذف</span>
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Add/Edit Banner Dialog - Responsive */}
      <Dialog open={isAddDialogOpen || isEditDialogOpen} onOpenChange={(open) => {
        if (!open) {
          setIsAddDialogOpen(false);
          setIsEditDialogOpen(false);
          setEditingBanner(null);
          resetForm();
        }
      }}>
        <DialogContent className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingBanner ? 'تعديل البانر' : 'إضافة بانر جديد'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-6">
            {/* Image Upload - Responsive */}
            <div className="space-y-3">
              <Label htmlFor="image">صورة البانر</Label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-4">
                {imagePreview ? (
                  <div className="space-y-3">
                    <img 
                      src={imagePreview} 
                      alt="معاينة"
                      className="w-full h-48 object-cover rounded-lg"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => {
                        setImagePreview('');
                        setSelectedImage(null);
                      }}
                      className="w-full"
                    >
                      إزالة الصورة
                    </Button>
                  </div>
                ) : (
                  <div className="text-center">
                    <Upload className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                    <div className="space-y-2">
                      <p className="text-sm text-gray-600">انقر لاختيار صورة أو اسحبها هنا</p>
                      <input
                        id="image"
                        type="file"
                        accept="image/*"
                        onChange={handleImageSelect}
                        className="hidden"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => document.getElementById('image')?.click()}
                        className="w-full sm:w-auto"
                      >
                        <Upload className="w-4 h-4 ml-2" />
                        اختيار صورة
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Form Fields - Responsive */}
            <div className="grid grid-cols-1 gap-4">
              <div>
                <Label htmlFor="title">عنوان البانر *</Label>
                <Input
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="أدخل عنوان البانر"
                  className="text-right"
                />
              </div>

              <div>
                <Label htmlFor="description">وصف البانر</Label>
                <Textarea
                  id="description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="أدخل وصف البانر (اختياري)"
                  className="text-right min-h-[80px]"
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="active">البانر نشط</Label>
                <Switch
                  id="active"
                  checked={isActive}
                  onCheckedChange={setIsActive}
                />
              </div>
            </div>

            {/* Action Buttons - Responsive */}
            <div className="flex flex-col sm:flex-row gap-3 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setIsAddDialogOpen(false);
                  setIsEditDialogOpen(false);
                  setEditingBanner(null);
                  resetForm();
                }}
                className="w-full sm:w-auto"
              >
                إلغاء
              </Button>
              <Button
                onClick={handleSubmit}
                disabled={createBannerMutation.isPending || updateBannerMutation.isPending}
                className="w-full sm:w-auto bg-purple-600 hover:bg-purple-700"
              >
                {createBannerMutation.isPending || updateBannerMutation.isPending
                  ? 'جاري الحفظ...'
                  : editingBanner
                  ? 'تحديث البانر'
                  : 'إضافة البانر'
                }
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};