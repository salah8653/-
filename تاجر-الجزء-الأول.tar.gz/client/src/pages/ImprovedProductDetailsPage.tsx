import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowRight, Heart, Share2, ShoppingCart, Plus, Minus, Package, ShoppingBag } from "lucide-react";
import { useLocation } from "wouter";
import { useCart } from "@/hooks/useCart";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest } from "@/lib/queryClient";
import { ProductWithCategory } from "shared/schema";

export const ImprovedProductDetailsPage = () => {
  const [, params] = useRoute("/product/:id");
  const [, setLocation] = useLocation();
  const [quantity, setQuantity] = useState(1);
  const [customPrice, setCustomPrice] = useState("");
  const [selectedColor, setSelectedColor] = useState("");
  const [isSaved, setIsSaved] = useState(false);
  const { addItem } = useCart();
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: product, isLoading } = useQuery<ProductWithCategory>({
    queryKey: ["/api/products", params?.id],
    enabled: !!params?.id,
  });

  // جلب حالة الحفظ للمنتج
  const { data: savedProducts = [] } = useQuery({
    queryKey: ["/api/saved-products"],
    enabled: !!user,
  });

  // تحديث حالة الحفظ عند تحميل البيانات
  useEffect(() => {
    if (Array.isArray(savedProducts) && product) {
      const isProductSaved = savedProducts.some((saved: any) => saved.productId === product.id);
      setIsSaved(isProductSaved);
    }
  }, [savedProducts, product]);

  // تعيين السعر الافتراضي عند تحميل المنتج
  useEffect(() => {
    if (product) {
      setCustomPrice(product.price?.toString() || "");
      // تعيين أول لون متاح كافتراضي
      if (product.colors && product.colors.length > 0) {
        setSelectedColor(product.colors[0]);
      }
    }
  }, [product]);

  // حفظ/إلغاء حفظ المنتج
  const toggleSaveMutation = useMutation({
    mutationFn: async () => {
      if (isSaved) {
        return await apiRequest('DELETE', `/api/saved-products/${product?.id}`);
      } else {
        return await apiRequest('POST', '/api/saved-products', {
          productId: product?.id,
        });
      }
    },
    onSuccess: () => {
      setIsSaved(!isSaved);
      queryClient.invalidateQueries({ queryKey: ['/api/saved-products'] });
      toast({
        title: isSaved ? "تم إلغاء الحفظ" : "تم حفظ المنتج",
        description: isSaved ? "تم إزالة المنتج من المحفوظات" : "تم إضافة المنتج إلى المحفوظات",
      });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "حدث خطأ، يرجى المحاولة مرة أخرى",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-gray-500">المنتج غير موجود</p>
      </div>
    );
  }

  // التحقق من صحة السعر المخصص
  const isValidPrice = () => {
    const price = parseFloat(customPrice);
    if (!product) return false;
    
    const minPrice = product.minPrice ? parseFloat(product.minPrice) : 0;
    const maxPrice = product.maxPrice ? parseFloat(product.maxPrice) : Infinity;
    
    return price >= minPrice && price <= maxPrice && !isNaN(price);
  };

  const handleAddToCart = () => {
    if (product && isValidPrice()) {
      const productWithCustomPrice = {
        ...product,
        price: customPrice,
        selectedColor: selectedColor
      };
      addItem(productWithCustomPrice, quantity);
      toast({
        title: "تم إضافة المنتج",
        description: `تم إضافة ${quantity} من ${product.name} إلى العربة${selectedColor ? ` باللون ${selectedColor}` : ''} بسعر ${parseFloat(customPrice).toLocaleString()} د.ع`,
      });
    } else {
      toast({
        title: "خطأ في السعر",
        description: "يرجى إدخال سعر صحيح ضمن الحدود المسموحة",
        variant: "destructive",
      });
    }
  };

  const handleQuantityChange = (newQuantity: number) => {
    if (newQuantity >= 1 && newQuantity <= (product?.stock || 0)) {
      setQuantity(newQuantity);
    }
  };

  const handlePriceChange = (value: string) => {
    // السماح بالأرقام والنقطة العشرية فقط
    if (/^\d*\.?\d*$/.test(value)) {
      setCustomPrice(value);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      {/* Header */}
      <div className="bg-white shadow-sm sticky top-0 z-10">
        <div className="p-4 flex items-center justify-between">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => setLocation("/")}
          >
            <ArrowRight className="h-5 w-5" />
          </Button>
          
          <h1 className="font-semibold text-lg">{product.name}</h1>
          
          <div className="flex items-center gap-2">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => setLocation("/cart")}
            >
              <ShoppingBag className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon">
              <Share2 className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>

      {/* Product Image */}
      <div className="bg-white">
        <div className="aspect-square relative">
          {product.imageUrl ? (
            <img 
              src={product.imageUrl} 
              alt={product.name}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full bg-gray-100 flex items-center justify-center">
              <Package className="h-20 w-20 text-gray-400" />
            </div>
          )}
          
          {/* Status Badge - إظهارها فقط عند نفاد المخزون */}
          {product.stock <= 0 && (
            <div className="absolute top-4 right-4">
              <Badge className="bg-red-500 text-white">
                غير متوفر
              </Badge>
            </div>
          )}

          {/* Heart Button for Save - في أعلى الصورة */}
          <div className="absolute top-4 left-4">
            <Button 
              variant="ghost" 
              size="icon"
              className="bg-white/80 hover:bg-white"
              onClick={() => toggleSaveMutation.mutate()}
              disabled={!user || toggleSaveMutation.isPending}
            >
              <Heart className={`h-5 w-5 ${isSaved ? 'fill-red-500 text-red-500' : 'text-gray-600'}`} />
            </Button>
          </div>
        </div>
      </div>

      {/* Product Info */}
      <div className="p-4 space-y-4 pb-24">
        <Card>
          <CardContent className="p-4">
            <div className="space-y-3">
              <h1 className="text-xl font-bold text-gray-900">
                {product.name}
              </h1>

              <div className="flex items-center gap-2">
                <span className="text-sm text-gray-500">المتوفر:</span>
                <Badge variant={product.stock > 10 ? "default" : product.stock > 0 ? "secondary" : "destructive"}>
                  {product.stock} قطعة
                </Badge>
              </div>
              
              <div className="flex items-center gap-2">
                <span className="text-sm text-gray-500">الفئة:</span>
                <Badge variant="outline">
                  {product.category?.name || "غير محدد"}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Description */}
        <Card>
          <CardContent className="p-4">
            <h2 className="font-semibold text-gray-900 mb-2">وصف المنتج</h2>
            <p className="text-gray-600 leading-relaxed">
              {product.description || "لا يوجد وصف متاح للمنتج"}
            </p>
          </CardContent>
        </Card>

        {/* Color Selection */}
        {product.colors && product.colors.length > 0 && (
          <Card>
            <CardContent className="p-4">
              <h2 className="font-semibold text-gray-900 mb-3">اختر اللون</h2>
              <div className="flex flex-wrap gap-3">
                {product.colors.map((color, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedColor(color)}
                    className={`w-12 h-12 rounded-full border-4 transition-all ${
                      selectedColor === color 
                        ? 'border-purple-500 scale-110' 
                        : 'border-gray-300 hover:border-gray-400'
                    }`}
                    style={{ backgroundColor: color.toLowerCase() }}
                    title={color}
                  >
                    {selectedColor === color && (
                      <div className="w-full h-full rounded-full bg-white/30 flex items-center justify-center">
                        <div className="w-2 h-2 bg-white rounded-full"></div>
                      </div>
                    )}
                  </button>
                ))}
              </div>
              {selectedColor && (
                <p className="mt-2 text-sm text-gray-600">
                  اللون المختار: <span className="font-medium">{selectedColor}</span>
                </p>
              )}
            </CardContent>
          </Card>
        )}

        {/* Price Range and Custom Price */}
        <Card>
          <CardContent className="p-4">
            <h2 className="font-semibold text-gray-900 mb-3">تحديد السعر</h2>
            
            {/* عرض الحد الأدنى والأعلى للسعر */}
            <div className="mb-4 p-3 bg-blue-50 rounded-lg">
              <div className="flex justify-between items-center text-sm">
                <span className="text-gray-600">الحد الأدنى:</span>
                <span className="font-bold text-blue-600">
                  {product.minPrice ? parseFloat(product.minPrice).toLocaleString() : '0'} د.ع
                </span>
              </div>
              <div className="flex justify-between items-center text-sm mt-1">
                <span className="text-gray-600">الحد الأعلى:</span>
                <span className="font-bold text-blue-600">
                  {product.maxPrice ? parseFloat(product.maxPrice).toLocaleString() : 'غير محدود'} د.ع
                </span>
              </div>
            </div>

            {/* إدخال السعر المخصص */}
            <div className="space-y-2">
              <Label htmlFor="custom-price">السعر المطلوب (د.ع)</Label>
              <Input
                id="custom-price"
                type="text"
                value={customPrice}
                onChange={(e) => handlePriceChange(e.target.value)}
                placeholder="أدخل السعر المطلوب"
                className={`text-center text-lg font-semibold ${
                  !isValidPrice() ? 'border-red-500 bg-red-50' : 'border-green-500 bg-green-50'
                }`}
              />
              {!isValidPrice() && (
                <p className="text-red-500 text-xs text-center">
                  السعر يجب أن يكون بين {product.minPrice || 0} و {product.maxPrice || '∞'} د.ع
                </p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Quantity Selector */}
        <Card>
          <CardContent className="p-4">
            <h2 className="font-semibold text-gray-900 mb-3">اختر الكمية</h2>
            <div className="flex items-center justify-center bg-gray-100 rounded-lg p-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => handleQuantityChange(quantity - 1)}
                disabled={quantity <= 1}
              >
                <Minus className="h-4 w-4" />
              </Button>
              
              <span className="mx-4 text-xl font-semibold min-w-[3rem] text-center">
                {quantity}
              </span>
              
              <Button
                variant="ghost"
                size="icon"
                onClick={() => handleQuantityChange(quantity + 1)}
                disabled={quantity >= product.stock}
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            
            <div className="mt-3 text-center">
              <span className="text-sm text-gray-500">
                المخزون المتاح: {product.stock} قطعة
              </span>
            </div>
            
            <div className="mt-2 text-center">
              <span className="text-lg font-bold text-purple-600">
                الإجمالي: {(parseFloat(customPrice || product.price) * quantity).toLocaleString()} د.ع
              </span>
            </div>
          </CardContent>
        </Card>

        {/* Specifications */}
        <Card>
          <CardContent className="p-4">
            <h2 className="font-semibold text-gray-900 mb-3">المواصفات</h2>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-500">رقم المنتج:</span>
                <span className="font-medium">{product.sku}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">الفئة:</span>
                <span className="font-medium">{product.category?.name || "غير محدد"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">الحالة:</span>
                <Badge variant="default" className="bg-green-500">
                  متوفر
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bottom Actions */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4">
        <Button 
          className="w-full bg-purple-600 hover:bg-purple-700"
          onClick={handleAddToCart}
          disabled={!isValidPrice() || quantity <= 0 || quantity > product.stock || product.stock <= 0}
        >
          <ShoppingCart className="h-4 w-4 ml-2" />
          {product.stock <= 0 ? 'غير متوفر' : 'إضافة للعربة'}
        </Button>
      </div>
    </div>
  );
};