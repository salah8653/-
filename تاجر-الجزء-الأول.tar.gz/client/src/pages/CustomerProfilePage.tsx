import { useState, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowRight, 
  User, 
  Phone, 
  Mail, 
  MapPin, 
  CreditCard, 
  Package, 
  Heart, 
  Settings, 
  LogOut,
  Edit,
  ChevronLeft,
  MessageCircle,
  AlertTriangle,
  Camera,
  X,
  Wallet,
  Bot,
  Sparkles,
  Globe,
  Moon,
  Sun
} from "lucide-react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { BottomNavigation } from "@/components/BottomNavigation";
import { useToast } from "@/hooks/use-toast";
import { NetProfitSummary } from "../components/NetProfitSummary";
import { useIntro } from "@/hooks/useIntro";

// مكون قسم الدعم الفني
const SupportSection = () => {
  // جلب إعدادات التواصل من النظام
  const { data: contactSettings } = useQuery({
    queryKey: ['/api/settings/contact'],
    queryFn: async () => {
      const response = await fetch('/api/settings/contact');
      if (!response.ok) throw new Error('فشل في جلب إعدادات التواصل');
      return response.json();
    }
  });

  if (!contactSettings) return null;

  const handleWhatsAppContact = () => {
    const message = encodeURIComponent('مرحباً، أحتاج مساعدة في تطبيق تاجر');
    window.open(`https://wa.me/${contactSettings.supportWhatsapp.replace('+', '')}?text=${message}`, '_blank');
  };

  const handlePhoneCall = () => {
    window.open(`tel:${contactSettings.supportPhone}`, '_self');
  };

  const handleEmailContact = () => {
    window.open(`mailto:${contactSettings.supportEmail}?subject=استفسار من تطبيق تاجر`, '_self');
  };

  return (
    <div className="p-4 mt-6">
      <Card className="bg-gradient-to-r from-blue-50 to-cyan-50 border-blue-200">
        <CardContent className="p-4">
          <div className="flex items-center gap-3 mb-4">
            <MessageCircle className="h-5 w-5 text-blue-600" />
            <h3 className="font-semibold text-blue-900">الدعم الفني</h3>
          </div>
          
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-white rounded-lg border border-blue-100">
              <div className="flex items-center gap-3">
                <Phone className="h-4 w-4 text-blue-600" />
                <div>
                  <p className="text-sm font-medium text-gray-900">اتصال هاتفي</p>
                  <p className="text-xs text-gray-500">{contactSettings.supportPhone}</p>
                </div>
              </div>
              <Button
                size="sm"
                onClick={handlePhoneCall}
                className="bg-blue-600 hover:bg-blue-700"
              >
                اتصال
              </Button>
            </div>

            <div className="flex items-center justify-between p-3 bg-white rounded-lg border border-green-100">
              <div className="flex items-center gap-3">
                <MessageCircle className="h-4 w-4 text-green-600" />
                <div>
                  <p className="text-sm font-medium text-gray-900">واتساب</p>
                  <p className="text-xs text-gray-500">{contactSettings.supportWhatsapp}</p>
                </div>
              </div>
              <Button
                size="sm"
                onClick={handleWhatsAppContact}
                className="bg-green-600 hover:bg-green-700"
              >
                تواصل
              </Button>
            </div>

            <div className="flex items-center justify-between p-3 bg-white rounded-lg border border-orange-100">
              <div className="flex items-center gap-3">
                <Mail className="h-4 w-4 text-orange-600" />
                <div>
                  <p className="text-sm font-medium text-gray-900">البريد الإلكتروني</p>
                  <p className="text-xs text-gray-500">{contactSettings.supportEmail}</p>
                </div>
              </div>
              <Button
                size="sm"
                onClick={handleEmailContact}
                className="bg-orange-600 hover:bg-orange-700"
              >
                إرسال
              </Button>
            </div>

            <div className="flex items-center gap-3 p-3 bg-white rounded-lg border border-gray-100">
              <MapPin className="h-4 w-4 text-gray-600" />
              <div>
                <p className="text-sm font-medium text-gray-900">{contactSettings.companyName}</p>
                <p className="text-xs text-gray-500">{contactSettings.companyAddress}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export const CustomerProfilePage = () => {
  const [, setLocation] = useLocation();
  const { user, logout, updateUser } = useAuth();
  const { toast } = useToast();
  const { resetIntro } = useIntro();
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [showWarning, setShowWarning] = useState(true);

  // جلب إحصائيات المستخدم
  const { data: userStats } = useQuery({
    queryKey: [`/api/user-stats/${user?.phone}`],
    enabled: !!user?.phone,
  });

  // جلب الطلبات لمكون صافي الأرباح
  const { data: orders = [] } = useQuery<any[]>({
    queryKey: ['/api/orders'],
  });

  // حساب الأرباح المحققة من جميع الطلبات المكتملة (نموذج العمل الموحد)
  const completedOrders = orders.filter(order => 
    order.status === 'completed' || order.status === 'مكتمل'
  );
  const totalCompletedProfit = completedOrders.reduce((sum, order) => sum + (order.profit || 0), 0);
  
  // تسجيل للتحقق
  console.log('All completed orders:', completedOrders);
  console.log('Total completed profit:', totalCompletedProfit);

  // رفع الصورة الشخصية
  const uploadImageMutation = useMutation({
    mutationFn: async (file: File) => {
      console.log('📤 بدء رفع الصورة:', file.name, file.size, file.type);
      
      const formData = new FormData();
      formData.append('file', file);
      
      console.log('📝 FormData created:', formData.has('file'));
      
      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });
      
      console.log('📡 Response status:', response.status);
      
      if (!response.ok) {
        const errorData = await response.text();
        console.error('❌ Upload error:', errorData);
        throw new Error(`فشل في رفع الصورة: ${response.status}`);
      }
      
      const data = await response.json();
      console.log('✅ Upload success:', data);
      return data;
    },
    onSuccess: async (data) => {
      console.log('🎉 Upload mutation success:', data);
      
      // تحديث صورة المستخدم
      if (user?.id) {
        try {
          console.log('📝 Updating user profile image...');
          await apiRequest('PUT', `/api/users/${user.id}`, {
            profileImage: data.url
          });
          
          // تحديث بيانات المستخدم محلياً
          updateUser({ profileImage: data.url });
          
          toast({
            title: "تم تحديث الصورة الشخصية",
            description: "تم حفظ صورتك الجديدة بنجاح",
          });
          
          // إعادة تحميل بيانات المستخدم
          queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
        } catch (error) {
          console.error('❌ Error updating user profile:', error);
          toast({
            title: "خطأ في حفظ الصورة",
            description: "تم رفع الصورة لكن فشل في حفظها",
            variant: "destructive",
          });
        }
      }
    },
    onError: (error) => {
      console.error('❌ Upload mutation error:', error);
      toast({
        title: "خطأ في رفع الصورة",
        description: error.message || "حدث خطأ أثناء رفع الصورة",
        variant: "destructive",
      });
    },
    onSettled: () => {
      setIsUploading(false);
    }
  });

  const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB
        toast({
          title: "حجم الصورة كبير",
          description: "يجب أن يكون حجم الصورة أقل من 5 ميجابايت",
          variant: "destructive",
        });
        return;
      }

      setIsUploading(true);
      uploadImageMutation.mutate(file);
    }
  };

  const handleLogout = () => {
    toast({
      title: "تم تسجيل الخروج بنجاح",
      description: "شكراً لك، نراك قريباً!"
    });
    logout(); // سيقوم بإعادة التوجيه تلقائياً
  };

  // إضافة الدوال المطلوبة للإعدادات
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [language, setLanguage] = useState('ar');

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    if (!isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    toast({
      title: "تم تغيير وضع العرض",
      description: isDarkMode ? "تم التبديل للوضع الفاتح" : "تم التبديل للوضع المظلم"
    });
  };

  const toggleLanguage = () => {
    const newLanguage = language === 'ar' ? 'en' : 'ar';
    setLanguage(newLanguage);
    toast({
      title: "تم تغيير اللغة",
      description: newLanguage === 'ar' ? "تم التبديل للعربية" : "Switched to English"
    });
  };

  const menuItems = [
    {
      icon: Wallet,
      title: "عمليات السحب",
      subtitle: "تاريخ عمليات السحب والحالة",
      onClick: () => setLocation("/withdraw-history")
    },

    {
      icon: Bot,
      title: "المساعد الذكي",
      subtitle: "مساعد التجارة الإلكترونية الشامل",
      onClick: () => setLocation("/ecommerce-assistant")
    },
    {
      icon: MapPin,
      title: "سياسة التطبيق",
      subtitle: "الشروط والأحكام وسياسات التوصيل",
      onClick: () => setLocation("/app-policies")
    },
    {
      icon: Heart,
      title: "قائمة المحفوظات",
      subtitle: "المنتجات المحفوظة",
      onClick: () => setLocation("/saved-products")
    },
    {
      icon: MessageCircle,
      title: "الدعم الفني",
      subtitle: "التواصل مع فريق الدعم",
      onClick: () => setLocation('/support')
    },
    {
      icon: Settings,
      title: "الإعدادات",
      subtitle: "تخصيص التطبيق والإعدادات الشخصية",
      onClick: () => setLocation("/user-settings")
    },
    {
      icon: Sparkles,
      title: "إعادة عرض الترحيب",
      subtitle: "مشاهدة شاشة الترحيب مرة أخرى",
      onClick: () => {
        resetIntro();
        toast({
          title: "سيتم عرض شاشة الترحيب",
          description: "إعادة تحميل الصفحة لمشاهدة الانترو"
        });
        setTimeout(() => {
          window.location.reload();
        }, 1000);
      }
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="p-4 flex items-center gap-3">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => setLocation("/")}
          >
            <ArrowRight className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-bold">حسابي</h1>
        </div>
      </div>

      {/* Profile Header */}
      <div className="p-4">
        <Card className="bg-gradient-to-r from-purple-600 to-purple-800 text-white border-0">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="relative">
                <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center overflow-hidden">
                  {(user as any)?.profileImage ? (
                    <img 
                      src={(user as any)?.profileImage} 
                      alt="الصورة الشخصية" 
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <User className="h-8 w-8 text-white" />
                  )}
                </div>
                <Button
                  size="icon"
                  className="absolute -bottom-1 -right-1 rounded-full w-6 h-6 bg-white hover:bg-gray-100 shadow-lg"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isUploading}
                >
                  {isUploading ? (
                    <div className="w-3 h-3 border-2 border-purple-600 border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <Camera className="h-3 w-3 text-purple-600" />
                  )}
                </Button>
              </div>
              
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                className="hidden"
              />
              
              <div className="flex-1">
                <h2 className="text-xl font-bold mb-1">
                  {user?.fullName || "مستخدم"}
                </h2>
                <p className="text-purple-100 text-sm">
                  عضو منذ 2025
                </p>
              </div>
              
              <Button 
                variant="ghost" 
                size="icon"
                className="text-white hover:bg-white/20"
                onClick={() => setLocation("/profile/edit")}
              >
                <Edit className="h-5 w-5" />
              </Button>
            </div>
            
            {/* Contact Info */}
            <div className="mt-4 space-y-2">
              <div className="flex items-center gap-2 text-purple-100">
                <Phone className="h-4 w-4" />
                <span className="text-sm">{user?.phone}</span>
              </div>
              
              {user?.email && (
                <div className="flex items-center gap-2 text-purple-100">
                  <Mail className="h-4 w-4" />
                  <span className="text-sm">{user.email}</span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* رسالة التحذير */}
      {showWarning && (
        <div className="px-4 mb-4">
          <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg relative">
            <button
              onClick={() => setShowWarning(false)}
              className="absolute top-2 left-2 p-1 hover:bg-amber-100 rounded-full transition-colors"
              aria-label="إغلاق التحذير"
            >
              <X className="w-4 h-4 text-amber-600" />
            </button>
            <div className="flex items-start gap-3 pl-6">
              <AlertTriangle className="w-5 h-5 text-amber-600 mt-0.5 flex-shrink-0" />
              <div className="text-right">
                <p className="text-amber-800 text-sm font-medium mb-1">
                  تحذير مهم
                </p>
                <p className="text-amber-700 text-sm leading-relaxed">
                  رقم الهاتف والبريد الإلكتروني محميان ولا يمكن تغييرهما لحماية حسابك. في حالة الحاجة لتعديلهما، تواصل مع الدعم الفني
                </p>
                <p className="text-amber-700 text-sm mt-2 font-medium">
                  شكرا لك
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* مكون صافي الأرباح */}
      <div className="px-4 mb-4">
        <NetProfitSummary orders={Array.isArray(orders) ? orders : []} />
      </div>

      {/* Stats Cards */}
      <div className="px-4 mb-4">
        <div className="grid grid-cols-3 gap-3">
          <Card>
            <CardContent className="p-3 text-center">
              <div className="text-2xl font-bold text-purple-600 mb-1">{(userStats as any)?.totalProfit || 0}</div>
              <div className="text-xs text-gray-500">د.ع</div>
              <div className="text-sm text-gray-700">الأرباح المحققة</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-3 text-center">
              <div className="text-2xl font-bold text-green-600 mb-1">{(userStats as any)?.pendingProfit || 0}</div>
              <div className="text-xs text-gray-500">د.ع</div>
              <div className="text-sm text-gray-700">الأرباح القادمة</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-3 text-center">
              <div className="text-2xl font-bold text-blue-600 mb-1">{(userStats as any)?.totalOrders || 0}</div>
              <div className="text-xs text-gray-500">طلب</div>
              <div className="text-sm text-gray-700">إجمالي الطلبات</div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Withdraw Button */}
      <div className="px-4 mb-4">
        <Button
          onClick={() => setLocation("/withdraw")}
          className="w-full bg-green-600 hover:bg-green-700 text-white py-3"
          disabled={totalCompletedProfit === 0 || totalCompletedProfit < 10000}
        >
          <Wallet className="w-5 h-5 ml-2" />
          سحب الأرباح
        </Button>
        {(totalCompletedProfit === 0 || totalCompletedProfit < 10000) && (
          <p className="text-sm text-gray-500 text-center mt-2">
            {totalCompletedProfit === 0 
              ? "لا توجد أرباح متاحة للسحب" 
              : "الحد الأدنى للسحب 10,000 د.ع"}
          </p>
        )}
      </div>

      {/* Menu Items */}
      <div className="px-4 space-y-2">
        {menuItems.map((item, index) => (
          <Card key={index} className="hover:shadow-md transition-shadow">
            <CardContent className="p-0">
              <Button
                variant="ghost"
                className="w-full justify-start p-4 h-auto"
                onClick={item.onClick}
              >
                <div className="flex items-center gap-3 w-full">
                  <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                    <item.icon className="h-5 w-5 text-purple-600" />
                  </div>
                  
                  <div className="flex-1 text-right">
                    <div className="font-semibold text-gray-900">
                      {item.title}
                    </div>
                    <div className="text-sm text-gray-500">
                      {item.subtitle}
                    </div>
                  </div>
                  
                  <ChevronLeft className="h-5 w-5 text-gray-400" />
                </div>
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Support Section */}
      <SupportSection />



      {/* Logout */}
      <div className="p-4 pb-20">
        <Button 
          variant="outline" 
          className="w-full text-red-600 border-red-200 hover:bg-red-50"
          onClick={handleLogout}
        >
          <LogOut className="h-4 w-4 ml-2" />
          تسجيل الخروج
        </Button>
      </div>

      <BottomNavigation />
    </div>
  );
};