import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import { useLocation } from "wouter";
import { ECommerceAIAssistant } from "@/components/ECommerceAIAssistant";

export const ECommerceAssistantPage = () => {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="p-4 flex items-center gap-3">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => setLocation("/profile")}
          >
            <ArrowRight className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-bold">المساعد الذكي للتجارة الإلكترونية</h1>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        <ECommerceAIAssistant />
      </div>
    </div>
  );
};