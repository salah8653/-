import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  BarChart3, 
  Package, 
  Users, 
  ShoppingCart, 
  Settings, 
  MessageCircle, 
  Image, 
  CreditCard, 
  TrendingUp,
  Search,
  ArrowRight,
  Bot,
  ChevronRight,
  Store,
  ArrowLeft
} from 'lucide-react';
import { Link, useLocation } from 'wouter';

interface ManagementSection {
  id: string;
  title: string;
  description: string;
  icon: any;
  color: string;
  path: string;
  count?: number;
  status?: 'active' | 'inactive' | 'warning';
}

export const StoreManagementPage = () => {
  const [, setLocation] = useLocation();
  const [searchTerm, setSearchTerm] = useState('');

  const managementSections: ManagementSection[] = [
    {
      id: 'dashboard',
      title: 'لوحة التحكم الرئيسية',
      description: 'إحصائيات عامة ونظرة شاملة على المتجر',
      icon: BarChart3,
      color: 'bg-gradient-to-r from-blue-500 to-blue-600',
      path: '/dashboard',
      status: 'active'
    },
    {
      id: 'products',
      title: 'إدارة المنتجات',
      description: 'إضافة وتعديل وحذف المنتجات',
      icon: Package,
      color: 'bg-gradient-to-r from-green-500 to-green-600',
      path: '/products',
      count: 1,
      status: 'active'
    },
    {
      id: 'categories',
      title: 'إدارة الفئات',
      description: 'تنظيم المنتجات في فئات مختلفة',
      icon: Store,
      color: 'bg-gradient-to-r from-purple-500 to-purple-600',
      path: '/categories/new',
      status: 'active'
    },
    {
      id: 'users',
      title: 'إدارة المستخدمين',
      description: 'إدارة حسابات العملاء والموظفين',
      icon: Users,
      color: 'bg-gradient-to-r from-indigo-500 to-indigo-600',
      path: '/users',
      count: 2,
      status: 'active'
    },
    {
      id: 'orders',
      title: 'إدارة الطلبات',
      description: 'متابعة ومعالجة طلبات العملاء',
      icon: ShoppingCart,
      color: 'bg-gradient-to-r from-orange-500 to-orange-600',
      path: '/orders',
      count: 0,
      status: 'inactive'
    },
    {
      id: 'support',
      title: 'الدعم الفني',
      description: 'الرد على استفسارات ومساعدة العملاء',
      icon: MessageCircle,
      color: 'bg-gradient-to-r from-pink-500 to-pink-600',
      path: '/support',
      status: 'active'
    },
    {
      id: 'banners',
      title: 'إدارة البانرات',
      description: 'إضافة وتعديل إعلانات المتجر',
      icon: Image,
      color: 'bg-gradient-to-r from-cyan-500 to-cyan-600',
      path: '/banners',
      count: 2,
      status: 'active'
    },
    {
      id: 'analytics',
      title: 'التحليلات والتقارير',
      description: 'تقارير مفصلة عن أداء المتجر',
      icon: TrendingUp,
      color: 'bg-gradient-to-r from-emerald-500 to-emerald-600',
      path: '/analytics',
      status: 'active'
    },
    {
      id: 'withdrawals',
      title: 'إدارة السحوبات',
      description: 'معالجة طلبات سحب الأرباح',
      icon: CreditCard,
      color: 'bg-gradient-to-r from-red-500 to-red-600',
      path: '/withdraw-management',
      count: 0,
      status: 'inactive'
    },
    {
      id: 'ai-assistant',
      title: 'المساعد الذكي',
      description: 'أدوات الذكاء الاصطناعي لتحسين المتجر',
      icon: Bot,
      color: 'bg-gradient-to-r from-violet-500 to-violet-600',
      path: '/ai-assistant',
      status: 'active'
    },
    {
      id: 'settings',
      title: 'الإعدادات العامة',
      description: 'إعدادات التطبيق والمتجر',
      icon: Settings,
      color: 'bg-gradient-to-r from-gray-500 to-gray-600',
      path: '/settings',
      status: 'active'
    },

  ];

  // تصفية الأقسام حسب البحث
  const filteredSections = managementSections.filter(section =>
    section.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    section.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusBadge = (status?: string) => {
    switch (status) {
      case 'active':
        return <Badge variant="default" className="bg-green-100 text-green-700">نشط</Badge>;
      case 'inactive':
        return <Badge variant="secondary" className="bg-gray-100 text-gray-700">غير نشط</Badge>;
      case 'warning':
        return <Badge variant="destructive" className="bg-yellow-100 text-yellow-700">تحذير</Badge>;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50" dir="rtl">
      {/* رأس الصفحة */}
      <div className="bg-white border-b border-gray-200 shadow-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between py-4">
            <div className="flex items-center gap-4">
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setLocation('/dashboard')}
                className="flex items-center gap-2"
              >
                <ArrowLeft className="h-4 w-4" />
                العودة
              </Button>
              
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                  <Store className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">إدارة المتجر</h1>
                  <p className="text-gray-600 text-sm">
                    مركز التحكم الشامل في جميع أقسام المتجر • تاجر
                  </p>
                </div>
              </div>
            </div>
            
            {/* شريط البحث */}
            <div className="relative">
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="البحث في الأقسام..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pr-10 pl-4 w-80 bg-gray-50 border-gray-200"
              />
            </div>
          </div>
        </div>
      </div>

      {/* المحتوى الرئيسي */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* إحصائيات سريعة */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-100 text-sm">إجمالي الأقسام</p>
                  <p className="text-2xl font-bold">{managementSections.length}</p>
                </div>
                <Store className="h-8 w-8 text-blue-200" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-100 text-sm">الأقسام النشطة</p>
                  <p className="text-2xl font-bold">
                    {managementSections.filter(s => s.status === 'active').length}
                  </p>
                </div>
                <BarChart3 className="h-8 w-8 text-green-200" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-r from-orange-500 to-orange-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-orange-100 text-sm">المنتجات</p>
                  <p className="text-2xl font-bold">1</p>
                </div>
                <Package className="h-8 w-8 text-orange-200" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-100 text-sm">المستخدمين</p>
                  <p className="text-2xl font-bold">2</p>
                </div>
                <Users className="h-8 w-8 text-purple-200" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* شبكة الأقسام */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredSections.map((section) => {
            const IconComponent = section.icon;
            return (
              <Card key={section.id} className="group hover:shadow-lg transition-all duration-200 cursor-pointer border border-gray-200 hover:border-gray-300">
                <Link href={section.path}>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className={`w-12 h-12 ${section.color} rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform duration-200`}>
                        <IconComponent className="h-6 w-6 text-white" />
                      </div>
                      <div className="flex items-center gap-2">
                        {section.count !== undefined && (
                          <Badge variant="secondary" className="text-xs">
                            {section.count}
                          </Badge>
                        )}
                        {getStatusBadge(section.status)}
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">
                        {section.title}
                      </CardTitle>
                      <ChevronRight className="h-5 w-5 text-gray-400 group-hover:text-blue-500 group-hover:translate-x-1 transition-all" />
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <p className="text-gray-600 text-sm leading-relaxed">
                      {section.description}
                    </p>
                    <div className="flex items-center justify-between mt-4">
                      <span className="text-xs text-gray-500">انقر للدخول</span>
                      <ArrowRight className="h-4 w-4 text-gray-400 group-hover:text-blue-500 group-hover:translate-x-1 transition-all" />
                    </div>
                  </CardContent>
                </Link>
              </Card>
            );
          })}
        </div>

        {/* رسالة عدم وجود نتائج */}
        {filteredSections.length === 0 && (
          <div className="text-center py-12">
            <Store className="h-16 w-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">لا توجد أقسام</h3>
            <p className="text-gray-500">لا توجد أقسام تطابق البحث "{searchTerm}"</p>
            <Button 
              variant="outline" 
              onClick={() => setSearchTerm('')}
              className="mt-4"
            >
              إزالة الفلتر
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};