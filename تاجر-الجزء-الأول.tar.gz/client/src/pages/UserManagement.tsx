import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Users, 
  DollarSign, 
  Package, 
  ShoppingCart, 
  Calendar,
  Phone,
  Mail,
  UserCheck,
  UserX,
  Search,
  Filter,
  Lock,
  Ban,
  Clock,
  LogOut
} from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useLocation } from "wouter";

interface UserWithStats {
  id: string;
  fullName: string;
  phone: string;
  email: string;
  password: string;
  role: string;
  joinDate: string;
  totalProfit: number;
  totalOrders: number;
  totalProductsSold: number;
  createdAt: any;
  isBanned?: boolean;
  banExpiresAt?: string;
  banReason?: string;
  status?: string;
}

export default function UserManagement() {
  const [, setLocation] = useLocation();
  const [searchTerm, setSearchTerm] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [showAdminDialog, setShowAdminDialog] = useState(false);
  const [adminPassword, setAdminPassword] = useState("");
  const [pendingUserUpdate, setPendingUserUpdate] = useState<{userId: string, newRole: string} | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: users = [], isLoading } = useQuery({
    queryKey: ["/api/users-with-stats"],
    queryFn: () => fetch("/api/users-with-stats").then(res => res.json())
  });

  const updateUserRoleMutation = useMutation({
    mutationFn: async ({ userId, newRole }: { userId: string; newRole: string }) => {
      return apiRequest("PUT", `/api/users/${userId}/role`, { role: newRole });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users-with-stats"] });
      toast({
        title: "تم التحديث",
        description: "تم تحديث دور المستخدم بنجاح"
      });
      setShowAdminDialog(false);
      setAdminPassword("");
      setPendingUserUpdate(null);
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "فشل في تحديث دور المستخدم",
        variant: "destructive"
      });
      setShowAdminDialog(false);
      setAdminPassword("");
      setPendingUserUpdate(null);
    }
  });

  const banUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      // استخدام معرف Firebase الصحيح بدلاً من المعرف الرقمي
      const actualUserId = userId.toString().includes('fSL') || userId.toString().includes('x8z') || userId.toString().length > 10 
        ? userId 
        : users?.find(u => u.id.toString() === userId.toString())?.firebaseId || userId;
      
      return apiRequest("POST", "/api/users/ban", { 
        userId: actualUserId, 
        reason: "حظر من لوحة التحكم",
        banEndTime: null // حظر لا نهائي
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users-with-stats"] });
      toast({
        title: "تم حظر المستخدم",
        description: "تم حظر المستخدم بشكل دائم"
      });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "فشل في حظر المستخدم",
        variant: "destructive"
      });
    }
  });

  const unbanUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      // البحث عن المستخدم في القائمة للحصول على معرف Firebase الصحيح
      const user = users?.find((u: any) => u.id.toString() === userId.toString());
      
      if (!user) {
        throw new Error('المستخدم غير موجود');
      }
      
      // استخدام معرف Firebase الصحيح المضاف حديثاً
      const firebaseUserId = user.firebaseId;
      console.log('محاولة إلغاء حظر المستخدم:', firebaseUserId, user);
      
      if (!firebaseUserId) {
        throw new Error('معرف Firebase غير موجود');
      }
      
      return apiRequest("POST", "/api/users/unban", { userId: firebaseUserId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users-with-stats"] });
      toast({
        title: "تم إلغاء الحظر",
        description: "تم إلغاء حظر المستخدم بنجاح"
      });
      
      // تحديث قائمة المستخدمين فوراً
      setTimeout(() => {
        queryClient.invalidateQueries({ queryKey: ["/api/users-with-stats"] });
      }, 500);
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "فشل في إلغاء حظر المستخدم",
        variant: "destructive"
      });
    }
  });

  const forceLogoutMutation = useMutation({
    mutationFn: async (userId: string) => {
      return apiRequest("POST", "/api/users/force-logout", { userId });
    },
    onSuccess: () => {
      toast({
        title: "تم تسجيل الخروج",
        description: "تم تسجيل خروج المستخدم بنجاح"
      });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "فشل في تسجيل خروج المستخدم",
        variant: "destructive"
      });
    }
  });

  const handleForceLogout = (userId: string) => {
    forceLogoutMutation.mutate(userId);
  };

  const handleRoleUpdate = (userId: string, newRole: string) => {
    if (newRole === 'admin') {
      setPendingUserUpdate({ userId, newRole });
      setShowAdminDialog(true);
    } else {
      updateUserRoleMutation.mutate({ userId, newRole });
    }
  };

  const confirmAdminPromotion = () => {
    if (adminPassword !== "12345salah2001") {
      toast({
        title: "كلمة مرور خاطئة",
        description: "يرجى إدخال كلمة مرور المدير الصحيحة",
        variant: "destructive"
      });
      return;
    }

    if (pendingUserUpdate) {
      updateUserRoleMutation.mutate(pendingUserUpdate);
    }
  };

  const filteredUsers = users.filter((user: UserWithStats) => {
    const matchesSearch = user.fullName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.phone?.includes(searchTerm) ||
                         user.email?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = roleFilter === "all" || user.role === roleFilter;
    return matchesSearch && matchesRole;
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600 mx-auto"></div>
          <p className="text-gray-600 mt-4">جاري تحميل بيانات المستخدمين...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold text-slate-900 mb-2">إدارة المستخدمين</h1>
              <p className="text-slate-600">إدارة وتتبع جميع المستخدمين في النظام</p>
            </div>
            <div className="text-center">
              <Users className="w-12 h-12 text-blue-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-slate-900">{users.length}</div>
              <div className="text-sm text-slate-600">إجمالي المستخدمين</div>
            </div>
          </div>

          {/* Search and Filter */}
          <div className="flex gap-4 mb-6">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  placeholder="البحث بالاسم أو الهاتف أو البريد الإلكتروني..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pr-10 text-right"
                />
              </div>
            </div>
            <div>
              <Select value={roleFilter} onValueChange={setRoleFilter}>
                <SelectTrigger className="w-48">
                  <Filter className="w-4 h-4 ml-2" />
                  <SelectValue placeholder="فلترة حسب الدور" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع المستخدمين</SelectItem>
                  <SelectItem value="admin">المديرين</SelectItem>
                  <SelectItem value="customer">العملاء</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-100">إجمالي الأرباح</p>
                    <p className="text-2xl font-bold">
                      {users.reduce((sum: number, user: UserWithStats) => sum + user.totalProfit, 0).toLocaleString()}
                    </p>
                  </div>
                  <DollarSign className="w-8 h-8 text-green-100" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-blue-100">إجمالي الطلبات</p>
                    <p className="text-2xl font-bold">
                      {users.reduce((sum: number, user: UserWithStats) => sum + user.totalOrders, 0)}
                    </p>
                  </div>
                  <ShoppingCart className="w-8 h-8 text-blue-100" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-purple-100">المنتجات المباعة</p>
                    <p className="text-2xl font-bold">
                      {users.reduce((sum: number, user: UserWithStats) => sum + user.totalProductsSold, 0)}
                    </p>
                  </div>
                  <Package className="w-8 h-8 text-purple-100" />
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Users List */}
        <div className="space-y-4">
          {filteredUsers.length === 0 ? (
            <Card className="bg-white">
              <CardContent className="p-8 text-center">
                <Users className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-600 mb-2">لا يوجد مستخدمون</h3>
                <p className="text-gray-500">لا يوجد مستخدمون يطابقون معايير البحث</p>
              </CardContent>
            </Card>
          ) : (
            filteredUsers.map((user: UserWithStats) => (
              <Card key={user.id} className="bg-white shadow-md hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="space-y-4">
                    {/* معلومات المستخدم الأساسية */}
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-lg">
                        {user.fullName?.charAt(0) || user.phone?.charAt(0) || '؟'}
                      </div>
                      <div>
                        <div className="flex items-center gap-3 mb-1">
                          <h3 className="text-lg font-semibold text-slate-900">{user.fullName || 'غير محدد'}</h3>
                          <Badge variant={user.role === 'admin' ? 'destructive' : 'secondary'}>
                            {user.role === 'admin' ? 'مدير' : 'عميل'}
                          </Badge>
                          {user.status === 'banned' && (
                            <Badge variant="destructive" className="bg-red-600">
                              محظور
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    {/* بيانات المستخدم التفصيلية */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      <div className="flex items-center gap-2 text-sm">
                        <Phone className="w-4 h-4 text-blue-600 flex-shrink-0" />
                        <span className="font-medium text-slate-700 min-w-[60px]">الهاتف:</span>
                        <span className="bg-blue-50 px-3 py-1 rounded-lg text-blue-800 font-mono text-left flex-1">
                          {user.phone}
                        </span>
                      </div>
                      
                      {user.email && (
                        <div className="flex items-center gap-2 text-sm">
                          <Mail className="w-4 h-4 text-green-600 flex-shrink-0" />
                          <span className="font-medium text-slate-700 min-w-[60px]">الإيميل:</span>
                          <span className="bg-green-50 px-3 py-1 rounded-lg text-green-800 text-left flex-1 break-all">
                            {user.email}
                          </span>
                        </div>
                      )}
                      
                      <div className="flex items-center gap-2 text-sm">
                        <Lock className="w-4 h-4 text-purple-600 flex-shrink-0" />
                        <span className="font-medium text-slate-700 min-w-[80px]">كلمة المرور:</span>
                        <span className="bg-purple-50 px-3 py-1 rounded-lg text-purple-800 font-mono flex-1">
                          {user.password || 'غير محدد'}
                        </span>
                      </div>
                      
                      <div className="flex items-center gap-2 text-sm">
                        <Calendar className="w-4 h-4 text-orange-600 flex-shrink-0" />
                        <span className="font-medium text-slate-700 min-w-[80px]">تاريخ التسجيل:</span>
                        <span className="bg-orange-50 px-3 py-1 rounded-lg text-orange-800">
                          {user.createdAt ? new Date(user.createdAt).toLocaleDateString('en-GB', {
                            year: 'numeric',
                            month: '2-digit',
                            day: '2-digit'
                          }) : 'غير محدد'}
                        </span>
                      </div>
                    </div>

                    {/* إحصائيات المستخدم */}
                    <div className="flex items-center gap-6 text-sm">
                      <div className="flex items-center gap-1">
                        <DollarSign className="w-4 h-4 text-green-600" />
                        <span className="text-green-600 font-medium">{user.totalProfit.toLocaleString()}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <ShoppingCart className="w-4 h-4 text-blue-600" />
                        <span className="text-blue-600 font-medium">{user.totalOrders} طلب</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Package className="w-4 h-4 text-purple-600" />
                        <span className="text-purple-600 font-medium">{user.totalProductsSold} منتج</span>
                      </div>
                    </div>
                    
                    {/* أزرار الإدارة */}
                    <div className="border-t pt-4 space-y-3">
                      {/* أزرار إدارة الدور */}
                      {user.role === 'customer' ? (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleRoleUpdate(user.id, 'admin')}
                          disabled={updateUserRoleMutation.isPending}
                          className="text-green-600 border-green-300 hover:bg-green-50 font-medium w-full"
                        >
                          <UserCheck className="w-4 h-4 ml-1" />
                          ترقية لمدير
                        </Button>
                      ) : user.role === 'admin' ? (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleRoleUpdate(user.id, 'customer')}
                          disabled={updateUserRoleMutation.isPending}
                          className="text-orange-600 border-orange-300 hover:bg-orange-50 font-medium w-full"
                        >
                          <UserX className="w-4 h-4 ml-1" />
                          إزالة الإدارة
                        </Button>
                      ) : null}

                      {/* أزرار إدارة الحظر - للعملاء فقط */}
                      {user.role === 'customer' && (
                        <>
                          {(user.status === 'banned' || (user as any).isBanned) ? (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => unbanUserMutation.mutate(user.id)}
                              disabled={unbanUserMutation.isPending}
                              className="text-green-600 border-green-300 hover:bg-green-50 font-bold bg-green-50 w-full"
                            >
                              <Clock className="w-4 h-4 ml-1" />
                              إلغاء الحظر
                            </Button>
                          ) : (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                // التأكد من استخدام معرف Firebase الصحيح
                                const firebaseId = user.id.toString().startsWith('1748') ? 
                                  (user as any).firebaseId || user.id : user.id;
                                console.log('محاولة حظر المستخدم:', firebaseId, user);
                                banUserMutation.mutate(firebaseId);
                              }}
                              disabled={banUserMutation.isPending}
                              className="text-red-600 border-red-400 hover:bg-red-50 font-bold bg-red-50 border-2 w-full shadow-sm"
                            >
                              <Ban className="w-4 h-4 ml-1" />
                              حظر المستخدم
                            </Button>
                          )}
                        </>
                      )}
                      
                      {/* زر تسجيل خروج المستخدم */}
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleForceLogout(user.id)}
                        disabled={forceLogoutMutation.isPending}
                        className="text-orange-600 border-orange-300 hover:bg-orange-50 font-medium w-full"
                      >
                        <LogOut className="w-4 h-4 ml-1" />
                        تسجيل خروج المستخدم
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>

        {/* Exit Button - Fixed position */}
        <div className="fixed bottom-6 right-6 z-50">
          <Button
            onClick={() => setLocation('/store-management')}
            size="lg"
            className="bg-red-600 hover:bg-red-700 text-white shadow-lg rounded-full w-14 h-14 p-0"
          >
            ×
          </Button>
        </div>
      </div>

      {/* Dialog for Admin Password */}
      <Dialog open={showAdminDialog} onOpenChange={setShowAdminDialog}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>تأكيد ترقية المستخدم إلى مدير</DialogTitle>
            <DialogDescription>
              يرجى إدخال كلمة مرور المدير لتأكيد هذا الإجراء
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <Label htmlFor="adminPassword">كلمة مرور المدير</Label>
              <Input
                id="adminPassword"
                type="password"
                placeholder="أدخل كلمة مرور المدير"
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                className="text-right"
              />
              <p className="text-xs text-gray-500">
                هذا الإجراء يتطلب تأكيد من المدير الحالي
              </p>
            </div>
          </div>
          
          <DialogFooter className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => {
                setShowAdminDialog(false);
                setAdminPassword("");
                setPendingUserUpdate(null);
              }}
            >
              إلغاء
            </Button>
            <Button
              onClick={confirmAdminPromotion}
              disabled={!adminPassword || updateUserRoleMutation.isPending}
              className="bg-red-600 hover:bg-red-700"
            >
              {updateUserRoleMutation.isPending ? 'جارٍ...' : 'تأكيد'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}