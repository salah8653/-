import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { OrdersManager } from '@/components/OrdersManager';
import { OrderStatusSelect } from '@/components/OrderStatusSelect';
import { ProfitDisplay } from '@/components/ProfitDisplay';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowRight, User, Phone, Package, Bell, Clock, MapPin, Store, DollarSign, Edit } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { formatCurrency, getOrderStatus, getOrderStatusColor } from '../utils/formatters';
import { NetProfitSummary } from '../components/NetProfitSummary';

interface Trader {
  name: string;
  phone: string;
  ordersCount: number;
  totalAmount: number;
  lastOrderDate: string;
  hasNewOrders: boolean;
  newOrdersCount: number;
  customers: Customer[];
}

interface Customer {
  name: string;
  phone: string;
  ordersCount: number;
  totalAmount: number;
  lastOrderDate: string;
  hasNewOrders: boolean;
  newOrdersCount: number;
}

interface Order {
  id: number;
  total: string;
  status: string;
  customerDetails: {
    name: string;
    phone: string;
    governorate: string;
    area: string;
    address: string;
    notes?: string;
  };
  items: Array<{
    product: {
      name: string;
      price: number;
    };
    quantity: number;
  }>;
  customerPrice: number;
  deliveryFee: number;
  totalWithDelivery: number;
  profit: number;
  orderDate: string;
  createdAt: string;
}

export const OrdersPage = () => {
  const [selectedTrader, setSelectedTrader] = useState<Trader | null>(null);
  const [activeTab, setActiveTab] = useState('traders');
  const [viewedNotifications, setViewedNotifications] = useState<Set<string>>(new Set());
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // تحميل الإشعارات المشاهدة من localStorage
  useEffect(() => {
    const saved = localStorage.getItem('viewedTraderNotifications');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setViewedNotifications(new Set(parsed));
      } catch (error) {
        console.error('خطأ في تحليل الإشعارات المحفوظة:', error);
      }
    }
  }, []);

  // حفظ الإشعارات المشاهدة في localStorage
  const saveViewedNotifications = (notifications: Set<string>) => {
    try {
      const notificationsArray: string[] = [];
      notifications.forEach(notification => notificationsArray.push(notification));
      localStorage.setItem('viewedTraderNotifications', JSON.stringify(notificationsArray));
      setViewedNotifications(notifications);
    } catch (error) {
      console.error('خطأ في حفظ الإشعارات:', error);
    }
  };

  // جلب جميع الطلبات
  const { data: orders = [], isLoading } = useQuery({
    queryKey: ['/api/orders'],
    queryFn: async () => {
      const response = await fetch('/api/orders');
      if (!response.ok) throw new Error('فشل في جلب الطلبات');
      return response.json();
    }
  });

  // إنشاء قائمة التجار - صلاح هو التاجر الوحيد وجميع الطلبات له
  const salahPhone = '07863620710';
  const isTraderViewed = viewedNotifications.has(salahPhone);
  
  // جميع الطلبات تعتبر للتاجر صلاح (سواء كانت بأسماء علي أو صلاح أو محمد إلخ)
  const salahOrders = orders; // جميع الطلبات
  
  const traders: Trader[] = salahOrders.length > 0 ? [{
    name: 'صلاح',
    phone: salahPhone,
    ordersCount: salahOrders.length,
    totalAmount: salahOrders.reduce((sum: number, order: Order) => sum + (parseInt(order.total) || 0), 0),
    lastOrderDate: salahOrders.length > 0 ? new Date(Math.max(...salahOrders.map((o: Order) => new Date(o.createdAt).getTime()))).toISOString() : new Date().toISOString(),
    hasNewOrders: !isTraderViewed && salahOrders.some((order: Order) => new Date(order.createdAt).getTime() > Date.now() - (24 * 60 * 60 * 1000)),
    newOrdersCount: !isTraderViewed ? salahOrders.filter((order: Order) => new Date(order.createdAt).getTime() > Date.now() - (24 * 60 * 60 * 1000)).length : 0,
    customers: []
  }] : [];
  
  // تجميع العملاء لعرضهم في تفاصيل الطلبات (للعرض فقط)
  const customers: Customer[] = orders.reduce((acc: Customer[], order: Order) => {
    const customerPhone = order.customerDetails?.phone;
    const customerName = order.customerDetails?.name;
    
    if (!customerPhone || !customerName) return acc;
    
    const existingCustomer = acc.find(c => c.phone === customerPhone);
    const isNewOrder = new Date(order.createdAt).getTime() > Date.now() - (24 * 60 * 60 * 1000);
    const isViewed = viewedNotifications.has(customerPhone);
    
    if (existingCustomer) {
      existingCustomer.ordersCount += 1;
      existingCustomer.totalAmount += parseInt(order.total) || 0;
      if (new Date(order.createdAt) > new Date(existingCustomer.lastOrderDate)) {
        existingCustomer.lastOrderDate = order.createdAt;
      }
      if (isNewOrder && !isViewed) {
        existingCustomer.hasNewOrders = true;
        existingCustomer.newOrdersCount += 1;
      }
    } else {
      acc.push({
        name: customerName,
        phone: customerPhone,
        ordersCount: 1,
        totalAmount: parseInt(order.total) || 0,
        lastOrderDate: order.createdAt,
        hasNewOrders: isNewOrder && !isViewed,
        newOrdersCount: (isNewOrder && !isViewed) ? 1 : 0
      });
    }
    
    return acc;
  }, []);

  // ترتيب العملاء: الذين لديهم طلبات جديدة أولاً
  customers.sort((a, b) => {
    if (a.hasNewOrders && !b.hasNewOrders) return -1;
    if (!a.hasNewOrders && b.hasNewOrders) return 1;
    return new Date(b.lastOrderDate).getTime() - new Date(a.lastOrderDate).getTime();
  });

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('ar-EG', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // استخدام دالة formatCurrency من ملف formatters لتنسيق الأرقام باللغة الإنجليزية

  // معالجة تحديث حالة الطلب
  const updateOrderStatus = useMutation({
    mutationFn: async ({ orderId, status }: { orderId: number, status: string }) => {
      const response = await fetch(`/api/orders/${orderId}/status`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status }),
      });
      
      if (!response.ok) {
        throw new Error('فشل في تحديث حالة الطلب');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/orders'] });
      toast({
        title: "تم التحديث",
        description: "تم تحديث حالة الطلب بنجاح",
      });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "فشل في تحديث حالة الطلب",
        variant: "destructive",
      });
    },
  });

  const handleStatusChange = (orderId: number, status: string) => {
    updateOrderStatus.mutate({ orderId, status });
  };

  const handleTraderClick = (trader: Trader) => {
    // إضافة التاجر إلى قائمة المُشاهد لإخفاء الإشعارات
    const newViewed = new Set(viewedNotifications);
    newViewed.add(trader.phone);
    saveViewedNotifications(newViewed);
    
    setSelectedTrader(trader);
    setActiveTab('orders');
  };



  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg p-6">
        <h1 className="text-3xl font-bold text-white mb-2">إدارة الطلبات والتجار</h1>
        <p className="text-blue-100">متابعة وإدارة التجار وطلباتهم</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="traders" className="flex items-center gap-2">
            <Store className="w-4 h-4" />
            إدارة التجار
            {traders.filter(t => t.hasNewOrders).length > 0 && (
              <Badge variant="destructive" className="ml-1">
                {traders.filter(t => t.hasNewOrders).length}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="orders" className="flex items-center gap-2">
            <Package className="w-4 h-4" />
            الطلبات
          </TabsTrigger>
        </TabsList>

        <TabsContent value="traders" className="space-y-4">
          {isLoading ? (
            <div className="flex items-center justify-center h-64">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : (
            <>
              <div className="mb-6">
                <h2 className="text-xl font-bold text-gray-900 mb-2">قائمة التجار</h2>
                <p className="text-gray-600">إجمالي التجار: {traders.length}</p>
              </div>

              <div className="grid gap-4">
                {traders.map((trader) => (
                  <Card 
                    key={trader.phone}
                    className={`cursor-pointer hover:shadow-lg transition-all border-r-4 ${
                      trader.hasNewOrders 
                        ? 'border-red-500 bg-red-50/30 animate-pulse' 
                        : 'border-blue-500'
                    }`}
                    onClick={() => handleTraderClick(trader)}
                  >
                    <CardContent className="p-3">
                      <div className="flex items-center justify-between gap-3">
                        <div className="flex items-center gap-3 flex-1 min-w-0">
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                            trader.hasNewOrders ? 'bg-red-100' : 'bg-blue-100'
                          }`}>
                            <Store className={`w-5 h-5 ${
                              trader.hasNewOrders ? 'text-red-600' : 'text-blue-600'
                            }`} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <h3 className="font-bold text-base truncate">{trader.name}</h3>
                              {trader.hasNewOrders && (
                                <Badge variant="destructive" className="text-xs">
                                  {trader.newOrdersCount} جديد
                                </Badge>
                              )}
                            </div>
                            <div className="flex items-center gap-1 text-gray-600 text-sm">
                              <Phone className="w-3 h-3" />
                              <span className="truncate">{trader.phone}</span>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-2 flex-shrink-0">
                          <div className="text-center bg-blue-50 rounded px-2 py-1">
                            <div className="text-sm font-bold text-blue-600">{trader.ordersCount}</div>
                            <div className="text-xs text-gray-500">طلب</div>
                          </div>
                          <div className="text-center bg-green-50 rounded px-2 py-1">
                            <div className="text-xs font-bold text-green-600">{formatCurrency(trader.totalAmount)}</div>
                            <div className="text-xs text-gray-500">د.ع</div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
                
                {traders.length === 0 && (
                  <Card>
                    <CardContent className="p-8 text-center">
                      <Store className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-500 mb-2">لا يوجد تجار</h3>
                      <p className="text-gray-400">لم يتم العثور على أي تجار بعد</p>
                    </CardContent>
                  </Card>
                )}
              </div>
            </>
          )}
        </TabsContent>



        <TabsContent value="orders" className="space-y-4">
          {selectedTrader ? (
            <>
              <div className="flex items-center gap-4 mb-6">
                <Button
                  onClick={() => {
                    setSelectedTrader(null);
                    setActiveTab('traders');
                  }}
                  variant="outline"
                  className="flex items-center gap-2"
                >
                  <ArrowRight className="w-4 h-4" />
                  العودة إلى التجار
                </Button>
                
                <Card className="flex-1 bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                          <Store className="w-6 h-6 text-blue-600" />
                        </div>
                        <div>
                          <h3 className="font-bold text-lg text-gray-900">{selectedTrader.name}</h3>
                          <div className="flex items-center gap-2 text-gray-600">
                            <Phone className="w-4 h-4" />
                            <span>{selectedTrader.phone}</span>
                          </div>
                        </div>
                      </div>
                      <div className="text-right space-y-2">
                        <div className="bg-blue-50 rounded-lg p-3">
                          <div className="text-xs text-gray-500">إجمالي الطلبات</div>
                          <div className="font-bold text-lg text-blue-600">{selectedTrader.ordersCount}</div>
                        </div>
                        <div className="bg-green-50 rounded-lg p-3">
                          <div className="text-xs text-gray-500">إجمالي المبيعات</div>
                          <div className="font-bold text-lg text-green-600">{formatCurrency(selectedTrader.totalAmount)} د.ع</div>
                        </div>
                        <div className="bg-purple-50 rounded-lg p-3">
                          <div className="text-xs text-gray-500">إجمالي الأرباح</div>
                          <div className="font-bold text-lg text-purple-600">{formatCurrency(orders.reduce((sum: number, order: Order) => sum + (order.profit || 0), 0))} د.ع</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="bg-white rounded-lg border border-gray-200 p-4 md:p-6">
                <div className="flex flex-col md:flex-row md:items-center gap-3 mb-6">
                  <div className="flex items-center gap-3">
                    <Package className="w-6 h-6 text-blue-600" />
                    <h2 className="text-lg md:text-xl font-bold text-gray-900">طلبات التاجر {selectedTrader.name}</h2>
                  </div>
                  <div className="flex-1"></div>
                  <div className="text-center md:text-right bg-blue-50 rounded-lg p-3">
                    <div className="text-xl md:text-2xl font-bold text-blue-600">{salahOrders.length}</div>
                    <div className="text-xs md:text-sm text-gray-600">إجمالي الطلبات</div>
                  </div>
                </div>

                <div className="space-y-3">
                  {salahOrders.map((order: Order) => (
                    <Card key={order.id} className="border-l-4 border-blue-500 hover:shadow-md transition-all duration-200">
                      <CardContent className="p-4">
                        {/* رأس الطلب */}
                        <div className="flex flex-col md:flex-row md:items-start justify-between gap-3 mb-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                              <Package className="w-5 h-5 text-blue-600" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <h3 className="font-bold text-base md:text-lg text-gray-900 truncate">طلب #{order.id}</h3>
                              <div className="flex flex-col sm:flex-row sm:items-center gap-2 mt-1">
                                <div className="flex items-center gap-2">
                                  <Select
                                    value={order.status}
                                    onValueChange={(newStatus) => updateOrderStatus.mutate({ orderId: order.id, status: newStatus })}
                                    disabled={updateOrderStatus.isPending}
                                  >
                                    <SelectTrigger className="w-32 h-7 text-xs">
                                      <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="pending">قيد الانتظار</SelectItem>
                                      <SelectItem value="processing">قيد المعالجة</SelectItem>
                                      <SelectItem value="completed">مكتمل</SelectItem>
                                      <SelectItem value="cancelled">ملغي</SelectItem>
                                    </SelectContent>
                                  </Select>
                                  <Edit className="w-3 h-3 text-gray-400" />
                                </div>
                                <div className="flex items-center gap-1 text-xs text-gray-500">
                                  <Clock className="w-3 h-3" />
                                  <span>{formatDate(order.createdAt)}</span>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="text-center md:text-right bg-green-50 rounded-lg p-2 min-w-0">
                            <div className="text-lg md:text-xl font-bold text-green-600">{formatCurrency(parseInt(order.total))}</div>
                            <div className="text-xs text-gray-500">د.ع</div>
                          </div>
                        </div>

                        {/* معلومات العميل */}
                        <div className="bg-gray-50 rounded-lg p-3 mb-3">
                          <div className="flex items-center gap-2 mb-2">
                            <User className="w-4 h-4 text-gray-600" />
                            <span className="font-medium text-sm text-gray-900">{order.customerDetails.name}</span>
                          </div>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-gray-600">
                            <div className="flex items-center gap-2">
                              <Phone className="w-3 h-3" />
                              <span>{order.customerDetails.phone}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <MapPin className="w-3 h-3" />
                              <span>{order.customerDetails.governorate} - {order.customerDetails.area}</span>
                            </div>
                          </div>
                          <div className="text-xs text-gray-600 mt-2">
                            <span className="font-medium">العنوان:</span> {order.customerDetails.address}
                          </div>
                          {order.customerDetails.notes && (
                            <div className="text-xs text-gray-600 mt-1">
                              <span className="font-medium">ملاحظات:</span> {order.customerDetails.notes}
                            </div>
                          )}
                        </div>

                        {/* تفاصيل المنتجات */}
                        <div className="space-y-2">
                          {order.items.map((item, index) => (
                            <div key={index} className="flex items-center justify-between p-2 bg-white rounded border text-sm">
                              <div className="flex-1 min-w-0">
                                <div className="font-medium text-gray-900 truncate">{item.product.name}</div>
                                <div className="text-xs text-gray-500">الكمية: {item.quantity}</div>
                              </div>
                              <div className="text-right pl-2">
                                <div className="font-bold text-green-600">{formatCurrency(item.product.price)}</div>
                                <div className="text-xs text-gray-500">د.ع</div>
                              </div>
                            </div>
                          ))}
                          
                          {/* ملخص الأسعار */}
                          <div className="border-t pt-2 space-y-1 text-sm">
                            <div className="flex justify-between">
                              <span className="text-gray-600">سعر المنتجات:</span>
                              <span className="font-medium">{formatCurrency(order.customerPrice)} د.ع</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600">رسوم التوصيل:</span>
                              <span className="font-medium">{formatCurrency(order.deliveryFee)} د.ع</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600">ربح التاجر:</span>
                              <span className="font-medium text-purple-600">{formatCurrency(order.profit || 0)} د.ع</span>
                            </div>
                            <div className="flex justify-between font-bold text-base border-t pt-2">
                              <span>الإجمالي:</span>
                              <span className="text-green-600">{formatCurrency(order.totalWithDelivery)} د.ع</span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                  
                  {orders.length === 0 && (
                    <Card className="border-2 border-dashed border-gray-300">
                      <CardContent className="p-12 text-center">
                        <Package className="w-20 h-20 text-gray-400 mx-auto mb-4" />
                        <h3 className="text-xl font-medium text-gray-500 mb-2">لا توجد طلبات</h3>
                        <p className="text-gray-400">لم يتم العثور على أي طلبات للتاجر {selectedTrader.name}</p>
                      </CardContent>
                    </Card>
                  )}
                </div>
              </div>
            </>
          ) : (
            <>
              <div className="bg-white rounded-lg border border-gray-200 p-4 md:p-6">
                <div className="flex flex-col md:flex-row md:items-center gap-3 mb-6">
                  <div className="flex items-center gap-3">
                    <Package className="w-6 h-6 text-blue-600" />
                    <h2 className="text-lg md:text-xl font-bold text-gray-900">جميع الطلبات</h2>
                  </div>
                  <div className="flex-1"></div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-4">
                    <div className="bg-blue-50 rounded-lg p-2 md:p-3 text-center">
                      <div className="text-lg md:text-xl font-bold text-blue-600">{orders.length}</div>
                      <div className="text-xs text-gray-600">إجمالي</div>
                    </div>
                    <div className="bg-green-50 rounded-lg p-2 md:p-3 text-center">
                      <div className="text-lg md:text-xl font-bold text-green-600">{orders.filter((o: Order) => o.status === 'pending').length}</div>
                      <div className="text-xs text-gray-600">معلقة</div>
                    </div>
                    <div className="bg-orange-50 rounded-lg p-2 md:p-3 text-center">
                      <div className="text-lg md:text-xl font-bold text-orange-600">{orders.filter((o: Order) => o.status === 'processing').length}</div>
                      <div className="text-xs text-gray-600">معالجة</div>
                    </div>
                    <div className="bg-purple-50 rounded-lg p-2 md:p-3 text-center">
                      <div className="text-sm md:text-lg font-bold text-purple-600">{formatCurrency(orders.reduce((sum: number, o: Order) => sum + parseInt(o.total), 0))}</div>
                      <div className="text-xs text-gray-600">د.ع</div>
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  {orders.map((order: Order) => (
                    <Card key={order.id} className="border-l-4 border-green-500 hover:shadow-md transition-all duration-200">
                      <CardContent className="p-4">
                        {/* رأس الطلب */}
                        <div className="flex flex-col md:flex-row md:items-start justify-between gap-3 mb-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                              <Package className="w-5 h-5 text-green-600" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <h3 className="font-bold text-base md:text-lg text-gray-900 truncate">طلب #{order.id}</h3>
                              <div className="flex flex-col sm:flex-row sm:items-center gap-2 mt-1">
                                <div className="flex items-center gap-2">
                                  <Select
                                    value={order.status}
                                    onValueChange={(newStatus) => updateOrderStatus.mutate({ orderId: order.id, status: newStatus })}
                                    disabled={updateOrderStatus.isPending}
                                  >
                                    <SelectTrigger className="w-32 h-7 text-xs">
                                      <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="pending">قيد الانتظار</SelectItem>
                                      <SelectItem value="processing">قيد المعالجة</SelectItem>
                                      <SelectItem value="completed">مكتمل</SelectItem>
                                      <SelectItem value="cancelled">ملغي</SelectItem>
                                    </SelectContent>
                                  </Select>
                                  <Edit className="w-3 h-3 text-gray-400" />
                                </div>
                                <div className="flex items-center gap-1 text-xs text-gray-500">
                                  <Clock className="w-3 h-3" />
                                  <span>{formatDate(order.createdAt)}</span>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="text-center md:text-right bg-green-50 rounded-lg p-2 min-w-0">
                            <div className="text-lg md:text-xl font-bold text-green-600">{formatCurrency(parseInt(order.total))}</div>
                            <div className="text-xs text-gray-500">د.ع</div>
                          </div>
                        </div>

                        {/* معلومات العميل */}
                        <div className="bg-gray-50 rounded-lg p-3 mb-3">
                          <div className="flex items-center gap-2 mb-2">
                            <User className="w-4 h-4 text-gray-600" />
                            <span className="font-medium text-sm text-gray-900">{order.customerDetails.name}</span>
                          </div>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-gray-600">
                            <div className="flex items-center gap-2">
                              <Phone className="w-3 h-3" />
                              <span>{order.customerDetails.phone}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <MapPin className="w-3 h-3" />
                              <span>{order.customerDetails.governorate} - {order.customerDetails.area}</span>
                            </div>
                          </div>
                          <div className="text-xs text-gray-600 mt-2">
                            <span className="font-medium">العنوان:</span> {order.customerDetails.address}
                          </div>
                          {order.customerDetails.notes && (
                            <div className="text-xs text-gray-600 mt-1">
                              <span className="font-medium">ملاحظات:</span> {order.customerDetails.notes}
                            </div>
                          )}
                        </div>

                        {/* تفاصيل المنتجات */}
                        <div className="space-y-2">
                          {order.items.map((item, index) => (
                            <div key={index} className="flex items-center justify-between p-2 bg-white rounded border text-sm">
                              <div className="flex-1 min-w-0">
                                <div className="font-medium text-gray-900 truncate">{item.product.name}</div>
                                <div className="text-xs text-gray-500">الكمية: {item.quantity}</div>
                              </div>
                              <div className="text-right pl-2">
                                <div className="font-bold text-green-600">{formatCurrency(item.product.price)}</div>
                                <div className="text-xs text-gray-500">د.ع</div>
                              </div>
                            </div>
                          ))}
                          
                          {/* ملخص الأسعار */}
                          <div className="border-t pt-2 space-y-1 text-sm">
                            <div className="flex justify-between">
                              <span className="text-gray-600">سعر المنتجات:</span>
                              <span className="font-medium">{formatCurrency(order.customerPrice)} د.ع</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600">رسوم التوصيل:</span>
                              <span className="font-medium">{formatCurrency(order.deliveryFee)} د.ع</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600">ربح التاجر:</span>
                              <span className="font-medium text-purple-600">{formatCurrency(order.profit || 0)} د.ع</span>
                            </div>
                            <div className="flex justify-between font-bold text-base border-t pt-2">
                              <span>الإجمالي:</span>
                              <span className="text-green-600">{formatCurrency(order.totalWithDelivery)} د.ع</span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                  
                  {orders.length === 0 && (
                    <Card className="border-2 border-dashed border-gray-300">
                      <CardContent className="p-8 md:p-12 text-center">
                        <Package className="w-16 md:w-20 h-16 md:h-20 text-gray-400 mx-auto mb-4" />
                        <h3 className="text-lg md:text-xl font-medium text-gray-500 mb-2">لا توجد طلبات</h3>
                        <p className="text-sm md:text-base text-gray-400">لم يتم العثور على أي طلبات في النظام</p>
                      </CardContent>
                    </Card>
                  )}
                </div>
              </div>
            </>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};