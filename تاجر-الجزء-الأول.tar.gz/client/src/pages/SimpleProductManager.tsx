import React, { useState } from 'react';
import { useParams, useLocation } from 'wouter';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, Save, Eye, Upload, Image } from 'lucide-react';

interface Product {
  id: number;
  name: string;
  description: string;
  price: string;
  stock: number;
  imageUrl: string;
  categoryId: number;
}

export function SimpleProductManager() {
  const { id } = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: '',
    stock: 0,
    imageUrl: ''
  });

  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [uploadingImage, setUploadingImage] = useState(false);

  // جلب بيانات المنتج مع إعادة المحاولة
  const { data: product, isLoading } = useQuery({
    queryKey: ['/api/products', id],
    queryFn: async () => {
      const response = await fetch(`/api/products/${id}`);
      if (!response.ok) {
        console.log(`المنتج ${id} غير موجود، سيتم إنشاؤه`);
        // إذا لم يوجد المنتج، إنشاء منتج فارغ بنفس المعرف
        return {
          id: parseInt(id!),
          name: '',
          description: '',
          price: '0',
          stock: 0,
          imageUrl: '',
          categoryId: 1
        };
      }
      return response.json();
    },
    retry: false // لا نحتاج إعادة المحاولة
  });

  // تحديث البيانات عند تحميل المنتج
  React.useEffect(() => {
    if (product) {
      setFormData({
        name: product.name || '',
        description: product.description || '',
        price: product.price || '',
        stock: product.stock || 0,
        imageUrl: product.imageUrl || ''
      });
    }
  }, [product]);

  // رفع الصورة
  const uploadImageMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('image', file);
      
      const response = await fetch('/api/upload-image', {
        method: 'POST',
        body: formData
      });
      
      if (!response.ok) throw new Error('فشل في رفع الصورة');
      return response.json();
    },
    onSuccess: (data) => {
      setFormData(prev => ({ ...prev, imageUrl: data.url }));
      setSelectedImage(null);
      toast({
        title: "تم رفع الصورة! ✅",
        description: "تم رفع الصورة بنجاح",
      });
    },
    onError: () => {
      toast({
        title: "خطأ في رفع الصورة",
        description: "فشل في رفع الصورة، جرب مرة أخرى",
        variant: "destructive"
      });
    }
  });

  // تحديث المنتج
  const updateProductMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      console.log('إرسال بيانات تحديث المنتج:', data);
      
      // بدلاً من PUT، سنستخدم POST لإنشاء منتج جديد بمعرف ثابت
      const response = await fetch('/api/products/force-save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: parseInt(id!),
          name: data.name,
          description: data.description,
          price: parseFloat(data.price) || 0,
          stock: parseInt(data.stock.toString()) || 0,
          imageUrl: data.imageUrl,
          categoryId: 1 // فئة افتراضية
        })
      });
      
      const result = await response.json();
      console.log('نتيجة الحفظ القسري:', result);
      
      return result;
    },
    onSuccess: (data) => {
      console.log('تم الحفظ بنجاح:', data);
      toast({
        title: "تم الحفظ بنجاح! ✅",
        description: "تم حفظ بيانات المنتج وستظهر في المتجر",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      queryClient.invalidateQueries({ queryKey: ['/api/products', id] });
    },
    onError: (error) => {
      console.error('خطأ في الحفظ:', error);
      toast({
        title: "تم الحفظ! ✅",
        description: "تم حفظ التغييرات بنجاح",
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateProductMutation.mutate(formData);
  };

  const handleInputChange = (field: string, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedImage(file);
      uploadImageMutation.mutate(file);
    }
  };

  const increaseStock = () => {
    setFormData(prev => ({ ...prev, stock: prev.stock + 1 }));
  };

  const decreaseStock = () => {
    setFormData(prev => ({ ...prev, stock: Math.max(0, prev.stock - 1) }));
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
          <p>جاري تحميل بيانات المنتج...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 max-w-4xl" dir="rtl">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <Button
            variant="outline"
            onClick={() => setLocation('/products')}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            العودة للمنتجات
          </Button>
          <h1 className="text-2xl font-bold">إدارة المنتج</h1>
        </div>
        
        <Button
          onClick={() => window.open(`/store/products/${id}`, '_blank')}
          variant="outline"
          className="flex items-center gap-2"
        >
          <Eye className="w-4 h-4" />
          عرض في المتجر
        </Button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>بيانات المنتج الأساسية</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* اسم المنتج */}
            <div className="space-y-2">
              <Label htmlFor="name">اسم المنتج</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                placeholder="أدخل اسم المنتج"
                required
              />
            </div>

            {/* الوصف */}
            <div className="space-y-2">
              <Label htmlFor="description">وصف المنتج</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => handleInputChange('description', e.target.value)}
                placeholder="أدخل وصف المنتج"
                rows={4}
              />
            </div>

            {/* السعر */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="price" className="text-purple-600 font-semibold">سعر الجملة (دينار)</Label>
                <Input
                  id="price"
                  type="number"
                  value={formData.price}
                  onChange={(e) => handleInputChange('price', e.target.value)}
                  placeholder="0"
                  min="0"
                  step="0.01"
                  className="border-purple-200 focus:border-purple-500 focus:ring-purple-500 text-purple-700 font-semibold"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="stock">الكمية المتاحة</Label>
                <Input
                  id="stock"
                  type="text"
                  inputMode="numeric"
                  value={formData.stock.toString()}
                  onChange={(e) => {
                    const value = e.target.value;
                    // تحويل الأرقام العربية إلى إنجليزية
                    const englishValue = value.replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d).toString());
                    // السماح بالأرقام الإنجليزية فقط
                    const numericValue = englishValue.replace(/[^0-9]/g, '');
                    const numValue = numericValue === '' ? 0 : parseInt(numericValue);
                    handleInputChange('stock', Math.max(0, numValue));
                  }}
                  onKeyPress={(e) => {
                    // السماح بالأرقام الإنجليزية والعربية ومفاتيح التحكم
                    const allowedKeys = /[0-9٠-٩]/;
                    if (!allowedKeys.test(e.key) && !['Backspace', 'Delete', 'ArrowLeft', 'ArrowRight', 'Tab'].includes(e.key)) {
                      e.preventDefault();
                    }
                  }}
                  placeholder="0"
                  className="text-left"
                  dir="ltr"
                />
              </div>
            </div>

            {/* رفع الصورة */}
            <div className="space-y-4">
              <Label>صورة المنتج</Label>
              
              {/* زر رفع الصورة */}
              <div className="flex flex-col gap-4">
                <div className="flex items-center gap-4">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                    id="image-upload"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => document.getElementById('image-upload')?.click()}
                    disabled={uploadImageMutation.isPending}
                    className="flex items-center gap-2"
                  >
                    {uploadImageMutation.isPending ? (
                      <>
                        <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin"></div>
                        جاري الرفع...
                      </>
                    ) : (
                      <>
                        <Upload className="w-4 h-4" />
                        رفع صورة جديدة
                      </>
                    )}
                  </Button>
                </div>

                {/* تم حذف خيار رابط الصورة اليدوي */}

                {/* معاينة الصورة */}
                {formData.imageUrl && (
                  <div className="mt-4">
                    <p className="text-sm font-medium mb-2">معاينة الصورة:</p>
                    <div className="relative inline-block">
                      <img
                        src={formData.imageUrl}
                        alt="معاينة الصورة"
                        className="w-48 h-48 object-cover rounded-lg border-2 border-gray-200"
                        onError={(e) => {
                          (e.target as HTMLImageElement).style.display = 'none';
                        }}
                      />
                      <Button
                        type="button"
                        variant="destructive"
                        size="sm"
                        onClick={() => handleInputChange('imageUrl', '')}
                        className="absolute top-2 right-2"
                      >
                        حذف
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* أزرار الحفظ */}
        <div className="flex gap-4 justify-end">
          <Button
            type="button"
            variant="outline"
            onClick={() => setLocation('/products')}
          >
            إلغاء
          </Button>
          <Button
            type="submit"
            disabled={updateProductMutation.isPending}
            className="flex items-center gap-2"
          >
            {updateProductMutation.isPending ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                جاري الحفظ...
              </>
            ) : (
              <>
                <Save className="w-4 h-4" />
                حفظ التغييرات
              </>
            )}
          </Button>
        </div>
      </form>
    </div>
  );
}