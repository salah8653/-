import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowRight, CreditCard, Smartphone } from "lucide-react";

export const WithdrawPage = () => {
  const [, setLocation] = useLocation();

  const withdrawMethods = [
    {
      id: 'zain-cash',
      title: 'زين كاش',
      description: 'سحب الأرباح عبر زين كاش',
      icon: <Smartphone className="w-8 h-8 text-purple-600" />,
      route: '/withdraw/zain-cash'
    },
    {
      id: 'mastercard',
      title: 'ماستر كارد الرافدين',
      description: 'سحب الأرباح عبر ماستر كارد الرافدين',
      icon: <CreditCard className="w-8 h-8 text-purple-600" />,
      route: '/withdraw/mastercard'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-md mx-auto">
        {/* Header */}
        <div className="flex items-center mb-6">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLocation("/profile")}
            className="p-2"
          >
            <ArrowRight className="w-5 h-5" />
          </Button>
          <h1 className="text-xl font-bold text-gray-900 mr-3">
            سحب الأرباح
          </h1>
        </div>

        {/* Instructions */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <h3 className="font-semibold text-gray-900 mb-2">اختر طريقة السحب</h3>
            <p className="text-sm text-gray-600">
              ستصل أرباحك خلال يومين
            </p>
          </CardContent>
        </Card>

        {/* Withdraw Methods */}
        <div className="space-y-3">
          {withdrawMethods.map((method) => (
            <Card key={method.id} className="hover:shadow-md transition-shadow cursor-pointer">
              <CardContent className="p-0">
                <Button
                  variant="ghost"
                  className="w-full h-auto p-4 justify-start"
                  onClick={() => setLocation(method.route)}
                >
                  <div className="flex items-center gap-4 w-full">
                    <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                      {method.icon}
                    </div>
                    
                    <div className="flex-1 text-right">
                      <div className="font-semibold text-gray-900">
                        {method.title}
                      </div>
                      <div className="text-sm text-gray-500">
                        {method.description}
                      </div>
                    </div>
                    
                    <ArrowRight className="w-5 h-5 text-gray-400 transform rotate-180" />
                  </div>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>


      </div>
    </div>
  );
};