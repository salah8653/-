import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Users, Phone, MapPin, ShoppingBag, Search } from 'lucide-react';
import { useState } from 'react';
import { formatCurrency, getOrderStatus, getOrderStatusColor } from './utils/formatters';

export const CustomersPage = () => {
  const [searchTerm, setSearchTerm] = useState('');

  const { data: customers = [], isLoading } = useQuery({
    queryKey: ['/api/customers'],
  });

  const { data: orders = [] } = useQuery({
    queryKey: ['/api/orders'],
  });

  // تصفية العملاء حسب البحث
  const filteredCustomers = Array.isArray(customers) ? customers.filter((customer: any) =>
    customer.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.phone?.includes(searchTerm)
  ) : [];

  // حساب عدد الطلبات لكل عميل
  const getCustomerOrdersCount = (customerId: number) => {
    return Array.isArray(orders) ? orders.filter((order: any) => order.customerId === customerId).length : 0;
  };

  // حساب إجمالي المشتريات للعميل
  const getCustomerTotalSpent = (customerId: number) => {
    const customerOrders = Array.isArray(orders) ? orders.filter((order: any) => order.customerId === customerId) : [];
    return customerOrders.reduce((total: number, order: any) => total + (order.total || 0), 0);
  };

  if (isLoading) {
    return (
      <div className="space-y-8">
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">إدارة العملاء</h1>
          <p className="text-slate-600">جاري تحميل بيانات العملاء...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
            <Users className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2">إدارة العملاء</h1>
            <p className="text-slate-600">قائمة بجميع عملاء المتجر وتفاصيل مشترياتهم</p>
          </div>
        </div>

        {/* شريط البحث */}
        <div className="relative">
          <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
          <Input
            placeholder="البحث عن عميل بالاسم أو رقم الهاتف..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pr-10"
          />
        </div>
      </div>

      {/* إحصائيات العملاء */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600">إجمالي العملاء</p>
                <p className="text-2xl font-bold text-slate-900">{customers.length}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Users className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600">العملاء النشطين</p>
                <p className="text-2xl font-bold text-slate-900">
                  {customers.filter((customer: any) => getCustomerOrdersCount(customer.id) > 0).length}
                </p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <ShoppingBag className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600">متوسط الطلبات للعميل</p>
                <p className="text-2xl font-bold text-slate-900">
                  {customers.length > 0 ? Math.round(orders.length / customers.length) : 0}
                </p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <ShoppingBag className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* قائمة العملاء */}
      <Card>
        <CardHeader>
          <CardTitle>قائمة العملاء</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredCustomers.length === 0 ? (
            <div className="text-center py-8">
              <Users className="w-12 h-12 text-slate-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-slate-900 mb-2">لا توجد عملاء</h3>
              <p className="text-slate-600">
                {searchTerm ? 'لم يتم العثور على عملاء مطابقين للبحث' : 'لم يتم إضافة أي عملاء بعد'}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredCustomers.map((customer: any) => (
                <div key={customer.id} className="border border-slate-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h3 className="font-semibold text-slate-900 mb-1">{customer.name}</h3>
                      <div className="flex items-center gap-1 text-sm text-slate-600 mb-1">
                        <Phone className="w-3 h-3" />
                        <span>{customer.phone}</span>
                      </div>
                      {customer.address && (
                        <div className="flex items-center gap-1 text-sm text-slate-600">
                          <MapPin className="w-3 h-3" />
                          <span className="truncate">{customer.address}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="text-center p-2 bg-blue-50 rounded">
                      <div className="font-semibold text-blue-600">{getCustomerOrdersCount(customer.id)}</div>
                      <div className="text-blue-500">طلب</div>
                    </div>
                    <div className="text-center p-2 bg-green-50 rounded">
                      <div className="font-semibold text-green-600">{getCustomerTotalSpent(customer.id)} د.ع</div>
                      <div className="text-green-500">إجمالي المشتريات</div>
                    </div>
                  </div>

                  <div className="mt-3 flex gap-2">
                    <Button variant="outline" size="sm" className="flex-1">
                      عرض الطلبات
                    </Button>
                    <Button variant="outline" size="sm">
                      تعديل
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};