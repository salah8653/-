import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Phone, MessageSquare, Lock, ArrowRight, AlertTriangle, X } from 'lucide-react';
import { Link } from 'wouter';
import { z } from 'zod';
import { sendSMSVerification, verifyPhoneCode } from '@/lib/firebase-auth';
import type { ConfirmationResult } from 'firebase/auth';

// Schema for phone number step
const phoneSchema = z.object({
  phone: z.string().min(10, 'رقم الهاتف يجب أن يكون 10 أرقام على الأقل'),
  email: z.string().email("البريد الإلكتروني غير صحيح").min(1, "البريد الإلكتروني مطلوب"),
});

// Schema for verification code step
const codeSchema = z.object({
  code: z.string().length(6, 'رمز التحقق يجب أن يكون 6 أرقام'),
});

// Schema for new password step
const passwordSchema = z.object({
  password: z.string().min(6, 'كلمة المرور يجب أن تكون 6 أحرف على الأقل'),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "كلمتا المرور غير متطابقتان",
  path: ["confirmPassword"],
});

type PhoneFormData = z.infer<typeof phoneSchema>;
type CodeFormData = z.infer<typeof codeSchema>;
type PasswordFormData = z.infer<typeof passwordSchema>;

export const ForgotPasswordPage = () => {
  const [currentStep, setCurrentStep] = useState<'phone' | 'code' | 'password'>('phone');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [userInfo, setUserInfo] = useState({ fullName: '', email: '' });
  const [confirmationResult, setConfirmationResult] = useState<ConfirmationResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [codeNotification, setCodeNotification] = useState('');
  const [showWarning, setShowWarning] = useState(true);
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const phoneForm = useForm<PhoneFormData>({
    resolver: zodResolver(phoneSchema),
    defaultValues: { phone: '', email: '' },
  });

  const codeForm = useForm<CodeFormData>({
    resolver: zodResolver(codeSchema),
    defaultValues: { code: '' },
  });

  const passwordForm = useForm<PasswordFormData>({
    resolver: zodResolver(passwordSchema),
    defaultValues: { password: '', confirmPassword: '' },
  });

  const sendVerificationCode = async (data: PhoneFormData) => {
    setIsLoading(true);
    try {
      // إرسال طلب إلى الخادم للتحقق من المعلومات وإرسال رمز التحقق
      const response = await fetch('/api/auth/send-reset-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          phone: data.phone,
          email: data.email
        }),
      });

      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.message);
      }

      setPhoneNumber(data.phone);
      setUserInfo({ fullName: '', email: data.email });
      setCurrentStep('code');
      
      toast({
        title: "تم إرسال رمز التحقق",
        description: `تم إرسال رمز التحقق إلى رقم ${data.phone}`,
      });

      // عرض الكود في إشعار لمدة 15 ثانية
      if (result.code) {
        setCodeNotification(`رمز التحقق: ${result.code}`);
        setTimeout(() => {
          setCodeNotification('');
        }, 15000); // 15 ثانية
      }
      
    } catch (error: any) {
      toast({
        title: "خطأ في التحقق",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const verifyCode = async (data: CodeFormData) => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/auth/verify-reset-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone: phoneNumber, code: data.code }),
      });

      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.message);
      }

      setCurrentStep('password');
      
      toast({
        title: "تم التحقق بنجاح",
        description: "يمكنك الآن إدخال كلمة مرور جديدة",
      });
      
    } catch (error: any) {
      toast({
        title: "رمز التحقق غير صحيح",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const resetPassword = async (data: PasswordFormData) => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          phone: phoneNumber, 
          newPassword: data.password 
        }),
      });

      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.message);
      }

      toast({
        title: "تم تغيير كلمة المرور بنجاح",
        description: "يمكنك الآن تسجيل الدخول بكلمة المرور الجديدة",
      });

      // توجيه المستخدم لصفحة تسجيل الدخول
      setTimeout(() => {
        setLocation('/login');
      }, 2000);
      
    } catch (error: any) {
      toast({
        title: "خطأ في تغيير كلمة المرور",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold text-gray-900">
            استعادة كلمة المرور
          </CardTitle>
          <p className="text-gray-600 mt-2">
            {currentStep === 'phone' && 'أدخل رقم هاتفك لاستلام رمز التحقق'}
            {currentStep === 'code' && 'أدخل رمز التحقق المرسل إلى هاتفك'}
            {currentStep === 'password' && 'أدخل كلمة المرور الجديدة'}
          </p>
        </CardHeader>

        <CardContent>
          {/* مكون reCAPTCHA المطلوب لـ Firebase */}
          <div id="recaptcha-container"></div>
          

          
          {/* خطوة إدخال المعلومات */}
          {currentStep === 'phone' && (
            <Form {...phoneForm}>
              <form onSubmit={phoneForm.handleSubmit(sendVerificationCode)} className="space-y-4">
                <FormField
                  control={phoneForm.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-right block">رقم الهاتف *</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Phone className="absolute right-3 top-3 h-5 w-5 text-gray-400" />
                          <Input
                            {...field}
                            type="tel"
                            placeholder="07XXXXXXXX"
                            className="pr-10 text-right"
                            dir="rtl"
                          />
                        </div>
                      </FormControl>
                      <FormMessage className="text-right" />
                    </FormItem>
                  )}
                />

                <FormField
                  control={phoneForm.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-right block">البريد الإلكتروني *</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          type="email"
                          placeholder="example@email.com"
                          className="text-right"
                          dir="rtl"
                        />
                      </FormControl>
                      <FormMessage className="text-right" />
                    </FormItem>
                  )}
                />

                <p className="text-sm text-gray-600 text-right">
                  * رقم الهاتف والبريد الإلكتروني مطلوبان
                </p>

                <Button
                  type="submit"
                  className="w-full"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      جاري الإرسال...
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <MessageSquare className="w-4 h-4" />
                      إرسال رمز التحقق
                    </div>
                  )}
                </Button>
              </form>
            </Form>
          )}

          {/* إشعار الكود لمدة 15 ثانية */}
          {codeNotification && (
            <div className="mb-4 p-4 bg-green-100 border border-green-300 rounded-lg">
              <p className="text-green-800 text-center font-bold text-lg">
                {codeNotification}
              </p>
              <p className="text-green-600 text-center text-sm mt-1">
                سيختفي هذا الإشعار خلال 15 ثانية
              </p>
            </div>
          )}

          {/* خطوة التحقق من الرمز */}
          {currentStep === 'code' && (
            <Form {...codeForm}>
              <form onSubmit={codeForm.handleSubmit(verifyCode)} className="space-y-4">
                <FormField
                  control={codeForm.control}
                  name="code"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-right block">رمز التحقق</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          type="text"
                          placeholder="123456"
                          className="text-center text-2xl font-mono tracking-widest"
                          maxLength={6}
                        />
                      </FormControl>
                      <FormMessage className="text-right" />
                      <p className="text-sm text-gray-600 text-right mt-2">
                        تم إرسال رمز التحقق إلى {phoneNumber}
                      </p>
                    </FormItem>
                  )}
                />

                <Button
                  type="submit"
                  className="w-full"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      جاري التحقق...
                    </div>
                  ) : (
                    'تحقق من الرمز'
                  )}
                </Button>

                <Button
                  type="button"
                  variant="outline"
                  className="w-full"
                  onClick={() => setCurrentStep('phone')}
                >
                  العودة لتغيير رقم الهاتف
                </Button>
              </form>
            </Form>
          )}

          {/* خطوة إدخال كلمة مرور جديدة */}
          {currentStep === 'password' && (
            <Form {...passwordForm}>
              <form onSubmit={passwordForm.handleSubmit(resetPassword)} className="space-y-4">
                <FormField
                  control={passwordForm.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-right block">كلمة المرور الجديدة</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Lock className="absolute right-3 top-3 h-5 w-5 text-gray-400" />
                          <Input
                            {...field}
                            type="password"
                            placeholder="أدخل كلمة مرور جديدة"
                            className="pr-10 text-right"
                            dir="rtl"
                          />
                        </div>
                      </FormControl>
                      <FormMessage className="text-right" />
                    </FormItem>
                  )}
                />

                <FormField
                  control={passwordForm.control}
                  name="confirmPassword"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-right block">تأكيد كلمة المرور</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Lock className="absolute right-3 top-3 h-5 w-5 text-gray-400" />
                          <Input
                            {...field}
                            type="password"
                            placeholder="أعد إدخال كلمة المرور"
                            className="pr-10 text-right"
                            dir="rtl"
                          />
                        </div>
                      </FormControl>
                      <FormMessage className="text-right" />
                    </FormItem>
                  )}
                />

                <Button
                  type="submit"
                  className="w-full"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      جاري التحديث...
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <ArrowRight className="w-4 h-4" />
                      تحديث كلمة المرور
                    </div>
                  )}
                </Button>
              </form>
            </Form>
          )}

          <div className="mt-6 text-center">
            <Link href="/login" className="text-blue-600 hover:text-blue-800 text-sm">
              العودة لتسجيل الدخول
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};