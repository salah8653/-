import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Copy, ShoppingCart, ArrowRight, Package, Heart, Download } from "lucide-react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { FloatingNotification, useFloatingNotification } from "@/components/FloatingNotification";

interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  minPrice?: number;
  maxPrice?: number;
  stock: number;
  sku: string;
  imageUrl: string;
  categoryId: number;
  category?: {
    id: number;
    name: string;
  };
}

export const NewProductPage = () => {
  const [, params] = useRoute("/product/:id");
  const [, setLocation] = useLocation();
  const [isSaved, setIsSaved] = useState(false);
  const { toast } = useToast();
  const { notification, showNotification, hideNotification } = useFloatingNotification();

  // جلب بيانات المنتج
  const { data: product, isLoading } = useQuery<Product>({
    queryKey: ["/api/products", params?.id],
    queryFn: async () => {
      const response = await fetch(`/api/products/${params?.id}`);
      if (!response.ok) {
        throw new Error('فشل في جلب المنتج');
      }
      return response.json();
    },
    enabled: !!params?.id,
  });

  // التحقق من حفظ المنتج من localStorage
  useEffect(() => {
    if (product) {
      const saved = JSON.parse(localStorage.getItem('savedProducts') || '[]');
      const isProductSaved = saved.some((item: any) => item.id === product.id);
      setIsSaved(isProductSaved);
    }
  }, [product]);

  // وظائف السلة والمحفوظات  
  const addToCart = async (product: Product) => {
    try {
      const response = await fetch('/api/cart', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          productId: product.id,
          quantity: 1
        })
      });

      if (response.ok) {
        showNotification(`تم إضافة ${product.name} إلى السلة`, 'cart');
        // تحديث السلة في الواجهة
        window.dispatchEvent(new CustomEvent('cartUpdated'));
      } else {
        showNotification(`فشل في إضافة ${product.name} إلى السلة`, 'error');
      }
    } catch (error) {
      showNotification(`خطأ في إضافة المنتج إلى السلة`, 'error');
    }
  };

  const toggleSaveProduct = (product: Product) => {
    const saved = JSON.parse(localStorage.getItem('savedProducts') || '[]');
    const existingIndex = saved.findIndex((item: any) => item.id === product.id);
    
    if (existingIndex >= 0) {
      saved.splice(existingIndex, 1);
      setIsSaved(false);
      showNotification(`تم حذف ${product.name} من المحفوظات`, 'save');
    } else {
      saved.push({
        id: product.id,
        name: product.name,
        price: product.price,
        imageUrl: product.imageUrl,
        description: product.description
      });
      setIsSaved(true);
      showNotification(`تم حفظ ${product.name} في المحفوظات`, 'save');
    }
    
    localStorage.setItem('savedProducts', JSON.stringify(saved));
  };

  // إضافة إلى السلة
  const handleAddToCart = () => {
    if (product) {
      addToCart(product);
    }
  };

  // حفظ/إلغاء حفظ المنتج
  const handleToggleSave = () => {
    if (product) {
      toggleSaveProduct(product);
    }
  };

  const copyDescription = () => {
    if (product?.description) {
      navigator.clipboard.writeText(product.description);
      toast({
        title: "تم نسخ الوصف",
        description: "تم نسخ وصف المنتج إلى الحافظة",
      });
    }
  };

  // تحميل الصورة وحفظ البيانات في Firebase
  const downloadImage = async () => {
    if (product?.imageUrl) {
      try {
        // تسجيل عملية التحميل في Firebase
        await fetch('/api/analytics/download', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            productId: product.id,
            productName: product.name,
            action: 'image_download',
            timestamp: new Date().toISOString()
          })
        });

        const response = await fetch(product.imageUrl);
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `${product.name}.jpg`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
        
        toast({
          title: "تم تحميل الصورة",
          description: "تم حفظ صورة المنتج في هاتفك",
        });
      } catch (error) {
        toast({
          title: "فشل تحميل الصورة",
          description: "حدث خطأ أثناء تحميل الصورة",
          variant: "destructive",
        });
      }
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="text-center py-12">
        <Package className="w-16 h-16 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">المنتج غير موجود</h3>
        <Button onClick={() => setLocation("/")}>
          <ArrowRight className="w-4 h-4 ml-2" />
          العودة للصفحة الرئيسية
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm sticky top-0 z-10">
        <div className="flex items-center justify-between p-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLocation("/")}
          >
            <ArrowRight className="w-4 h-4" />
          </Button>
          
          <h1 className="text-lg font-semibold text-gray-900 truncate max-w-xs">
            {product.name}
          </h1>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={handleToggleSave}
            className="p-2"
          >
            <Heart className={`w-5 h-5 ${isSaved ? 'fill-purple-600 text-purple-600' : 'text-gray-400'}`} />
          </Button>
        </div>
      </div>

      <div className="p-4 space-y-4">
        {/* Product Image */}
        <Card>
          <CardContent className="p-0 relative">
            <div className="aspect-square bg-gray-100 rounded-lg overflow-hidden">
              {product.imageUrl ? (
                <img 
                  src={product.imageUrl} 
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Package className="w-16 h-16 text-gray-300" />
                </div>
              )}
            </div>
            {/* Download Button */}
            {product.imageUrl && (
              <Button
                onClick={downloadImage}
                className="absolute top-2 right-2 bg-black bg-opacity-50 hover:bg-opacity-70 text-white p-2 rounded-full"
                size="sm"
              >
                <Download className="w-4 h-4" />
              </Button>
            )}
          </CardContent>
        </Card>

        {/* Product Info */}
        <Card>
          <CardContent className="p-4">
            <div className="space-y-3">
              <div>
                <h2 className="text-xl font-bold text-gray-900 mb-2">{product.name}</h2>
                {product.category && (
                  <Badge variant="secondary" className="mb-2">
                    الفئة: {product.category.name}
                  </Badge>
                )}
              </div>

              <div className="flex items-center justify-between">
                <div className="flex flex-col">
                  {product.minPrice && product.maxPrice ? (
                    <div className="text-lg font-bold text-purple-600">
                      <span>الحد الأدنى: {parseFloat(product.minPrice.toString()).toLocaleString()} د.ع</span>
                      <br />
                      <span>الحد الأعلى: {parseFloat(product.maxPrice.toString()).toLocaleString()} د.ع</span>
                    </div>
                  ) : (
                    <span className="text-2xl font-bold text-purple-600">
                      {parseFloat(product.price.toString()).toLocaleString()} د.ع
                    </span>
                  )}
                </div>
                <div className="text-sm text-gray-500">
                  متبقية {product.stock} قطعة
                </div>
              </div>
            </div>
          </CardContent>
        </Card>



        {/* Description */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-gray-900">وصف المنتج</h3>
              <Button
                variant="outline"
                size="sm"
                onClick={copyDescription}
                className="flex items-center gap-2"
              >
                <Copy className="w-4 h-4" />
                نسخ
              </Button>
            </div>
            <p className="text-gray-600 leading-relaxed">
              {product.description}
            </p>
          </CardContent>
        </Card>


      </div>

      {/* Fixed Bottom Button */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t shadow-lg">
        <Button
          onClick={handleAddToCart}
          disabled={product.stock <= 0}
          className="w-full bg-purple-600 hover:bg-purple-700 text-white py-3 text-lg font-semibold"
        >
          <ShoppingCart className="w-5 h-5 ml-2" />
          إضافة إلى السلة
        </Button>
      </div>

      {/* Floating Notifications */}
      <FloatingNotification
        message={notification.message}
        type={notification.type}
        isVisible={notification.isVisible}
        onClose={hideNotification}
      />
    </div>
  );
};