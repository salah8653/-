import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Upload, Trash2, Edit, Plus, Image } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface Banner {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  isActive: boolean;
}

export function NewBannersPage() {
  const [banners, setBanners] = useState<Banner[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingBanner, setEditingBanner] = useState<Banner | null>(null);
  const [isAddingNew, setIsAddingNew] = useState(false);
  const { toast } = useToast();

  // حالة النموذج
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    imageUrl: "",
    isActive: true
  });

  // جلب البانرات
  useEffect(() => {
    fetchBanners();
  }, []);

  const fetchBanners = async () => {
    try {
      const response = await apiRequest("GET", "/api/banners");
      const data = await response.json();
      setBanners(data || []);
    } catch (error) {
      console.error("خطأ في جلب البانرات:", error);
      setBanners([]);
    } finally {
      setLoading(false);
    }
  };

  // إضافة بانر جديد
  const handleAddBanner = async () => {
    if (!formData.title.trim()) {
      toast({
        title: "خطأ",
        description: "يرجى إدخال عنوان البانر",
        variant: "destructive",
      });
      return;
    }

    try {
      const response = await apiRequest("POST", "/api/banners", formData);
      setBanners([...banners, response]);
      setFormData({ title: "", description: "", imageUrl: "", isActive: true });
      setIsAddingNew(false);
      toast({
        title: "نجح",
        description: "تم إضافة البانر بنجاح",
      });
    } catch (error) {
      toast({
        title: "خطأ",
        description: "فشل في إضافة البانر",
        variant: "destructive",
      });
    }
  };

  // تحديث بانر
  const handleUpdateBanner = async () => {
    if (!editingBanner || !formData.title.trim()) {
      toast({
        title: "خطأ",
        description: "يرجى إدخال عنوان البانر",
        variant: "destructive",
      });
      return;
    }

    try {
      const response = await apiRequest("PUT", `/api/banners/${editingBanner.id}`, formData);
      setBanners(banners.map(b => b.id === editingBanner.id ? response : b));
      setEditingBanner(null);
      setFormData({ title: "", description: "", imageUrl: "", isActive: true });
      toast({
        title: "نجح",
        description: "تم تحديث البانر بنجاح",
      });
    } catch (error) {
      toast({
        title: "خطأ",
        description: "فشل في تحديث البانر",
        variant: "destructive",
      });
    }
  };

  // حذف بانر
  const handleDeleteBanner = async (id: string) => {
    if (!confirm("هل أنت متأكد من حذف هذا البانر؟")) return;

    try {
      await apiRequest("DELETE", `/api/banners/${id}`);
      setBanners(banners.filter(b => b.id !== id));
      toast({
        title: "نجح",
        description: "تم حذف البانر بنجاح",
      });
    } catch (error) {
      toast({
        title: "خطأ",
        description: "فشل في حذف البانر",
        variant: "destructive",
      });
    }
  };

  // تغيير حالة البانر
  const toggleBannerStatus = async (id: string, isActive: boolean) => {
    try {
      await apiRequest("PUT", `/api/banners/${id}/toggle`, { isActive });
      setBanners(banners.map(b => b.id === id ? { ...b, isActive } : b));
      toast({
        title: "نجح",
        description: `تم ${isActive ? 'تفعيل' : 'إلغاء'} البانر بنجاح`,
      });
    } catch (error) {
      toast({
        title: "خطأ",
        description: "فشل في تغيير حالة البانر",
        variant: "destructive",
      });
    }
  };

  // بدء التحرير
  const startEdit = (banner: Banner) => {
    setEditingBanner(banner);
    setFormData({
      title: banner.title,
      description: banner.description,
      imageUrl: banner.imageUrl,
      isActive: banner.isActive
    });
    setIsAddingNew(false);
  };

  // إلغاء التحرير
  const cancelEdit = () => {
    setEditingBanner(null);
    setIsAddingNew(false);
    setFormData({ title: "", description: "", imageUrl: "", isActive: true });
  };

  // رفع صورة
  const handleImageUpload = async (file: File) => {
    const formData = new FormData();
    formData.append('image', file);

    try {
      const response = await fetch('/api/upload-image', {
        method: 'POST',
        body: formData,
      });
      const data = await response.json();
      
      if (data.url) {
        setFormData(prev => ({ ...prev, imageUrl: data.url }));
        toast({
          title: "نجح",
          description: "تم رفع الصورة بنجاح",
        });
      }
    } catch (error) {
      toast({
        title: "خطأ",
        description: "فشل في رفع الصورة",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-6" dir="rtl">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-gray-900">إدارة البانرات</h1>
        <Button
          onClick={() => setIsAddingNew(true)}
          className="bg-purple-600 hover:bg-purple-700"
          disabled={banners.length >= 5}
        >
          <Plus className="ml-2 h-4 w-4" />
          إضافة بانر جديد
        </Button>
      </div>

      {/* نموذج الإضافة/التحرير */}
      {(isAddingNew || editingBanner) && (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>
              {editingBanner ? "تحرير البانر" : "إضافة بانر جديد"}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="title">العنوان</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                placeholder="عنوان البانر"
              />
            </div>

            <div>
              <Label htmlFor="description">الوصف</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                placeholder="وصف البانر"
                rows={3}
              />
            </div>

            <div>
              <Label htmlFor="imageUrl">رابط الصورة أو رفع صورة</Label>
              <div className="flex gap-2">
                <Input
                  id="imageUrl"
                  value={formData.imageUrl}
                  onChange={(e) => setFormData(prev => ({ ...prev, imageUrl: e.target.value }))}
                  placeholder="رابط الصورة"
                />
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) handleImageUpload(file);
                  }}
                  className="hidden"
                  id="image-upload"
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => document.getElementById('image-upload')?.click()}
                >
                  <Upload className="h-4 w-4" />
                </Button>
              </div>
              {formData.imageUrl && (
                <img
                  src={formData.imageUrl}
                  alt="معاينة"
                  className="mt-2 max-h-32 rounded border"
                />
              )}
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id="isActive"
                checked={formData.isActive}
                onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isActive: checked }))}
              />
              <Label htmlFor="isActive">البانر نشط</Label>
            </div>

            <div className="flex gap-2">
              <Button
                onClick={editingBanner ? handleUpdateBanner : handleAddBanner}
                className="bg-purple-600 hover:bg-purple-700"
              >
                {editingBanner ? "تحديث" : "إضافة"}
              </Button>
              <Button variant="outline" onClick={cancelEdit}>
                إلغاء
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* قائمة البانرات */}
      <div className="grid gap-4">
        {banners.length === 0 ? (
          <Card>
            <CardContent className="text-center py-8">
              <Image className="mx-auto h-12 w-12 text-gray-400 mb-4" />
              <p className="text-gray-500">لا توجد بانرات حالياً</p>
            </CardContent>
          </Card>
        ) : (
          banners.map((banner) => (
            <Card key={banner.id} className="overflow-hidden">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4 space-x-reverse">
                    {banner.imageUrl && (
                      <img
                        src={banner.imageUrl}
                        alt={banner.title}
                        className="w-16 h-16 object-cover rounded"
                      />
                    )}
                    <div>
                      <h3 className="font-semibold text-lg">{banner.title}</h3>
                      <p className="text-gray-600 text-sm">{banner.description}</p>
                      <span
                        className={`inline-block px-2 py-1 rounded-full text-xs ${
                          banner.isActive
                            ? 'bg-green-100 text-green-800'
                            : 'bg-gray-100 text-gray-800'
                        }`}
                      >
                        {banner.isActive ? 'نشط' : 'غير نشط'}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2 space-x-reverse">
                    <Switch
                      checked={banner.isActive}
                      onCheckedChange={(checked) => toggleBannerStatus(banner.id, checked)}
                    />
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => startEdit(banner)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDeleteBanner(banner.id)}
                    >
                      <Trash2 className="h-4 w-4 text-red-600" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {banners.length >= 5 && (
        <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
          <p className="text-yellow-800 text-sm">
            تم الوصول للحد الأقصى من البانرات (5 بانرات). يرجى حذف بانر لإضافة واحد جديد.
          </p>
        </div>
      )}
    </div>
  );
}