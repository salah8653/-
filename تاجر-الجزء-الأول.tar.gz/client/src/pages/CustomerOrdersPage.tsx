import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Package, Clock, CheckCircle, XCircle, ArrowRight, User, MapPin, Phone, Eye, ShoppingBag, Search } from "lucide-react";
import { useState, useMemo } from "react";
import { useLanguage } from "@/contexts/LanguageContext";
import { BottomNavigation } from "@/components/BottomNavigation";
import { formatCurrency, getOrderStatus, getOrderStatusColor } from "../utils/formatters";

interface OrderItem {
  productId: number;
  quantity: number;
  product: {
    id?: number;
    name: string;
    price: string;
    imageUrl?: string;
  };
}

interface Order {
  id: number;
  total: string;
  status: string;
  customerDetails: {
    name: string;
    phone: string;
    governorate: string;
    area: string;
    address: string;
    notes?: string;
  };
  items: OrderItem[];
  customerPrice?: number;
  deliveryFee?: number;
  totalWithDelivery?: number;
  totalItems?: number;
  orderDate?: string;
  createdAt: string;
  updatedAt: string;
}

const getStatusIcon = (status: string) => {
  const normalizedStatus = status === 'completed' || status === 'delivered' || !status || status === 'undefined' ? 'completed' : status;
  
  switch (normalizedStatus) {
    case 'pending':
      return <Clock className="w-4 h-4 text-yellow-500" />;
    case 'processing':
      return <Package className="w-4 h-4 text-blue-500" />;
    case 'shipped':
      return <Package className="w-4 h-4 text-purple-500" />;
    case 'delivered':
    case 'completed':
      return <CheckCircle className="w-4 h-4 text-green-500" />;
    case 'cancelled':
      return <XCircle className="w-4 h-4 text-red-500" />;
    default:
      return <CheckCircle className="w-4 h-4 text-green-500" />;
  }
};

// استخدام الدوال المركزية للحالة واللون من ملف formatters

// Modal component for order details
function OrderDetailsModal({ order, onClose }: { order: Order; onClose: () => void }) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-900">تفاصيل الطلب</h2>
            <button 
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600"
            >
              <XCircle className="w-6 h-6" />
            </button>
          </div>

          {/* Order Header */}
          <div className="bg-purple-50 rounded-lg p-4 mb-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-600">رقم الطلب</span>
              <span className="font-semibold">#{order.id.toString().slice(-6)}</span>
            </div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-600">الحالة</span>
              <div className={`px-2 py-1 rounded-full text-xs font-medium ${getOrderStatusColor(order.status)}`}>
                {getOrderStatus(order.status)}
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">المبلغ الإجمالي</span>
              <span className="font-bold text-purple-600 text-lg">
                {formatCurrency(order.total)} د.ع
              </span>
            </div>
            <div className="flex items-center justify-between mt-2">
              <span className="text-sm text-gray-600">ربح التاجر</span>
              <span className="font-semibold text-green-600">
                {formatCurrency((order as any).profit || 0)} د.ع
              </span>
            </div>
          </div>

          {/* Customer Details */}
          <div className="mb-6">
            <h3 className="font-semibold text-gray-900 mb-3">بيانات العميل</h3>
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2">
                <User className="w-4 h-4 text-gray-400" />
                <span>{order.customerDetails?.name}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-gray-400" />
                <span>{order.customerDetails?.phone}</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-gray-400" />
                <span>{order.customerDetails?.governorate} - {order.customerDetails?.area}</span>
              </div>
              <div className="text-gray-600 mr-6">
                {order.customerDetails?.address}
              </div>
              {order.customerDetails?.notes && (
                <div className="text-gray-600 mr-6">
                  ملاحظات: {order.customerDetails.notes}
                </div>
              )}
            </div>
          </div>

          {/* Order Items */}
          <div className="mb-6">
            <h3 className="font-semibold text-gray-900 mb-3">المنتجات</h3>
            <div className="space-y-3">
              {order.items?.map((item, index) => (
                <div key={index} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                  {item.product?.imageUrl && (
                    <img 
                      src={item.product.imageUrl} 
                      alt={item.product.name}
                      className="w-12 h-12 object-cover rounded"
                    />
                  )}
                  <div className="flex-1">
                    <div className="font-medium text-gray-900">{item.product?.name}</div>
                    <div className="text-sm text-gray-600">الكمية: {item.quantity}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Order Date */}
          <div className="border-t pt-4">
            <div className="text-sm text-gray-500">
              تاريخ الطلب: {new Date(order.createdAt).toLocaleDateString('ar-IQ')} - {new Date(order.createdAt).toLocaleTimeString('ar-IQ')}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function CustomerOrdersPage() {
  const { language, t, dir } = useLanguage();
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  
  const { data: orders, isLoading, error } = useQuery<Order[]>({
    queryKey: ['/api/orders'],
  });

  // Filter orders based on search query
  const filteredOrders = useMemo(() => {
    if (!orders || !searchQuery.trim()) return orders;
    
    const query = searchQuery.toLowerCase().trim();
    return orders.filter(order => 
      order.customerDetails?.name?.toLowerCase().includes(query) ||
      order.customerDetails?.phone?.includes(query) ||
      order.id.toString().includes(query)
    );
  }, [orders, searchQuery]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
        <BottomNavigation />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600 mb-4">{language === 'ar' ? 'حدث خطأ في تحميل الطلبات' : 'Error loading orders'}</p>
          <button 
            onClick={() => window.location.reload()} 
            className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700"
          >
            {language === 'ar' ? 'إعادة المحاولة' : 'Try Again'}
          </button>
        </div>
        <BottomNavigation />
      </div>
    );
  }

  if (!orders || orders.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-md mx-auto pt-20 px-4">
          <div className="bg-white rounded-lg shadow-sm p-8 text-center">
            <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-gray-900 mb-2">
              {language === 'ar' ? 'لا توجد طلبات بعد' : 'No orders yet'}
            </h2>
            <p className="text-gray-600 mb-6">
              {language === 'ar' ? 'ابدأ بتصفح المنتجات وإضافة ما تحتاجه إلى السلة' : 'Start browsing products and add what you need to the cart'}
            </p>
            <Link href="/" className="bg-purple-600 text-white px-6 py-3 rounded-lg hover:bg-purple-700 transition-colors">
              {language === 'ar' ? 'تصفح المنتجات' : 'Browse Products'}
            </Link>
          </div>
        </div>
        <BottomNavigation />
      </div>
    );
  }

  // Show "no results" message when search returns empty
  if (filteredOrders && filteredOrders.length === 0 && searchQuery.trim()) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 py-8">
          <div className="flex items-center justify-between mb-8">
            <h1 className="text-2xl font-bold text-gray-900">طلباتي</h1>
            <Link href="/" className="text-purple-600 hover:text-purple-700 flex items-center gap-2">
              <ArrowRight className="w-4 h-4" />
              العودة للمتجر
            </Link>
          </div>

          {/* Search Bar */}
          <div className="mb-6">
            <div className="relative">
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="البحث بالاسم أو رقم الهاتف أو رقم الطلب..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pr-10 pl-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-right"
              />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-8 text-center">
            <Search className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-gray-900 mb-2">
              {language === 'ar' ? 'لا توجد نتائج' : 'No results'}
            </h2>
            <p className="text-gray-600 mb-4">
              {language === 'ar' ? `لم يتم العثور على طلبات تطابق بحثك: "${searchQuery}"` : `No orders found matching your search: "${searchQuery}"`}
            </p>
            <button 
              onClick={() => setSearchQuery("")}
              className="bg-purple-600 text-white px-6 py-3 rounded-lg hover:bg-purple-700 transition-colors"
            >
              {language === 'ar' ? 'إظهار جميع الطلبات' : 'Show all orders'}
            </button>
          </div>
        </div>
        <BottomNavigation />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50" dir={dir}>
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-2xl font-bold text-gray-900">{t('orders')}</h1>
          <Link href="/" className="text-purple-600 hover:text-purple-700 flex items-center gap-2">
            <ArrowRight className="w-4 h-4" />
            {language === 'ar' ? 'العودة للمتجر' : 'Back to Store'}
          </Link>
        </div>

        {/* Search Bar */}
        <div className="mb-6">
          <div className="relative">
            <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="البحث بالاسم أو رقم الهاتف أو رقم الطلب..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pr-10 pl-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-right"
            />
          </div>
          {searchQuery.trim() && (
            <div className="mt-2 text-sm text-gray-600">
              {filteredOrders?.length || 0} نتيجة من أصل {orders?.length || 0} طلب
            </div>
          )}
        </div>

        <div className="grid gap-4">
          {(filteredOrders || orders)?.map((order) => (
            <div 
              key={order.id} 
              className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 hover:shadow-md transition-shadow cursor-pointer"
              onClick={() => setSelectedOrder(order)}
            >
              <div className="flex items-center justify-between">
                {/* Right Side - Product Image and Info */}
                <div className="flex items-center gap-4">
                  <div className="relative">
                    {order.items?.[0]?.product?.imageUrl ? (
                      <img 
                        src={order.items[0].product.imageUrl} 
                        alt={order.items[0].product.name}
                        className="w-16 h-16 object-cover rounded-lg"
                      />
                    ) : (
                      <div className="w-16 h-16 bg-gray-100 rounded-lg flex items-center justify-center">
                        <Package className="w-8 h-8 text-gray-400" />
                      </div>
                    )}
                    {order.items && order.items.length > 1 && (
                      <div className="absolute -top-2 -right-2 bg-purple-600 text-white text-xs rounded-full w-6 h-6 flex items-center justify-center">
                        +{order.items.length - 1}
                      </div>
                    )}
                  </div>
                  
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <ShoppingBag className="w-4 h-4 text-gray-400" />
                      <span className="text-sm font-medium text-gray-900">
                        {order.items?.length || 0} منتج
                      </span>
                    </div>
                    <div className="flex items-center gap-2 mb-1">
                      {getStatusIcon(order.status)}
                      <span className="text-sm text-gray-600">
                        {getOrderStatus(order.status)}
                      </span>
                    </div>
                    <div className="text-xs text-gray-500">
                      {new Date(order.createdAt).toLocaleDateString('ar-IQ')}
                    </div>
                  </div>
                </div>

                {/* Left Side - Price and View Button */}
                <div className="flex items-center gap-3">
                  <div className="text-left">
                    <div className="text-lg font-bold text-purple-600">
                      {formatCurrency(order.total)} د.ع
                    </div>
                    <div className="text-xs text-gray-500">
                      المبلغ الإجمالي
                    </div>
                    <div className="text-sm font-medium text-green-600 mt-1">
                      ربح: {formatCurrency((order as any).profit || 0)} د.ع
                    </div>
                  </div>
                  <div className="text-purple-600">
                    <Eye className="w-5 h-5" />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Order Details Modal */}
      {selectedOrder && (
        <OrderDetailsModal 
          order={selectedOrder} 
          onClose={() => setSelectedOrder(null)} 
        />
      )}
      
      <BottomNavigation />
    </div>
  );
}