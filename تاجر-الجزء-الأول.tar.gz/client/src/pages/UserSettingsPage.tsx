import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { 
  Settings, 
  LogOut, 
  Moon, 
  Sun, 
  Globe, 
  User,
  ArrowRight,
  Languages,
  ChevronRight
} from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { useLocation } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import { useLanguage } from '@/contexts/LanguageContext';

export const UserSettingsPage = () => {
  const { logout, user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { language, t, dir } = useLanguage();
  const [isDarkMode, setIsDarkMode] = useState(() => {
    return localStorage.getItem('darkMode') === 'true';
  });

  // تطبيق الوضع المظلم عند تحميل الصفحة
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, []);

  const handleLogout = () => {
    toast({
      title: "تم تسجيل الخروج بنجاح",
      description: "شكراً لك، نراك قريباً!"
    });
    logout();
    setLocation('/login');
  };

  const toggleDarkMode = () => {
    const newDarkMode = !isDarkMode;
    setIsDarkMode(newDarkMode);
    
    if (newDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    
    localStorage.setItem('darkMode', newDarkMode.toString());
    
    toast({
      title: "تم تغيير وضع العرض",
      description: newDarkMode ? "تم التبديل للوضع المظلم" : "تم التبديل للوضع الفاتح"
    });
  };

  const { setLanguage: changeLanguage } = useLanguage();

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 p-4" dir={dir}>
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center gap-3 mb-8">
          <div className="w-12 h-12 bg-purple-600 rounded-xl flex items-center justify-center">
            <Settings className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">{t('settings.title')}</h1>
            <p className="text-slate-600 dark:text-slate-400">
              {language === 'ar' ? 'إدارة حسابك وتفضيلاتك' : 'Manage your account and preferences'}
            </p>
          </div>
        </div>

        {/* معلومات المستخدم */}
        <Card className="dark:bg-slate-800 dark:border-slate-700">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-slate-900 dark:text-white">
              <User className="w-5 h-5" />
              {language === 'ar' ? 'معلومات الحساب' : 'Account Information'}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-700 rounded-lg">
              <div>
                <p className="font-medium text-slate-900 dark:text-white">
                  {language === 'ar' ? 'رقم الهاتف' : 'Phone Number'}
                </p>
                <p className="text-slate-600 dark:text-slate-400">
                  {user?.phone || (language === 'ar' ? 'غير محدد' : 'Not specified')}
                </p>
              </div>
              <Badge variant="secondary" className="dark:bg-slate-600 dark:text-white">
                {language === 'ar' ? 'مُفعل' : 'Active'}
              </Badge>
            </div>
            <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-700 rounded-lg">
              <div>
                <p className="font-medium text-slate-900 dark:text-white">
                  {language === 'ar' ? 'نوع الحساب' : 'Account Type'}
                </p>
                <p className="text-slate-600 dark:text-slate-400">
                  {language === 'ar' ? 'عميل' : 'Customer'}
                </p>
              </div>
              <Badge variant="outline" className="dark:border-slate-600 dark:text-slate-300">
                {language === 'ar' ? 'أساسي' : 'Basic'}
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* إعدادات العرض */}
        <Card className="dark:bg-slate-800 dark:border-slate-700">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-slate-900 dark:text-white">
              <Moon className="w-5 h-5" />
              {language === 'ar' ? 'إعدادات العرض' : 'Display Settings'}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* الوضع المظلم */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {isDarkMode ? (
                  <Moon className="w-5 h-5 text-slate-600 dark:text-slate-400" />
                ) : (
                  <Sun className="w-5 h-5 text-slate-600 dark:text-slate-400" />
                )}
                <div>
                  <p className="font-medium text-slate-900 dark:text-white">
                    {language === 'ar' ? 'الوضع المظلم' : 'Dark Mode'}
                  </p>
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    {isDarkMode ? 
                      (language === 'ar' ? 'مُفعل' : 'Enabled') : 
                      (language === 'ar' ? 'غير مُفعل' : 'Disabled')
                    }
                  </p>
                </div>
              </div>
              <Switch
                checked={isDarkMode}
                onCheckedChange={toggleDarkMode}
              />
            </div>


          </CardContent>
        </Card>

        {/* حفظ التغييرات */}
        <Card className="border-green-200 bg-green-50 dark:border-green-700 dark:bg-green-900/20">
          <CardHeader>
            <CardTitle className="text-green-800 dark:text-green-200 text-center">
              {language === 'ar' ? '💾 حفظ التغييرات' : '💾 Save Changes'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center mb-4">
              <p className="text-sm text-green-700 dark:text-green-300">
                {language === 'ar' ? 'احفظ الإعدادات الجديدة لتطبيقها' : 'Save new settings to apply them'}
              </p>
            </div>
            <Button
              className="w-full bg-green-600 hover:bg-green-700 text-white py-4 text-lg font-bold shadow-lg"
              onClick={async () => {
                localStorage.setItem('darkMode', isDarkMode.toString());
                localStorage.setItem('language', language);
                
                toast({
                  title: language === 'ar' ? "✅ تم حفظ التغييرات بنجاح" : "✅ Changes saved successfully",
                  description: language === 'ar' ? "تم تطبيق جميع إعداداتك الجديدة" : "All your new settings have been applied"
                });
              }}
            >
              {language === 'ar' ? '💾 حفظ التغييرات' : '💾 Save Changes'}
            </Button>
          </CardContent>
        </Card>

        {/* إعدادات التطبيق */}
        <Card className="dark:bg-slate-800 dark:border-slate-700">
          <CardHeader>
            <CardTitle className="text-slate-900 dark:text-white">
              {language === 'ar' ? 'إعدادات التطبيق' : 'App Settings'}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button
              variant="outline"
              className="w-full justify-between dark:border-slate-600 dark:text-slate-300 dark:hover:bg-slate-700"
              onClick={() => setLocation('/support')}
            >
              <div className="flex items-center gap-2">
                <span>{language === 'ar' ? 'الدعم الفني' : 'Technical Support'}</span>
              </div>
              <ArrowRight className="w-4 h-4" />
            </Button>
            
            <Button
              variant="outline"
              className="w-full justify-between dark:border-slate-600 dark:text-slate-300 dark:hover:bg-slate-700"
              onClick={() => setLocation('/profile')}
            >
              <div className="flex items-center gap-2">
                <span>الملف الشخصي</span>
              </div>
              <ArrowRight className="w-4 h-4" />
            </Button>
          </CardContent>
        </Card>

        {/* تسجيل الخروج */}
        <Card className="border-red-200 dark:border-red-800 dark:bg-slate-800">
          <CardContent className="pt-6">
            <Button
              variant="destructive"
              className="w-full"
              onClick={handleLogout}
            >
              <LogOut className="w-4 h-4 ml-2" />
              تسجيل الخروج
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};