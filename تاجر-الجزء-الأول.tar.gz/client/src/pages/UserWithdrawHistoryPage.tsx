import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Clock, Check, X, DollarSign, Calendar, CreditCard, Smartphone } from "lucide-react";
import { format } from "date-fns";
import { ar } from "date-fns/locale";

interface WithdrawRequest {
  id: string;
  userPhone: string;
  userName: string;
  method: 'zain-cash' | 'mastercard';
  phoneNumber?: string;
  cardNumber?: string;
  fullName: string;
  amount: number;
  status: 'pending' | 'completed' | 'rejected';
  createdAt: string;
  updatedAt?: string;
  rejectionReason?: string;
}

export const UserWithdrawHistoryPage = () => {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const [filter, setFilter] = useState<'all' | 'pending' | 'completed' | 'rejected'>('all');

  const { data: withdrawRequests = [], isLoading } = useQuery({
    queryKey: [`/api/withdraw-requests/user/${user?.phone}`],
    enabled: !!user?.phone,
  });

  const { data: userStats } = useQuery({
    queryKey: [`/api/users/${user?.phone}/stats`],
    enabled: !!user?.phone,
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-800"><Clock className="w-3 h-3 mr-1" />قيد المعالجة</Badge>;
      case 'completed':
        return <Badge className="bg-green-100 text-green-800"><Check className="w-3 h-3 mr-1" />تم السحب</Badge>;
      case 'rejected':
        return <Badge className="bg-red-100 text-red-800"><X className="w-3 h-3 mr-1" />تم الرفض</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getMethodIcon = (method: string) => {
    switch (method) {
      case 'zain-cash':
        return <Smartphone className="w-4 h-4 text-purple-600" />;
      case 'mastercard':
        return <CreditCard className="w-4 h-4 text-blue-600" />;
      default:
        return <DollarSign className="w-4 h-4" />;
    }
  };

  const getMethodName = (method: string) => {
    switch (method) {
      case 'zain-cash':
        return 'زين كاش';
      case 'mastercard':
        return 'ماستر كارد الرافدين';
      default:
        return method;
    }
  };

  const filteredRequests = withdrawRequests.filter((request: WithdrawRequest) => {
    if (filter === 'all') return true;
    return request.status === filter;
  });

  const stats = {
    total: withdrawRequests.length,
    pending: withdrawRequests.filter((r: WithdrawRequest) => r.status === 'pending').length,
    completed: withdrawRequests.filter((r: WithdrawRequest) => r.status === 'completed').length,
    rejected: withdrawRequests.filter((r: WithdrawRequest) => r.status === 'rejected').length,
    totalAmount: withdrawRequests
      .filter((r: WithdrawRequest) => r.status === 'completed')
      .reduce((sum: number, r: WithdrawRequest) => sum + r.amount, 0),
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-md mx-auto">
        {/* Header */}
        <div className="flex items-center mb-6">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLocation("/profile")}
            className="p-2"
          >
            <ArrowRight className="w-5 h-5" />
          </Button>
          <h1 className="text-xl font-bold text-gray-900 mr-3">
            عمليات السحب
          </h1>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">إجمالي العمليات</p>
                  <p className="text-2xl font-bold text-purple-600">{stats.total}</p>
                </div>
                <DollarSign className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">المبلغ المسحوب</p>
                  <p className="text-lg font-bold text-green-600">
                    {stats.totalAmount.toLocaleString()} د.ع
                  </p>
                </div>
                <Check className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filter Buttons */}
        <div className="grid grid-cols-4 gap-2 mb-6">
          <Button
            variant={filter === 'all' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilter('all')}
            className="text-xs"
          >
            الكل ({stats.total})
          </Button>
          <Button
            variant={filter === 'pending' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilter('pending')}
            className="text-xs"
          >
            معالجة ({stats.pending})
          </Button>
          <Button
            variant={filter === 'completed' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilter('completed')}
            className="text-xs"
          >
            مكتمل ({stats.completed})
          </Button>
          <Button
            variant={filter === 'rejected' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilter('rejected')}
            className="text-xs"
          >
            مرفوض ({stats.rejected})
          </Button>
        </div>

        {/* Withdraw Requests List */}
        <div className="space-y-4">
          {filteredRequests.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <DollarSign className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">
                  {filter === 'all' ? 'لا توجد عمليات سحب' : `لا توجد عمليات ${filter === 'pending' ? 'قيد المعالجة' : filter === 'completed' ? 'مكتملة' : 'مرفوضة'}`}
                </p>
                <Button
                  className="mt-4"
                  onClick={() => setLocation("/withdraw")}
                >
                  طلب سحب جديد
                </Button>
              </CardContent>
            </Card>
          ) : (
            filteredRequests.map((request: WithdrawRequest) => (
              <Card key={request.id}>
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {getMethodIcon(request.method)}
                      <div>
                        <p className="text-sm font-medium">{getMethodName(request.method)}</p>
                        <p className="text-xs text-gray-500">
                          {request.method === 'zain-cash' ? request.phoneNumber : 
                           request.method === 'mastercard' ? `**** **** **** ${request.cardNumber?.slice(-4)}` : ''}
                        </p>
                      </div>
                    </div>
                    {getStatusBadge(request.status)}
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">المبلغ:</span>
                      <span className="text-lg font-bold text-purple-600">
                        {request.amount.toLocaleString()} د.ع
                      </span>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">تاريخ الطلب:</span>
                      <div className="flex items-center gap-1 text-sm text-gray-700">
                        <Calendar className="w-3 h-3" />
                        {format(new Date(request.createdAt), 'dd/MM/yyyy HH:mm', { locale: ar })}
                      </div>
                    </div>

                    {request.status === 'completed' && request.updatedAt && (
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">تاريخ التحويل:</span>
                        <div className="flex items-center gap-1 text-sm text-green-700">
                          <Check className="w-3 h-3" />
                          {format(new Date(request.updatedAt), 'dd/MM/yyyy HH:mm', { locale: ar })}
                        </div>
                      </div>
                    )}

                    {request.status === 'rejected' && request.rejectionReason && (
                      <div className="mt-3 p-3 bg-red-50 rounded-lg">
                        <p className="text-sm text-red-800 font-medium">سبب الرفض:</p>
                        <p className="text-sm text-red-700">{request.rejectionReason}</p>
                      </div>
                    )}

                    {request.status === 'pending' && (
                      <div className="mt-3 p-3 bg-yellow-50 rounded-lg">
                        <p className="text-sm text-yellow-800">
                          طلبك قيد المراجعة. ستصلك النتيجة خلال 24 ساعة.
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>

        {/* New Withdraw Button */}
        {((userStats as any)?.totalProfit >= 10000) && (
          <div className="mt-6">
            <Button
              className="w-full bg-purple-600 hover:bg-purple-700"
              onClick={() => setLocation("/withdraw")}
            >
              <DollarSign className="w-4 h-4 mr-2" />
              طلب سحب جديد
            </Button>
          </div>
        )}
        
        {((userStats as any)?.totalProfit < 10000 || !(userStats as any)?.totalProfit) && (
          <div className="mt-6 p-4 bg-gray-50 rounded-lg text-center">
            <p className="text-sm text-gray-500">
              {!(userStats as any)?.totalProfit 
                ? "لا توجد أرباح متاحة للسحب" 
                : "الحد الأدنى للسحب 10,000 د.ع"}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};