import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { Lock, Phone, AlertTriangle, X, ShoppingBag, AlertCircle } from 'lucide-react';
import { Link } from 'wouter';
import { loginSchema, type loginSchema as LoginSchemaType } from '@shared/schema';
import { z } from 'zod';

type LoginFormData = z.infer<typeof loginSchema>;

export const LoginPage = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [showWarning, setShowWarning] = useState(true);
  const [loginAttempts, setLoginAttempts] = useState(0);
  const [remainingAttempts, setRemainingAttempts] = useState(10);
  const [isBlocked, setIsBlocked] = useState(false);
  const [blockTimeLeft, setBlockTimeLeft] = useState(0);
  const { login } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  // فحص حالة محاولات تسجيل الدخول عند تحميل الصفحة
  const checkLoginAttempts = async (identifier: string) => {
    if (!identifier) return;
    
    try {
      const response = await fetch(`/api/auth/login-attempts/${encodeURIComponent(identifier)}`);
      if (response.ok) {
        const data = await response.json();
        setLoginAttempts(data.attempts);
        setRemainingAttempts(data.remainingAttempts);
        setIsBlocked(data.blocked);
        
        if (data.blocked && data.timeUntilReset > 0) {
          setBlockTimeLeft(Math.ceil(data.timeUntilReset / 1000));
          
          // عداد تنازلي
          const timer = setInterval(() => {
            const remaining = Math.ceil((data.timeUntilReset - (Date.now() - new Date().getTime())) / 1000);
            if (remaining <= 0) {
              setIsBlocked(false);
              setBlockTimeLeft(0);
              setLoginAttempts(0);
              setRemainingAttempts(10);
              clearInterval(timer);
            } else {
              setBlockTimeLeft(remaining);
            }
          }, 1000);
          
          return () => clearInterval(timer);
        }
      }
    } catch (error) {
      console.error('خطأ في فحص محاولات تسجيل الدخول:', error);
    }
  };

  useEffect(() => {
    // إزالة النظام القديم
    localStorage.removeItem('loginBlockedUntil');
  }, []);

  const form = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      phoneOrEmail: '',
      password: '',
    },
  });

  const onSubmit = async (data: LoginFormData) => {
    if (isBlocked) {
      toast({
        title: "تم حظر تسجيل الدخول مؤقتاً",
        description: `المحاولة متاحة بعد ${blockTimeLeft} ثانية`,
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      const response = await login(data.phoneOrEmail, data.password);
      if (response.user) {
        // إعادة تعيين محاولات تسجيل الدخول عند النجاح
        setLoginAttempts(0);
        localStorage.removeItem('loginBlockedUntil');
        
        // إعادة المستخدم إلى الصفحة المناسبة
        if (response.user.role === 'admin') {
          window.location.href = '/dashboard';
        } else {
          window.location.href = '/store';
        }
        
        toast({
          title: "تم تسجيل الدخول بنجاح",
          description: `مرحباً ${response.user.fullName || response.user.phone}`,
        });
        
        // توجيه المستخدم حسب نوعه مع إعادة تحميل الصفحة
        setTimeout(() => {
          if (response.user.role === 'admin') {
            window.location.href = '/dashboard'; // توجيه للإدارة
          } else {
            window.location.href = '/store'; // توجيه للمتجر
          }
        }, 500);
      }
    } catch (error: any) {
      // التحقق من حالة الحظر
      if (error.status === 403 && error.banned) {
        toast({
          title: "تم حظر الحساب",
          description: "تم حظر حسابك من قبل الإدارة",
          variant: "destructive",
        });
        
        // توجيه إلى صفحة الحظر
        setTimeout(() => {
          setLocation('/banned');
        }, 1000);
        return;
      }
      
      // التحقق من معدل المحاولات (النظام الجديد)
      if (error.status === 429) {
        setIsBlocked(true);
        setRemainingAttempts(0);
        
        toast({
          title: "تم تجاوز عدد المحاولات",
          description: "تم تجاوز عدد المحاولات المسموحة (10 محاولات في الساعة)",
          variant: "destructive",
        });
      } else {
        // تحديث معلومات المحاولات بعد فشل تسجيل الدخول
        await checkLoginAttempts(data.phoneOrEmail);
        
        toast({
          title: "خطأ في تسجيل الدخول",
          description: error.message || "بيانات تسجيل الدخول غير صحيحة",
          variant: "destructive",
        });
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center">
          <div className="mx-auto w-20 h-20 bg-gradient-to-br from-purple-600 to-purple-800 rounded-2xl flex items-center justify-center mb-6 shadow-lg border-4 border-purple-200">
            <ShoppingBag className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-3xl font-bold text-gray-900 mb-2">تسجيل الدخول</h2>
          <p className="text-gray-600">أدخل بياناتك للوصول إلى حسابك</p>
        </div>

        <Card className="shadow-xl border-0">
          <CardHeader className="space-y-1 pb-6">
            <CardTitle className="text-2xl text-center text-gray-800">
              مرحباً بك مرة أخرى
            </CardTitle>
          </CardHeader>
          <CardContent>
            {/* رسالة الحظر المؤقت */}
            {isBlocked && (
              <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
                <div className="flex items-center gap-3">
                  <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
                  <div className="text-right">
                    <p className="text-red-800 text-sm font-medium mb-1">
                      تم حظر تسجيل الدخول مؤقتاً
                    </p>
                    <p className="text-red-700 text-sm">
                      المحاولة متاحة بعد {blockTimeLeft} ثانية
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* عداد المحاولات */}
            {!isBlocked && loginAttempts > 0 && (
              <div className="mb-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                <div className="flex items-center gap-2 justify-center">
                  <AlertCircle className="w-4 h-4 text-yellow-600" />
                  <p className="text-yellow-800 text-sm">
                    المحاولة {loginAttempts}/10 - تبقى {remainingAttempts} محاولات
                  </p>
                </div>
              </div>
            )}

            {/* رسالة التحذير */}
            {showWarning && (
              <div className="mb-6 p-4 bg-amber-50 border border-amber-200 rounded-lg relative">
                <button
                  onClick={() => setShowWarning(false)}
                  className="absolute top-2 right-2 p-1 hover:bg-amber-100 rounded-full transition-colors"
                  aria-label="إغلاق التحذير"
                >
                  <X className="w-4 h-4 text-amber-600" />
                </button>
                <div className="flex items-start gap-3 pr-6">
                  <AlertTriangle className="w-5 h-5 text-amber-600 mt-0.5 flex-shrink-0" />
                  <div className="text-right">
                    <p className="text-amber-800 text-sm font-medium mb-1">
                      تحذير مهم
                    </p>
                    <p className="text-amber-700 text-sm leading-relaxed">
                      رقم الهاتف والبريد الإلكتروني مطلوبان في حال نسيت كلمه المرور وعدم تذكرهما لن تستطيع ارجاع حسابك من فضلك حافظ عليهما
                    </p>
                    <p className="text-amber-700 text-sm mt-2 font-medium">
                      شكرا لك
                    </p>
                  </div>
                </div>
              </div>
            )}

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="phoneOrEmail"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center gap-2">
                        <Phone className="w-4 h-4" />
                        رقم الهاتف أو البريد الإلكتروني
                      </FormLabel>
                      <FormControl>
                        <Input
                          placeholder="07701234567 أو البريد الإلكتروني"
                          {...field}
                          onChange={(e) => {
                            field.onChange(e);
                            // فحص محاولات تسجيل الدخول عند تغيير الحقل
                            if (e.target.value.length > 3) {
                              checkLoginAttempts(e.target.value);
                            }
                          }}
                          className="text-right h-12"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center gap-2">
                        <Lock className="w-4 h-4" />
                        كلمة المرور
                      </FormLabel>
                      <FormControl>
                        <Input
                          type="password"
                          placeholder="أدخل كلمة المرور"
                          {...field}
                          className="text-right h-12"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />



                <Button
                  type="submit"
                  className="w-full h-12 bg-purple-600 hover:bg-purple-700 text-white font-semibold"
                  disabled={isLoading}
                >
                  {isLoading ? 'جارِ تسجيل الدخول...' : 'تسجيل الدخول'}
                </Button>
              </form>
            </Form>

            <div className="mt-6 text-center space-y-2">
              <p className="text-gray-600">
                <Button 
                  variant="link" 
                  className="text-blue-600 p-0 h-auto font-medium"
                  onClick={() => window.open('https://wa.me/9647801258110', '_blank')}
                >
                  نسيت كلمة المرور؟ راسل الدعم
                </Button>
              </p>
              <p className="text-gray-600">
                ليس لديك حساب؟{' '}
                <Link href="/register">
                  <Button variant="link" className="text-blue-600 p-0 h-auto font-semibold">
                    إنشاء حساب جديد
                  </Button>
                </Link>
              </p>
            </div>
          </CardContent>
        </Card>

        <div className="text-center text-sm text-gray-500">
          <p>بتسجيل الدخول، أنت توافق على شروط الاستخدام وسياسة الخصوصية</p>
        </div>
      </div>
    </div>
  );
};