import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Trash2, ShoppingCart, Heart, ArrowLeft, Package } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

interface SavedProduct {
  id: number;
  product: {
    id: number;
    name: string;
    price: number;
    imageUrl?: string;
    category?: {
      name: string;
    };
  };
  savedAt: string;
}

export const CustomerSavedProductsPage = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // جلب المنتجات المحفوظة
  const { data: savedProducts = [], isLoading, refetch } = useQuery<SavedProduct[]>({
    queryKey: ['/api/saved-products'],
  });

  const removeMutation = useMutation({
    mutationFn: async (productId: number) => {
      const response = await fetch(`/api/saved-products/${productId}`, {
        method: 'DELETE',
      });
      if (!response.ok) throw new Error('فشل في حذف المنتج');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/saved-products'] });
      toast({
        title: "تم الحذف",
        description: "تم إزالة المنتج من المحفوظات",
      });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "فشل في حذف المنتج",
        variant: "destructive",
      });
    },
  });

  const addToCartMutation = useMutation({
    mutationFn: async (productId: number) => {
      const response = await fetch('/api/cart', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ productId, quantity: 1 }),
      });
      if (!response.ok) throw new Error('فشل في إضافة المنتج');
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم الإضافة",
        description: "تم إضافة المنتج إلى السلة",
      });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "فشل في إضافة المنتج للسلة",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 py-3">
        <div className="flex items-center justify-between">
          <Link href="/store">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="w-4 h-4 ml-2" />
            </Button>
          </Link>
          
          <h1 className="text-lg font-semibold">المنتجات المحفوظة</h1>
          
          <div className="w-8 h-8" />
        </div>
      </div>

      <div className="container mx-auto max-w-md p-4">
        {savedProducts.length === 0 ? (
          <div className="text-center py-12">
            <Heart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">لا توجد منتجات محفوظة</h3>
            <p className="text-gray-600 mb-4">ابدأ بحفظ المنتجات التي تعجبك</p>
            <Link href="/store">
              <Button>تصفح المنتجات</Button>
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {savedProducts.map((item) => (
              <Link key={item.id} href={`/product/${item.product.id}`}>
                <Card className="overflow-hidden hover:shadow-md transition-shadow cursor-pointer">
                  <CardContent className="p-0">
                    <div className="flex">
                      {/* صورة المنتج */}
                      <div className="w-24 h-24 bg-gray-100 flex-shrink-0">
                        {item.product.imageUrl ? (
                          <img
                            src={item.product.imageUrl}
                            alt={item.product.name}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <Package className="w-8 h-8 text-gray-300" />
                          </div>
                        )}
                      </div>
                      
                      {/* معلومات المنتج */}
                      <div className="flex-1 p-4">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <h3 className="font-medium text-gray-900 mb-1">{item.product.name}</h3>
                            {item.product.category && (
                              <Badge variant="outline" className="text-xs">
                                الفئة: {item.product.category.name}
                              </Badge>
                            )}
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => {
                              e.preventDefault();
                              removeMutation.mutate(item.product.id);
                            }}
                            className="text-red-500 hover:text-red-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                        
                        <div className="flex justify-between items-center">
                          <div>
                            <div className="text-xs text-gray-500 mb-1">سعر الجملة</div>
                            <span className="text-lg font-bold text-purple-600">
                              {item.product.price.toLocaleString()} د.ع
                            </span>
                          </div>
                          <Button
                            size="sm"
                            onClick={(e) => {
                              e.preventDefault();
                              addToCartMutation.mutate(item.product.id);
                            }}
                            className="bg-purple-600 hover:bg-purple-700"
                          >
                            <ShoppingCart className="w-4 h-4 ml-1" />
                            إضافة
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};