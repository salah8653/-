import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Copy, ShoppingCart, ArrowRight, Package, Heart } from "lucide-react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest } from "@/lib/queryClient";
import { ProductWithCategory } from "shared/schema";

export const SimpleProductDetailsPage = () => {
  const [, params] = useRoute("/product/:id");
  const [, setLocation] = useLocation();
  const [quantity, setQuantity] = useState(1);
  const [isSaved, setIsSaved] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: product, isLoading, refetch } = useQuery<ProductWithCategory>({
    queryKey: ["/api/products", params?.id],
    enabled: !!params?.id,
    refetchOnWindowFocus: true,
    staleTime: 0, // تحديث البيانات فوراً
    gcTime: 0, // لا تحفظ في الذاكرة المؤقتة (TanStack Query v5)
    refetchInterval: 5000, // تحديث كل 5 ثوان
  });

  // تحديث البيانات عند تحميل الصفحة
  useEffect(() => {
    if (params?.id) {
      refetch();
    }
  }, [params?.id, refetch]);

  // جلب حالة الحفظ للمنتج
  const { data: savedProducts = [] } = useQuery({
    queryKey: ["/api/saved-products"],
    enabled: !!user,
  });

  useEffect(() => {
    if (savedProducts && Array.isArray(savedProducts) && product) {
      setIsSaved(savedProducts.some((sp: any) => sp.productId === product.id));
    }
  }, [savedProducts, product]);

  // إضافة/إزالة من المحفوظات
  const toggleSaveMutation = useMutation({
    mutationFn: async () => {
      if (isSaved) {
        return await fetch(`/api/saved-products/${product?.id}`, { method: "DELETE" });
      } else {
        return await fetch("/api/saved-products", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ productId: product?.id }),
        });
      }
    },
    onSuccess: () => {
      setIsSaved(!isSaved);
      toast({
        title: isSaved ? "تم إزالة المنتج من المحفوظات" : "تم حفظ المنتج",
        description: isSaved ? "تم إزالة المنتج من قائمة المحفوظات" : "تم إضافة المنتج إلى قائمة المحفوظات",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/saved-products"] });
    },
  });

  // إضافة المنتج إلى السلة
  const addToCartMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/cart", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          productId: product?.id,
          quantity: quantity,
          customPrice: product?.price
        }),
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم إضافة المنتج إلى السلة",
        description: "يمكنك الآن إتمام عملية الشراء",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
      // التوجه مباشرة إلى صفحة السلة
      setLocation('/cart');
    },
    onError: (error: any) => {
      toast({
        title: "فشل في إضافة المنتج",
        description: error.message || "حدث خطأ أثناء إضافة المنتج إلى السلة",
        variant: "destructive",
      });
    },
  });

  const copyDescription = () => {
    if (product?.description) {
      navigator.clipboard.writeText(product.description);
      toast({
        title: "تم نسخ الوصف",
        description: "تم نسخ وصف المنتج إلى الحافظة",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="text-center py-12">
        <Package className="w-16 h-16 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">المنتج غير موجود</h3>
        <Button onClick={() => setLocation("/")}>
          <ArrowRight className="w-4 h-4 ml-2" />
          العودة للرئيسية
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="flex items-center justify-between p-4">
          <Button variant="ghost" onClick={() => setLocation("/")}>
            <ArrowRight className="w-5 h-5" />
          </Button>
          
          <h1 className="font-semibold text-gray-900 truncate mx-4">
            {product.name}
          </h1>
          
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => toggleSaveMutation.mutate()}
            disabled={!user || toggleSaveMutation.isPending}
          >
            <Heart className={`h-5 w-5 ${isSaved ? 'fill-red-500 text-red-500' : ''}`} />
          </Button>
        </div>
      </div>

      <div className="p-4 space-y-6 pb-32">
        {/* Product Image */}
        <Card>
          <CardContent className="p-0">
            <div className="aspect-square relative bg-white rounded-lg overflow-hidden">
              {product.imageUrl ? (
                <img 
                  src={product.imageUrl} 
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full bg-gray-100 flex items-center justify-center">
                  <Package className="h-20 w-20 text-gray-400" />
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Product Title */}
        <Card>
          <CardContent className="p-4">
            <h1 className="text-2xl font-bold text-gray-900 text-center">
              {product.name}
            </h1>
          </CardContent>
        </Card>

        {/* Product Description */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-semibold text-gray-900">وصف المنتج</h2>
              <Button
                variant="outline"
                size="sm"
                onClick={copyDescription}
                className="flex items-center gap-2"
              >
                <Copy className="w-4 h-4" />
                نسخ
              </Button>
            </div>
            <p className="text-gray-600 leading-relaxed text-right">
              {product.description || "لا يوجد وصف متاح للمنتج"}
            </p>
          </CardContent>
        </Card>

        {/* Wholesale Price */}
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <h2 className="font-semibold text-gray-900 mb-2">سعر الجملة</h2>
              <div className="text-3xl font-bold text-purple-600">
                {parseFloat(product.price).toLocaleString()} د.ع
              </div>
              <p className="text-sm text-gray-500 mt-1">السعر للقطعة الواحدة</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Fixed Bottom Button */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t shadow-lg">
        <Button
          onClick={() => addToCartMutation.mutate()}
          disabled={!user || addToCartMutation.isPending || product.stock <= 0}
          className="w-full bg-purple-600 hover:bg-purple-700 text-white py-3 text-lg font-semibold"
        >
          {addToCartMutation.isPending ? (
            "جاري الإضافة..."
          ) : product.stock <= 0 ? (
            "غير متوفر"
          ) : (
            <>
              <ShoppingCart className="w-5 h-5 ml-2" />
              إضافة إلى السلة
            </>
          )}
        </Button>
      </div>
    </div>
  );
};