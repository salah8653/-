import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { 
  MessageCircle, 
  Search, 
  RefreshCw, 
  Send, 
  Phone, 
  Clock, 
  User,
  Loader2,
  ChevronLeft,
  Check,
  CheckCheck,
  ArrowLeft
} from 'lucide-react';
import { useLocation } from 'wouter';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'support';
  timestamp: Date;
  status: 'sent' | 'delivered' | 'read';
}

interface CustomerChat {
  customerId: string;
  customerName: string;
  customerPhone: string;
  messages: Message[];
  lastMessage: string;
  lastMessageTime: Date;
  unreadCount: number;
  isReadByAdmin: boolean;
}

export const AdminSupportNew = () => {
  const [, setLocation] = useLocation();
  const [chats, setChats] = useState<CustomerChat[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState<CustomerChat | null>(null);
  const [newMessage, setNewMessage] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [showChatList, setShowChatList] = useState(true);

  // تحميل رسائل الدعم
  const loadSupportMessages = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/support-messages');
      if (response.ok) {
        const messages = await response.json();
        console.log('📥 تم جلب رسائل الدعم من Firebase:', messages.length);
        
        if (messages.length === 0) {
          console.log('لا توجد رسائل');
          setChats([]);
          return;
        }

        // تجميع الرسائل حسب العميل
        const chatMap = new Map<string, CustomerChat>();
        
        messages.forEach((msg: any) => {
          const customerId = msg.customerPhone;
          
          if (!chatMap.has(customerId)) {
            chatMap.set(customerId, {
              customerId,
              customerName: msg.customerName,
              customerPhone: msg.customerPhone,
              messages: [],
              lastMessage: '',
              lastMessageTime: new Date(msg.createdAt),
              unreadCount: 0,
              isReadByAdmin: msg.isReadByAdmin || false
            });
          }
          
          const chat = chatMap.get(customerId)!;
          chat.messages.push({
            id: msg.id,
            text: msg.message,
            sender: msg.isAdminReply ? 'support' : 'user',
            timestamp: new Date(msg.createdAt),
            status: 'delivered'
          });
          
          if (!msg.isReadByAdmin && !msg.isAdminReply) {
            chat.unreadCount++;
          }
          
          if (new Date(msg.createdAt) > chat.lastMessageTime) {
            chat.lastMessageTime = new Date(msg.createdAt);
            chat.lastMessage = msg.message;
          }
        });

        // ترتيب الرسائل داخل كل محادثة حسب الوقت
        chatMap.forEach(chat => {
          chat.messages.sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
        });

        const chatsList = Array.from(chatMap.values()).sort((a, b) => 
          b.lastMessageTime.getTime() - a.lastMessageTime.getTime()
        );
        
        console.log('📊 تم تجميع المحادثات:', chatsList);
        setChats(chatsList);
      }
    } catch (error) {
      console.error('❌ خطأ في تحميل رسائل الدعم:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadSupportMessages();
    const interval = setInterval(loadSupportMessages, 5000);
    return () => clearInterval(interval);
  }, []);

  // إرسال رد من الإدارة
  const sendAdminReply = async () => {
    if (!newMessage.trim() || !selectedCustomer || isSending) return;

    setIsSending(true);
    try {
      const response = await fetch('/api/support-messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          customerPhone: selectedCustomer.customerPhone,
          customerName: selectedCustomer.customerName,
          message: newMessage,
          isAdminReply: true
        })
      });

      if (response.ok) {
        setNewMessage('');
        loadSupportMessages();
      }
    } catch (error) {
      console.error('❌ خطأ في إرسال الرد:', error);
    } finally {
      setIsSending(false);
    }
  };

  // وضع علامة مقروء
  const markAsRead = async (customerId: string) => {
    try {
      const response = await fetch('/api/support-messages/mark-read', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ customerPhone: customerId })
      });

      if (response.ok) {
        setChats(prevChats => 
          prevChats.map(chat => 
            chat.customerId === customerId 
              ? { ...chat, isReadByAdmin: true, unreadCount: 0 }
              : chat
          )
        );
        
        if (selectedCustomer?.customerId === customerId) {
          setSelectedCustomer({
            ...selectedCustomer,
            isReadByAdmin: true,
            unreadCount: 0
          });
        }
      }
    } catch (error) {
      console.error('❌ خطأ في تحديث حالة القراءة:', error);
    }
  };

  const selectCustomer = (chat: CustomerChat) => {
    setSelectedCustomer(chat);
    setShowChatList(false);
    if (!chat.isReadByAdmin) {
      markAsRead(chat.customerId);
    }
  };

  const formatTime = (date: Date) => {
    return new Intl.DateTimeFormat('ar-SA', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    }).format(date);
  };

  // تصفية المحادثات حسب البحث
  const filteredChats = chats.filter(chat => {
    if (!searchTerm.trim()) return true;
    const searchLower = searchTerm.toLowerCase();
    return (
      chat.customerName.toLowerCase().includes(searchLower) ||
      chat.customerPhone.includes(searchTerm) ||
      chat.messages.some(msg => msg.text.toLowerCase().includes(searchLower))
    );
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50" dir="rtl">
      {/* رأس الصفحة */}
      <div className="bg-white border-b border-gray-200 shadow-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between py-4 gap-4">
            <div className="flex-1">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                  <MessageCircle className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">إدارة الدعم الفني</h1>
                  <p className="text-gray-600 text-sm">
                    مساعدة العملاء وإدارة المحادثات • تاجر
                  </p>
                </div>
              </div>
            </div>
            
            {/* شريط البحث والأدوات */}
            <div className="flex items-center gap-3 flex-wrap">
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setLocation('/store-management')}
                className="flex items-center gap-2"
              >
                <ArrowLeft className="h-4 w-4" />
                العودة لإدارة المتجر
              </Button>
              
              <div className="relative flex-1 lg:flex-none">
                <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="البحث في المحادثات..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pr-10 pl-4 w-full lg:w-80 bg-gray-50 border-gray-200"
                />
              </div>
              
              <Button onClick={loadSupportMessages} disabled={isLoading} variant="outline" className="flex items-center gap-2">
                <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
                تحديث
              </Button>
              
              {/* إحصائيات سريعة */}
              <div className="hidden md:flex items-center gap-3 bg-gray-50 rounded-lg px-3 py-2">
                <div className="text-center">
                  <div className="text-lg font-bold text-blue-600">{filteredChats.length}</div>
                  <div className="text-xs text-gray-500">محادثة</div>
                </div>
                <div className="w-px h-8 bg-gray-300"></div>
                <div className="text-center">
                  <div className="text-lg font-bold text-red-600">
                    {filteredChats.filter(chat => !chat.isReadByAdmin).length}
                  </div>
                  <div className="text-xs text-gray-500">غير مقروء</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* المحتوى الرئيسي */}
      <div className="flex h-[calc(100vh-120px)]">
        {/* قائمة المحادثات - للشاشات الكبيرة أو عند عدم اختيار محادثة */}
        <div className={`${showChatList ? 'block' : 'hidden lg:block'} lg:w-96 w-full bg-white border-l border-gray-200 flex flex-col`}>
          {/* رأس قائمة المحادثات */}
          <div className="px-6 py-4 border-b border-gray-100 bg-gradient-to-r from-gray-50 to-white">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900">المحادثات النشطة</h2>
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="bg-blue-100 text-blue-700 text-xs">
                  {filteredChats.length}
                </Badge>
                {filteredChats.filter(chat => !chat.isReadByAdmin).length > 0 && (
                  <Badge variant="destructive" className="text-xs animate-pulse">
                    {filteredChats.filter(chat => !chat.isReadByAdmin).length} جديد
                  </Badge>
                )}
              </div>
            </div>
          </div>

          {/* قائمة المحادثات */}
          <div className="flex-1 overflow-y-auto">
            {isLoading ? (
              <div className="flex items-center justify-center h-32">
                <Loader2 className="h-5 w-5 animate-spin text-blue-500" />
                <span className="mr-2 text-sm text-gray-600">جاري التحميل...</span>
              </div>
            ) : filteredChats.length === 0 ? (
              <div className="text-center py-12 px-6">
                <MessageCircle className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500 text-sm font-medium">لا توجد محادثات</p>
                <p className="text-xs text-gray-400 mt-1">
                  في انتظار رسائل العملاء الجديدة
                </p>
              </div>
            ) : (
              <div className="space-y-1 p-2">
                {filteredChats.map((chat) => (
                  <Card 
                    key={chat.customerId}
                    className={`cursor-pointer transition-all duration-200 hover:shadow-md ${
                      selectedCustomer?.customerId === chat.customerId 
                        ? 'ring-2 ring-blue-500 bg-blue-50' 
                        : 'hover:bg-gray-50'
                    }`}
                    onClick={() => selectCustomer(chat)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3">
                        <Avatar className="h-10 w-10">
                          <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-600 text-white">
                            <User className="h-5 w-5" />
                          </AvatarFallback>
                        </Avatar>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <h3 className="font-medium text-gray-900 truncate">
                              {chat.customerName}
                            </h3>
                            {!chat.isReadByAdmin && (
                              <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                            )}
                          </div>
                          
                          <div className="flex items-center gap-2 mt-1">
                            <Phone className="h-3 w-3 text-gray-400" />
                            <span className="text-xs text-gray-500">{chat.customerPhone}</span>
                          </div>
                          
                          <div className="flex items-center justify-between mt-2">
                            <div className="flex items-center gap-1">
                              <Clock className="h-3 w-3 text-gray-400" />
                              <span className="text-xs text-gray-500">
                                {formatTime(chat.lastMessageTime)}
                              </span>
                            </div>
                            
                            {chat.unreadCount > 0 && (
                              <Badge variant="destructive" className="text-xs">
                                {chat.unreadCount}
                              </Badge>
                            )}
                          </div>
                          
                          {chat.messages.length > 0 && (
                            <p className="text-xs text-gray-600 mt-2 truncate">
                              {chat.messages[chat.messages.length - 1].text}
                            </p>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* منطقة المحادثة */}
        <div className={`${!showChatList ? 'block' : 'hidden lg:block'} flex-1 flex flex-col bg-white`}>
          {selectedCustomer ? (
            <>
              {/* رأس المحادثة */}
              <div className="px-6 py-4 border-b border-gray-200 bg-white">
                <div className="flex items-center gap-4">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="lg:hidden"
                    onClick={() => setShowChatList(true)}
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  
                  <Avatar className="h-10 w-10">
                    <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-600 text-white">
                      <User className="h-6 w-6" />
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900">{selectedCustomer.customerName}</h3>
                    <div className="flex items-center gap-2 text-sm text-gray-500">
                      <Phone className="h-3 w-3" />
                      {selectedCustomer.customerPhone}
                    </div>
                  </div>
                  
                  <div className="text-center">
                    <div className="text-sm font-medium text-gray-900">
                      {selectedCustomer.messages.length}
                    </div>
                    <div className="text-xs text-gray-500">رسالة</div>
                  </div>
                </div>
              </div>

              {/* منطقة الرسائل */}
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                {selectedCustomer.messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${message.sender === 'support' ? 'justify-start' : 'justify-end'}`}
                  >
                    <div
                      className={`max-w-xs lg:max-w-md px-4 py-3 rounded-2xl ${
                        message.sender === 'support'
                          ? 'bg-gray-100 text-gray-900'
                          : 'bg-gradient-to-r from-blue-500 to-purple-600 text-white'
                      }`}
                    >
                      <p className="text-sm leading-relaxed">{message.text}</p>
                      <div className={`flex items-center justify-between mt-2 text-xs ${
                        message.sender === 'support' ? 'text-gray-500' : 'text-white/80'
                      }`}>
                        <span>{formatTime(message.timestamp)}</span>
                        {message.sender === 'user' && (
                          <div className="flex items-center">
                            {message.status === 'sent' && <Check className="h-3 w-3" />}
                            {message.status === 'delivered' && <CheckCheck className="h-3 w-3" />}
                            {message.status === 'read' && <CheckCheck className="h-3 w-3 text-blue-300" />}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* منطقة إرسال الرسائل */}
              <div className="p-6 border-t border-gray-200 bg-gray-50">
                <div className="flex gap-3">
                  <Input
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder="اكتب ردك هنا..."
                    onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && sendAdminReply()}
                    className="flex-1 bg-white"
                    disabled={isSending}
                  />
                  <Button
                    onClick={sendAdminReply}
                    disabled={!newMessage.trim() || isSending}
                    className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
                  >
                    {isSending ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Send className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center bg-gray-50">
              <div className="text-center">
                <MessageCircle className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">اختر محادثة</h3>
                <p className="text-gray-500">حدد محادثة من القائمة لبدء الرد على العميل</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};