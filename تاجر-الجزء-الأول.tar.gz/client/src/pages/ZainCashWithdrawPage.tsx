import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { ArrowRight, Smartphone, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest } from "@/lib/queryClient";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const zainCashSchema = z.object({
  phoneNumber: z.string()
    .min(11, "رقم الهاتف يجب أن يكون 11 رقم")
    .max(11, "رقم الهاتف يجب أن يكون 11 رقم")
    .regex(/^[0-9]+$/, "يجب أن يحتوي على أرقام فقط"),
  fullName: z.string()
    .min(6, "الاسم الثلاثي مطلوب")
    .max(50, "الاسم طويل جداً"),
});

type ZainCashFormData = z.infer<typeof zainCashSchema>;

export const ZainCashWithdrawPage = () => {
  const [, setLocation] = useLocation();
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [formData, setFormData] = useState<ZainCashFormData | null>(null);
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const form = useForm<ZainCashFormData>({
    resolver: zodResolver(zainCashSchema),
    defaultValues: {
      phoneNumber: "",
      fullName: "",
    },
  });

  const withdrawMutation = useMutation({
    mutationFn: async (data: ZainCashFormData) => {
      return apiRequest("POST", "/api/withdraw", {
        method: "zain-cash",
        phoneNumber: data.phoneNumber,
        fullName: data.fullName,
        userPhone: user?.phone,
      });
    },
    onSuccess: (response: any) => {
      toast({
        title: "تم سحب الأرباح بنجاح",
        description: `تم تصفير الأرباح وإرسال الطلب. المبلغ: ${response.withdrawnAmount?.toLocaleString()} د.ع`,
      });
      // تحديث جميع البيانات المرتبطة بالأرباح
      queryClient.invalidateQueries({ queryKey: [`/api/user-stats/${user?.phone}`] });
      queryClient.invalidateQueries({ queryKey: ['/api/orders'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
      
      // توجيه المستخدم لصفحة الملف الشخصي لمشاهدة الأرباح المحدثة
      setTimeout(() => {
        setLocation("/profile");
      }, 2000);
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في عملية السحب",
        description: error.message || "حدث خطأ أثناء طلب السحب",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ZainCashFormData) => {
    setFormData(data);
    setShowConfirmDialog(true);
  };

  const handleConfirm = () => {
    if (formData) {
      withdrawMutation.mutate(formData);
    }
    setShowConfirmDialog(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-md mx-auto">
        {/* Header */}
        <div className="flex items-center mb-6">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLocation("/withdraw")}
            className="p-2"
          >
            <ArrowRight className="w-5 h-5" />
          </Button>
          <h1 className="text-xl font-bold text-gray-900 mr-3">
            سحب عبر زين كاش
          </h1>
        </div>

        {/* Form Card */}
        <Card>
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Smartphone className="w-8 h-8 text-purple-600" />
            </div>
            <CardTitle>بيانات زين كاش</CardTitle>
          </CardHeader>
          
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="phoneNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>رقم الهاتف (11 رقم)</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="07xxxxxxxxx"
                          {...field}
                          className="text-center"
                          dir="ltr"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="fullName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>الاسم الثلاثي</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="أحمد محمد علي"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button 
                  type="submit" 
                  className="w-full bg-purple-600 hover:bg-purple-700"
                  disabled={withdrawMutation.isPending}
                >
                  {withdrawMutation.isPending ? "جاري المعالجة..." : "سحب الأرباح"}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>

        {/* Info Card */}
        <Card className="mt-6 bg-blue-50 border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
              <div className="text-sm text-blue-800">
                <p className="font-medium mb-1">معلومات مهمة:</p>
                <ul className="space-y-1 text-xs">
                  <li>• تأكد من صحة رقم الهاتف</li>
                  <li>• الاسم يجب أن يطابق اسم حساب زين كاش</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Confirmation Dialog */}
      <AlertDialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>تأكيد سحب الأرباح</AlertDialogTitle>
            <AlertDialogDescription className="text-right">
              هل أنت متأكد من سحب الأرباح بالبيانات التالية؟
              <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                <p><strong>رقم الهاتف:</strong> {formData?.phoneNumber}</p>
                <p><strong>الاسم:</strong> {formData?.fullName}</p>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirm}>
              نعم، سحب الأرباح
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};