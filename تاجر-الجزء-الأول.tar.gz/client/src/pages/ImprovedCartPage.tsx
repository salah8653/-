import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useLocation } from "wouter";
import { useCart } from "@/hooks/useCart";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest } from "@/lib/queryClient";
import { ArrowRight, ShoppingCart, Plus, Minus, Package, MapPin, Phone, User, Trash2, CreditCard } from "lucide-react";

export const ImprovedCartPage = () => {
  const [, setLocation] = useLocation();
  const { items, updateQuantity, removeItem, clearCart, getTotalPrice, getTotalItems } = useCart();
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [orderForm, setOrderForm] = useState({
    customerName: user?.fullName || "",
    customerPhone: user?.phone || "",
    customerAddress: user?.address || "",
    notes: "",
    paymentMethod: "cash_on_delivery"
  });

  const createOrderMutation = useMutation({
    mutationFn: async () => {
      // إنشاء طلب جديد
      const orderResponse = await apiRequest('POST', '/api/orders', {
        customerId: user?.id || null,
        total: getTotalPrice(),
        status: 'pending',
        customerName: orderForm.customerName,
        customerPhone: orderForm.customerPhone,
        customerAddress: orderForm.customerAddress,
        notes: orderForm.notes,
        paymentMethod: orderForm.paymentMethod
      });

      // إضافة عناصر الطلب
      for (const item of items) {
        await apiRequest('POST', '/api/order-items', {
          orderId: orderResponse.id,
          productId: item.productId,
          quantity: item.quantity,
          price: item.price
        });

        // تحديث إحصائيات المبيعات
        await apiRequest('POST', '/api/product-stats', {
          productId: item.productId,
          soldQuantity: item.quantity
        });
      }

      return orderResponse;
    },
    onSuccess: (order) => {
      toast({
        title: "تم إنشاء الطلب بنجاح!",
        description: `رقم الطلب: ${order.id}. سيتم التواصل معك قريباً لتأكيد الطلب.`,
      });
      clearCart();
      setIsCheckoutOpen(false);
      setLocation(`/order-success/${order.id}`);
    },
    onError: (error: any) => {
      toast({
        title: "فشل في إنشاء الطلب",
        description: error.message || "حدث خطأ أثناء إنشاء الطلب، يرجى المحاولة مرة أخرى",
        variant: "destructive",
      });
    },
  });

  const handleQuantityChange = (productId: number, newQuantity: number) => {
    if (newQuantity <= 0) {
      removeItem(productId);
    } else {
      updateQuantity(productId, newQuantity);
    }
  };

  const isFormValid = () => {
    return orderForm.customerName.trim() && 
           orderForm.customerPhone.trim() && 
           orderForm.customerAddress.trim();
  };

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50" dir="rtl">
        <div className="bg-white shadow-sm sticky top-0 z-10">
          <div className="p-4 flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => setLocation("/")}
            >
              <ArrowRight className="h-5 w-5" />
            </Button>
            <h1 className="text-xl font-bold">عربة التسوق</h1>
          </div>
        </div>

        <div className="text-center py-12">
          <ShoppingCart className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-gray-900 mb-2">عربة التسوق فارغة</h2>
          <p className="text-gray-600 mb-4">أضف بعض المنتجات لتبدأ التسوق</p>
          <Button onClick={() => setLocation("/")}>
            تصفح المنتجات
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      {/* Header */}
      <div className="bg-white shadow-sm sticky top-0 z-10">
        <div className="p-4 flex items-center gap-3">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => setLocation("/")}
          >
            <ArrowRight className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-bold">عربة التسوق</h1>
          <Badge variant="secondary" className="mr-auto">
            {getTotalItems()} منتج
          </Badge>
        </div>
      </div>

      <div className="p-4 pb-32">
        <div className="space-y-4">
          {items.map((item) => (
            <Card key={item.productId} className="overflow-hidden">
              <CardContent className="p-4">
                <div className="flex gap-4">
                  {/* صورة المنتج */}
                  <div 
                    className="w-20 h-20 flex-shrink-0 cursor-pointer"
                    onClick={() => setLocation(`/product/${item.productId}`)}
                  >
                    {item.imageUrl ? (
                      <img 
                        src={item.imageUrl} 
                        alt={item.productName}
                        className="w-full h-full object-cover rounded-lg"
                      />
                    ) : (
                      <div className="w-full h-full bg-gray-100 rounded-lg flex items-center justify-center">
                        <Package className="w-8 h-8 text-gray-400" />
                      </div>
                    )}
                  </div>

                  {/* معلومات المنتج */}
                  <div className="flex-1">
                    <div className="flex justify-between items-start mb-2">
                      <h3 
                        className="font-semibold text-gray-900 cursor-pointer hover:text-purple-600"
                        onClick={() => setLocation(`/product/${item.productId}`)}
                      >
                        {item.productName}
                      </h3>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeItem(item.productId)}
                      >
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </Button>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <div className="text-lg font-bold text-purple-600">
                          {parseFloat(item.price).toLocaleString()} د.ع
                        </div>
                        <div className="text-sm text-gray-500">
                          الإجمالي: {(parseFloat(item.price) * item.quantity).toLocaleString()} د.ع
                        </div>
                      </div>

                      {/* محدد الكمية */}
                      <div className="flex items-center bg-gray-100 rounded-lg">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleQuantityChange(item.productId, item.quantity - 1)}
                        >
                          <Minus className="w-4 h-4" />
                        </Button>
                        
                        <span className="mx-3 text-lg font-semibold min-w-[2rem] text-center">
                          {item.quantity}
                        </span>
                        
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleQuantityChange(item.productId, item.quantity + 1)}
                        >
                          <Plus className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* ملخص الطلب */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>ملخص الطلب</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>عدد المنتجات:</span>
                <span>{getTotalItems()} منتج</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>المجموع الفرعي:</span>
                <span>{getTotalPrice().toLocaleString()} د.ع</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>رسوم التوصيل:</span>
                <span className="text-green-600">مجاني</span>
              </div>
              <div className="border-t pt-2">
                <div className="flex justify-between text-lg font-bold">
                  <span>المجموع الكلي:</span>
                  <span className="text-purple-600">{getTotalPrice().toLocaleString()} د.ع</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* أزرار الإجراءات السفلية */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4">
        <div className="flex gap-3">
          <Button 
            variant="outline" 
            className="flex-1"
            onClick={clearCart}
          >
            إفراغ العربة
          </Button>
          
          <Dialog open={isCheckoutOpen} onOpenChange={setIsCheckoutOpen}>
            <DialogTrigger asChild>
              <Button className="flex-1 bg-purple-600 hover:bg-purple-700">
                <CreditCard className="w-4 h-4 ml-2" />
                إتمام الطلب
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md max-h-screen overflow-y-auto">
              <DialogHeader>
                <DialogTitle>إتمام الطلب</DialogTitle>
              </DialogHeader>
              
              <div className="space-y-4">
                <div>
                  <Label htmlFor="customer-name">الاسم الكامل *</Label>
                  <div className="relative">
                    <User className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      id="customer-name"
                      value={orderForm.customerName}
                      onChange={(e) => setOrderForm({...orderForm, customerName: e.target.value})}
                      placeholder="أدخل اسمك الكامل"
                      className="pr-10"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="customer-phone">رقم الهاتف *</Label>
                  <div className="relative">
                    <Phone className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      id="customer-phone"
                      value={orderForm.customerPhone}
                      onChange={(e) => setOrderForm({...orderForm, customerPhone: e.target.value})}
                      placeholder="أدخل رقم هاتفك"
                      className="pr-10"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="customer-address">العنوان الكامل *</Label>
                  <div className="relative">
                    <MapPin className="absolute right-3 top-3 text-gray-400 w-4 h-4" />
                    <Textarea
                      id="customer-address"
                      value={orderForm.customerAddress}
                      onChange={(e) => setOrderForm({...orderForm, customerAddress: e.target.value})}
                      placeholder="أدخل عنوانك الكامل بالتفصيل"
                      rows={3}
                      className="pr-10"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="notes">ملاحظات إضافية</Label>
                  <Textarea
                    id="notes"
                    value={orderForm.notes}
                    onChange={(e) => setOrderForm({...orderForm, notes: e.target.value})}
                    placeholder="أي ملاحظات إضافية للطلب (اختياري)"
                    rows={2}
                  />
                </div>

                {/* طريقة الدفع */}
                <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                  <div className="flex items-center gap-3">
                    <CreditCard className="w-5 h-5 text-green-600" />
                    <div>
                      <h3 className="font-semibold text-green-800">الدفع عند الاستلام</h3>
                      <p className="text-sm text-green-600">
                        ادفع نقداً عند استلام طلبك
                      </p>
                    </div>
                  </div>
                </div>

                {/* ملخص الطلب */}
                <div className="p-4 bg-gray-50 rounded-lg">
                  <h3 className="font-semibold mb-2">ملخص الطلب</h3>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span>عدد المنتجات:</span>
                      <span>{getTotalItems()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>المجموع:</span>
                      <span className="font-bold">{getTotalPrice().toLocaleString()} د.ع</span>
                    </div>
                    <div className="flex justify-between">
                      <span>التوصيل:</span>
                      <span className="text-green-600">مجاني</span>
                    </div>
                    <div className="border-t pt-1 mt-2">
                      <div className="flex justify-between font-bold">
                        <span>المجموع الكلي:</span>
                        <span>{getTotalPrice().toLocaleString()} د.ع</span>
                      </div>
                    </div>
                  </div>
                </div>

                <Button
                  onClick={() => createOrderMutation.mutate()}
                  disabled={!isFormValid() || createOrderMutation.isPending}
                  className="w-full bg-purple-600 hover:bg-purple-700"
                >
                  {createOrderMutation.isPending ? "جاري إنشاء الطلب..." : "تأكيد الطلب"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>
    </div>
  );
};