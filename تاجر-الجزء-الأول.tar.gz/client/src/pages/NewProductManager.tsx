import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Upload, Save, ArrowLeft } from "lucide-react";
import { Link, useLocation } from "wouter";

export default function NewProductManager() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();
  
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: '',
    minPrice: '',
    maxPrice: '',
    stock: '0',
    categoryId: '',
    imageUrl: ''
  });

  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string>('');
  const [selectedAdditionalImages, setSelectedAdditionalImages] = useState<File[]>([]);
  const [additionalPreviewUrls, setAdditionalPreviewUrls] = useState<string[]>([]);

  // جلب الفئات
  const { data: categories = [] } = useQuery<any[]>({
    queryKey: ['/api/categories'],
  });

  // رفع الصورة
  const uploadImageMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('image', file);
      
      const response = await fetch('/api/upload-image', {
        method: 'POST',
        body: formData
      });
      
      if (!response.ok) throw new Error('فشل في رفع الصورة');
      return response.json();
    },
    onSuccess: (data) => {
      setFormData(prev => ({ ...prev, imageUrl: data.url }));
      setPreviewUrl(data.url);
      toast({
        title: "تم رفع الصورة! ✅",
        description: "يمكنك الآن حفظ المنتج",
      });
    },
    onError: () => {
      toast({
        title: "خطأ في رفع الصورة",
        description: "حاول مرة أخرى",
        variant: "destructive"
      });
    }
  });

  // إضافة المنتج
  const createProductMutation = useMutation({
    mutationFn: async (productData: any) => {
      // رفع الصور الإضافية أولاً
      let additionalImageUrls: string[] = [];
      
      if (selectedAdditionalImages.length > 0) {
        const uploadPromises = selectedAdditionalImages.map(async (file) => {
          const formData = new FormData();
          formData.append('image', file);
          
          const response = await fetch('/api/upload-image', {
            method: 'POST',
            body: formData
          });
          
          if (response.ok) {
            const result = await response.json();
            return result.url;
          }
          return null;
        });
        
        const results = await Promise.all(uploadPromises);
        additionalImageUrls = results.filter(url => url !== null);
      }
      
      const response = await fetch('/api/products/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...productData,
          additionalImages: additionalImageUrls
        })
      });
      
      if (!response.ok) throw new Error('فشل في إضافة المنتج');
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "تم إضافة المنتج بنجاح! 🎉",
        description: `المنتج "${data.name}" متاح الآن في المتجر`,
      });
      
      // إعادة تعيين النموذج
      setFormData({
        name: '',
        description: '',
        price: '',
        minPrice: '',
        maxPrice: '',
        stock: '0',
        categoryId: '',
        imageUrl: ''
      });
      setPreviewUrl('');
      setSelectedImage(null);
      setSelectedAdditionalImages([]);
      setAdditionalPreviewUrls([]);
      
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
    },
    onError: () => {
      toast({
        title: "خطأ في إضافة المنتج",
        description: "حاول مرة أخرى",
        variant: "destructive"
      });
    }
  });

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedImage(file);
      // معاينة فورية
      const reader = new FileReader();
      reader.onload = (e) => {
        setPreviewUrl(e.target?.result as string);
      };
      reader.readAsDataURL(file);
      
      uploadImageMutation.mutate(file);
    }
  };

  const handleAdditionalImagesUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length > 0) {
      // حد أقصى صورتان إضافيتان
      const limitedFiles = files.slice(0, 2);
      setSelectedAdditionalImages(limitedFiles);
      
      // معاينة فورية للصور الإضافية
      const promises = limitedFiles.map(file => {
        return new Promise<string>((resolve) => {
          const reader = new FileReader();
          reader.onload = (e) => resolve(e.target?.result as string);
          reader.readAsDataURL(file);
        });
      });
      
      Promise.all(promises).then(setAdditionalPreviewUrls);
    }
  };

  const removeAdditionalImage = (index: number) => {
    const newFiles = selectedAdditionalImages.filter((_, i) => i !== index);
    const newPreviews = additionalPreviewUrls.filter((_, i) => i !== index);
    setSelectedAdditionalImages(newFiles);
    setAdditionalPreviewUrls(newPreviews);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.price || !formData.minPrice || !formData.maxPrice) {
      toast({
        title: "بيانات ناقصة",
        description: "يرجى ملء جميع الحقول المطلوبة",
        variant: "destructive"
      });
      return;
    }

    createProductMutation.mutate({
      name: formData.name,
      description: formData.description,
      price: parseFloat(formData.price),
      minPrice: parseFloat(formData.minPrice),
      maxPrice: parseFloat(formData.maxPrice),
      stock: parseInt(formData.stock) || 0,
      imageUrl: formData.imageUrl,
      categoryId: 1,
      colors: ['أبيض'],
      sku: `SKU-${Date.now()}`,
      status: 'active'
    });
  };

  const handleInputChange = (field: string, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-gray-900">إضافة منتج جديد</h1>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setLocation('/store-management')}
          >
            <ArrowLeft className="h-4 w-4 ml-2" />
            العودة لإدارة المتجر
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>بيانات المنتج</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* اسم المنتج */}
              <div className="space-y-2">
                <Label htmlFor="name">اسم المنتج *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  placeholder="أدخل اسم المنتج"
                  required
                />
              </div>

              {/* وصف المنتج */}
              <div className="space-y-2">
                <Label htmlFor="description">وصف المنتج</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  placeholder="أدخل وصف المنتج"
                  rows={3}
                />
              </div>

              {/* الأسعار */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="price" className="text-purple-600 font-semibold">
                    سعر الجملة (دينار) *
                  </Label>
                  <Input
                    id="price"
                    type="number"
                    value={formData.price}
                    onChange={(e) => handleInputChange('price', e.target.value)}
                    placeholder="0"
                    min="0"
                    step="0.01"
                    className="border-purple-200 focus:border-purple-500 focus:ring-purple-500 text-purple-700 font-semibold text-left"
                    style={{ direction: 'ltr' }}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="minPrice" className="text-blue-600 font-semibold">
                    الحد الأدنى (دينار) *
                  </Label>
                  <Input
                    id="minPrice"
                    type="number"
                    value={formData.minPrice || ''}
                    onChange={(e) => handleInputChange('minPrice', e.target.value)}
                    placeholder="0"
                    min="0"
                    step="0.01"
                    className="border-blue-200 focus:border-blue-500 focus:ring-blue-500 text-blue-700 font-semibold text-left"
                    style={{ direction: 'ltr' }}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="maxPrice" className="text-green-600 font-semibold">
                    الحد الأعلى (دينار) *
                  </Label>
                  <Input
                    id="maxPrice"
                    type="number"
                    value={formData.maxPrice || ''}
                    onChange={(e) => handleInputChange('maxPrice', e.target.value)}
                    placeholder="0"
                    min="0"
                    step="0.01"
                    className="border-green-200 focus:border-green-500 focus:ring-green-500 text-green-700 font-semibold text-left"
                    style={{ direction: 'ltr' }}
                    required
                  />
                </div>
              </div>

              {/* الكمية */}
              <div className="space-y-2">
                <Label htmlFor="stock">الكمية المتاحة</Label>
                <Input
                  id="stock"
                  type="text"
                  value={formData.stock}
                  onChange={(e) => {
                    // السماح بالأرقام الإنجليزية فقط
                    const value = e.target.value.replace(/[^\d]/g, '');
                    handleInputChange('stock', value);
                  }}
                  placeholder="0"
                  className="text-left max-w-xs"
                  style={{ direction: 'ltr', fontFamily: 'monospace' }}
                  inputMode="numeric"
                />
              </div>

              {/* الفئة */}
              <div className="space-y-2">
                <Label htmlFor="categoryId">الفئة</Label>
                <Select 
                  value={formData.categoryId?.toString() || ''} 
                  onValueChange={(value) => handleInputChange('categoryId', parseInt(value))}
                >
                  <SelectTrigger className="text-right">
                    <SelectValue placeholder="اختر الفئة" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories?.map((category: any) => (
                      <SelectItem key={category.id} value={category.id.toString()}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* رفع الصورة */}
              <div className="space-y-2">
                <Label htmlFor="image">صورة المنتج</Label>
                <div className="flex flex-col space-y-4">
                  <div className="flex items-center space-x-4">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => document.getElementById('image-upload')?.click()}
                      disabled={uploadImageMutation.isPending}
                      className="flex items-center space-x-2"
                    >
                      <Upload className="h-4 w-4" />
                      <span>
                        {uploadImageMutation.isPending ? 'جاري الرفع...' : 'اختر صورة'}
                      </span>
                    </Button>
                    <input
                      id="image-upload"
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                    />
                  </div>

                  {/* معاينة الصورة */}
                  {previewUrl && (
                    <div className="border rounded-lg p-4">
                      <img
                        src={previewUrl}
                        alt="معاينة"
                        className="max-w-48 max-h-48 object-cover rounded"
                      />
                    </div>
                  )}
                </div>
              </div>

              {/* الصور الإضافية */}
              <div className="space-y-2">
                <Label htmlFor="additional-images">الصور الإضافية (حتى صورتان)</Label>
                <div className="flex flex-col space-y-4">
                  <div className="flex items-center space-x-4">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => document.getElementById('additional-images-upload')?.click()}
                      className="flex items-center space-x-2"
                    >
                      <Upload className="h-4 w-4" />
                      <span>اختر صور إضافية</span>
                    </Button>
                    <input
                      id="additional-images-upload"
                      type="file"
                      accept="image/*"
                      multiple
                      onChange={handleAdditionalImagesUpload}
                      className="hidden"
                    />
                  </div>

                  {/* معاينة الصور الإضافية */}
                  {additionalPreviewUrls.length > 0 && (
                    <div className="space-y-2">
                      <p className="text-sm text-gray-600">الصور الإضافية:</p>
                      <div className="flex flex-wrap gap-4">
                        {additionalPreviewUrls.map((url, index) => (
                          <div key={index} className="relative border rounded-lg p-2">
                            <img
                              src={url}
                              alt={`صورة إضافية ${index + 1}`}
                              className="w-24 h-24 object-cover rounded"
                            />
                            <Button
                              type="button"
                              variant="destructive"
                              size="sm"
                              onClick={() => removeAdditionalImage(index)}
                              className="absolute -top-2 -right-2 h-6 w-6 p-0 rounded-full"
                            >
                              ×
                            </Button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* زر الحفظ */}
              <Button
                type="submit"
                className="w-full"
                disabled={createProductMutation.isPending}
              >
                <Save className="h-4 w-4 ml-2" />
                {createProductMutation.isPending ? 'جاري الحفظ...' : 'إضافة المنتج'}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}