import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { 
  Settings, 
  LogOut, 
  Moon, 
  Sun, 
  Globe, 
  User,
  Shield,
  Database,
  Palette,
  ArrowLeft
} from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { useLocation } from 'wouter';

export const AdminUserSettingsPage = () => {
  const { logout, user } = useAuth();
  const [, setLocation] = useLocation();
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [language, setLanguage] = useState('ar');

  const handleLogout = () => {
    logout();
    setLocation('/login');
  };

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    if (!isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  const changeLanguage = (newLanguage: string) => {
    setLanguage(newLanguage);
    // هنا يمكن إضافة منطق تغيير اللغة
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-purple-600 rounded-xl flex items-center justify-center">
            <Settings className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">إعدادات المدير</h1>
            <p className="text-slate-600 dark:text-slate-400">إدارة الحساب والتفضيلات الإدارية</p>
          </div>
        </div>
        
        <Button 
          variant="ghost" 
          size="sm"
          onClick={() => setLocation('/store-management')}
          className="flex items-center gap-2"
        >
          <ArrowLeft className="h-4 w-4" />
          العودة لإدارة المتجر
        </Button>
      </div>

      {/* معلومات المدير */}
      <Card className="dark:bg-slate-800 dark:border-slate-700">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-slate-900 dark:text-white">
            <Shield className="w-5 h-5" />
            معلومات الحساب الإداري
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-700 rounded-lg">
            <div>
              <p className="font-medium text-slate-900 dark:text-white">رقم الهاتف</p>
              <p className="text-slate-600 dark:text-slate-400">{user?.phone || 'غير محدد'}</p>
            </div>
            <Badge variant="default" className="bg-green-500 text-white">
              مدير
            </Badge>
          </div>
          <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-700 rounded-lg">
            <div>
              <p className="font-medium text-slate-900 dark:text-white">نوع الحساب</p>
              <p className="text-slate-600 dark:text-slate-400">مدير النظام</p>
            </div>
            <Badge variant="outline" className="border-purple-500 text-purple-600 dark:border-purple-400 dark:text-purple-400">
              صلاحيات كاملة
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* إعدادات العرض */}
      <Card className="dark:bg-slate-800 dark:border-slate-700">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-slate-900 dark:text-white">
            <Palette className="w-5 h-5" />
            إعدادات العرض والواجهة
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* الوضع المظلم */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {isDarkMode ? (
                <Moon className="w-5 h-5 text-slate-600 dark:text-slate-400" />
              ) : (
                <Sun className="w-5 h-5 text-slate-600 dark:text-slate-400" />
              )}
              <div>
                <p className="font-medium text-slate-900 dark:text-white">الوضع المظلم</p>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  تفعيل الوضع المظلم لراحة العين
                </p>
              </div>
            </div>
            <Switch
              checked={isDarkMode}
              onCheckedChange={toggleDarkMode}
            />
          </div>

          {/* اللغة */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Globe className="w-5 h-5 text-slate-600 dark:text-slate-400" />
              <div>
                <p className="font-medium text-slate-900 dark:text-white">لغة الواجهة</p>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  تغيير لغة لوحة التحكم
                </p>
              </div>
            </div>
            <Select value={language} onValueChange={changeLanguage}>
              <SelectTrigger className="w-32 dark:bg-slate-700 dark:border-slate-600">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="dark:bg-slate-800 dark:border-slate-700">
                <SelectItem value="ar">العربية</SelectItem>
                <SelectItem value="en">English</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* إعدادات النظام */}
      <Card className="dark:bg-slate-800 dark:border-slate-700">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-slate-900 dark:text-white">
            <Database className="w-5 h-5" />
            إعدادات النظام
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Button
            variant="outline"
            className="w-full justify-start dark:border-slate-600 dark:text-slate-300 dark:hover:bg-slate-700"
            onClick={() => setLocation('/app-settings')}
          >
            <Settings className="w-4 h-4 ml-2" />
            إعدادات التطبيق العامة
          </Button>
          
          <Button
            variant="outline"
            className="w-full justify-start dark:border-slate-600 dark:text-slate-300 dark:hover:bg-slate-700"
            onClick={() => setLocation('/users')}
          >
            <User className="w-4 h-4 ml-2" />
            إدارة المستخدمين
          </Button>

          <Button
            variant="outline"
            className="w-full justify-start dark:border-slate-600 dark:text-slate-300 dark:hover:bg-slate-700"
            onClick={() => setLocation('/support')}
          >
            <Shield className="w-4 h-4 ml-2" />
            إدارة الدعم الفني
          </Button>
        </CardContent>
      </Card>

      {/* تسجيل الخروج */}
      <Card className="border-red-200 dark:border-red-800 dark:bg-slate-800">
        <CardContent className="pt-6">
          <Button
            variant="destructive"
            className="w-full"
            onClick={handleLogout}
          >
            <LogOut className="w-4 h-4 ml-2" />
            تسجيل الخروج من لوحة التحكم
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};