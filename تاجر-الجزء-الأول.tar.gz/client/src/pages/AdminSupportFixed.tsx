import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  MessageCircle, 
  Send, 
  Search, 
  User, 
  Trash2, 
  CheckCircle, 
  RefreshCw,
  Loader2
} from 'lucide-react';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'support';
  timestamp: Date;
  status?: 'sent' | 'delivered' | 'read';
}

interface CustomerChat {
  customerId: string;
  customerName: string;
  customerPhone: string;
  messages: Message[];
  lastMessage: string;
  lastMessageTime: Date;
  unreadCount: number;
  isReadByAdmin: boolean;
}

export default function AdminSupportFixed() {
  const [chats, setChats] = useState<CustomerChat[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState<CustomerChat | null>(null);
  const [newMessage, setNewMessage] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // تحميل رسائل الدعم من Firebase
  const loadSupportMessages = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/support-messages');
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      console.log('📥 تم جلب رسائل الدعم من Firebase:', data.length);
      
      if (!data || data.length === 0) {
        console.log('لا توجد رسائل');
        setChats([]);
        return;
      }
      
      // تجميع الرسائل حسب العملاء
      const customerChats: { [key: string]: CustomerChat } = {};
      
      data.forEach((msg: any) => {
        const customerId = msg.customerPhone;
        
        if (!customerChats[customerId]) {
          customerChats[customerId] = {
            customerId,
            customerName: msg.customerName || 'عميل غير معروف',
            customerPhone: msg.customerPhone,
            messages: [],
            lastMessage: '',
            lastMessageTime: new Date(msg.createdAt),
            unreadCount: 0,
            isReadByAdmin: msg.isReadByAdmin || false
          };
        }
        
        customerChats[customerId].messages.push({
          id: msg.id,
          text: msg.message || '',
          sender: msg.isAdminReply ? 'support' : 'user',
          timestamp: new Date(msg.createdAt),
          status: 'delivered'
        });
        
        // تحديث آخر رسالة
        const msgTime = new Date(msg.createdAt);
        if (msgTime > customerChats[customerId].lastMessageTime) {
          customerChats[customerId].lastMessage = msg.message || '';
          customerChats[customerId].lastMessageTime = msgTime;
          customerChats[customerId].isReadByAdmin = msg.isReadByAdmin || false;
        }
        
        // عد الرسائل غير المقروءة
        if (!msg.isReadByAdmin && !msg.isAdminReply) {
          customerChats[customerId].unreadCount++;
        }
      });
      
      // ترتيب الرسائل داخل كل محادثة حسب الوقت
      Object.values(customerChats).forEach(chat => {
        chat.messages.sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
      });
      
      // تحويل إلى مصفوفة وترتيب حسب آخر رسالة
      const chatArray = Object.values(customerChats).sort(
        (a, b) => b.lastMessageTime.getTime() - a.lastMessageTime.getTime()
      );
      
      console.log('📊 تم تجميع المحادثات:', chatArray);
      setChats(chatArray);
      
      // اختيار العميل الأول تلقائياً إذا لم يتم اختيار عميل
      if (chatArray.length > 0 && !selectedCustomer) {
        setSelectedCustomer(chatArray[0]);
      }
    } catch (error) {
      console.error('❌ خطأ في جلب رسائل الدعم:', error);
      setChats([]);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadSupportMessages();
    // إعادة تحميل كل 5 ثوان
    const interval = setInterval(loadSupportMessages, 5000);
    return () => clearInterval(interval);
  }, []);

  // إرسال رد من الإدارة
  const sendAdminReply = async () => {
    if (!newMessage.trim() || !selectedCustomer) return;

    try {
      const response = await fetch('/api/support-messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          customerPhone: selectedCustomer.customerPhone,
          customerName: selectedCustomer.customerName,
          message: newMessage.trim(),
          isAdminReply: true
        })
      });

      if (response.ok) {
        const adminMessage: Message = {
          id: `admin-${Date.now()}`,
          text: newMessage.trim(),
          sender: 'support',
          timestamp: new Date(),
          status: 'sent'
        };
        
        // تحديث المحادثة المحلية
        const updatedMessages = [...selectedCustomer.messages, adminMessage];
        
        setSelectedCustomer({
          ...selectedCustomer,
          messages: updatedMessages,
          lastMessage: newMessage.trim(),
          lastMessageTime: new Date()
        });

        // تحديث قائمة المحادثات
        setChats(prev => prev.map(chat => 
          chat.customerId === selectedCustomer.customerId 
            ? {
                ...chat,
                messages: updatedMessages,
                lastMessage: newMessage.trim(),
                lastMessageTime: new Date()
              }
            : chat
        ));

        setNewMessage('');
        console.log('✅ تم إرسال الرد بنجاح');
      }
    } catch (error) {
      console.error('❌ خطأ في إرسال الرد:', error);
    }
  };

  // حذف محادثة العميل
  const deleteCustomerChat = async (customerId: string) => {
    const customerChat = chats.find(chat => chat.customerId === customerId);
    if (!customerChat) return;

    try {
      const response = await fetch('/api/support-messages/delete-completely', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          customerPhone: customerChat.customerPhone
        })
      });

      if (response.ok) {
        setChats(prev => prev.filter(chat => chat.customerId !== customerId));
        if (selectedCustomer?.customerId === customerId) {
          setSelectedCustomer(null);
        }
        console.log('✅ تم حذف المحادثة بنجاح');
      }
    } catch (error) {
      console.error('❌ خطأ في حذف المحادثة:', error);
    }
  };

  // تحديد محادثة كمقروءة
  const markAsRead = async (customerId: string) => {
    const customerChat = chats.find(chat => chat.customerId === customerId);
    if (!customerChat) return;

    try {
      const response = await fetch('/api/support-messages/mark-read', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          customerPhone: customerChat.customerPhone
        })
      });

      if (response.ok) {
        setChats(prev => prev.map(chat => 
          chat.customerId === customerId 
            ? { ...chat, isReadByAdmin: true, unreadCount: 0 }
            : chat
        ));
        
        if (selectedCustomer?.customerId === customerId) {
          const updatedMessages = selectedCustomer.messages.map(msg => 
            msg.sender === 'user' ? { ...msg, status: 'read' as const } : msg
          );
          setSelectedCustomer({
            ...selectedCustomer,
            messages: updatedMessages,
            isReadByAdmin: true,
            unreadCount: 0
          });
        }
      }
    } catch (error) {
      console.error('❌ خطأ في تحديث حالة القراءة:', error);
    }
  };

  const selectCustomer = (chat: CustomerChat) => {
    setSelectedCustomer(chat);
    if (!chat.isReadByAdmin) {
      markAsRead(chat.customerId);
    }
  };

  const formatTime = (date: Date) => {
    return new Intl.DateTimeFormat('ar-SA', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    }).format(date);
  };

  const formatDate = (date: Date) => {
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    
    if (date.toDateString() === today.toDateString()) {
      return 'اليوم';
    } else if (date.toDateString() === yesterday.toDateString()) {
      return 'أمس';
    } else {
      return new Intl.DateTimeFormat('ar-SA', {
        month: 'short',
        day: 'numeric'
      }).format(date);
    }
  };

  // تصفية المحادثات حسب البحث
  const filteredChats = chats.filter(chat => {
    if (!searchTerm.trim()) return true;
    const searchLower = searchTerm.toLowerCase();
    return (
      chat.customerName.toLowerCase().includes(searchLower) ||
      chat.customerPhone.includes(searchTerm) ||
      chat.messages.some(msg => msg.text.toLowerCase().includes(searchLower))
    );
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
      {/* رأس الصفحة المحدث */}
      <div className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between py-4 gap-4">
            <div className="flex-1">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                  <MessageCircle className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">إدارة الدعم الفني</h1>
                  <p className="text-gray-600 text-sm">
                    مساعدة العملاء وإدارة المحادثات • تاجر
                  </p>
                </div>
              </div>
            </div>
            
            {/* شريط البحث والأدوات */}
            <div className="flex items-center gap-3 flex-wrap">
              <div className="relative flex-1 lg:flex-none">
                <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="البحث في المحادثات..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pr-10 pl-4 w-full lg:w-80 bg-gray-50 border-gray-200"
                />
              </div>
              
              <Button onClick={loadSupportMessages} disabled={isLoading} variant="outline" className="flex items-center gap-2">
                <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
                تحديث
              </Button>
              
              {/* إحصائيات سريعة */}
              <div className="flex items-center gap-3 bg-gray-50 rounded-lg px-3 py-2">
                <div className="text-center">
                  <div className="text-lg font-bold text-blue-600">{filteredChats.length}</div>
                  <div className="text-xs text-gray-500">محادثة</div>
                </div>
                <div className="w-px h-8 bg-gray-300"></div>
                <div className="text-center">
                  <div className="text-lg font-bold text-red-600">
                    {filteredChats.filter(chat => !chat.isReadByAdmin).length}
                  </div>
                  <div className="text-xs text-gray-500">غير مقروء</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* المحتوى الرئيسي */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex flex-col xl:flex-row gap-6 h-[calc(100vh-200px)]">
          {/* قائمة المحادثات */}
          <div className="xl:w-96 w-full">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 h-full flex flex-col overflow-hidden">
              {/* رأس قائمة المحادثات */}
              <div className="px-6 py-4 border-b border-gray-100 bg-gradient-to-r from-gray-50 to-white">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-semibold text-gray-900">المحادثات النشطة</h2>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className="bg-blue-100 text-blue-700 text-xs">
                      {filteredChats.length}
                    </Badge>
                    {filteredChats.filter(chat => !chat.isReadByAdmin).length > 0 && (
                      <Badge variant="destructive" className="text-xs animate-pulse">
                        {filteredChats.filter(chat => !chat.isReadByAdmin).length} جديد
                      </Badge>
                    )}
                  </div>
                </div>
              </div>

              {/* قائمة المحادثات */}
              <div className="flex-1 overflow-y-auto">
            {isLoading ? (
              <div className="flex items-center justify-center h-32">
                <Loader2 className="h-5 w-5 animate-spin text-blue-500" />
                <span className="mr-2 text-sm text-gray-600">جاري التحميل...</span>
              </div>
            ) : filteredChats.length === 0 ? (
              <div className="text-center py-8 md:py-12 px-4">
                <MessageCircle className="h-10 md:h-12 w-10 md:w-12 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500 text-sm font-medium">لا توجد محادثات</p>
                <p className="text-xs text-gray-400 mt-1">
                  في انتظار رسائل العملاء الجديدة
                </p>
              </div>
            ) : (
              <div className="p-2 space-y-2">
                {filteredChats.map((chat) => (
                  <Card 
                    key={chat.customerId}
                    className={`cursor-pointer transition-all duration-200 hover:shadow-md border-l-4 ${
                      selectedCustomer?.customerId === chat.customerId 
                        ? 'border-l-blue-500 bg-blue-50 shadow-md' 
                        : chat.unreadCount > 0 
                        ? 'border-l-red-500 bg-red-50' 
                        : 'border-l-gray-200 hover:border-l-blue-300'
                    }`}
                    onClick={() => selectCustomer(chat)}
                  >
                    <CardContent className="p-3">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2 flex-1 min-w-0">
                          <div className="h-8 w-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white text-sm font-bold flex-shrink-0">
                            {chat.customerName.charAt(0)}
                          </div>
                          <div className="flex-1 min-w-0">
                            <h3 className="font-medium text-gray-900 text-sm truncate">
                              {chat.customerName}
                            </h3>
                            <p className="text-xs text-gray-500 truncate">
                              {chat.customerPhone}
                            </p>
                          </div>
                        </div>
                        <div className="flex flex-col items-end gap-1 flex-shrink-0">
                          <span className="text-xs text-gray-500">
                            {formatDate(chat.lastMessageTime)}
                          </span>
                          {chat.unreadCount > 0 && (
                            <Badge variant="destructive" className="text-xs h-5 w-5 p-0 flex items-center justify-center rounded-full">
                              {chat.unreadCount}
                            </Badge>
                          )}
                        </div>
                      </div>
                      <p className="text-xs text-gray-600 line-clamp-2 break-words">
                        {chat.lastMessage}
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* منطقة المحادثة الرئيسية */}
        <div className="flex-1 bg-white rounded-lg shadow-sm border flex flex-col min-w-0">
          {selectedCustomer ? (
            <>
              {/* رأس المحادثة */}
              <div className="border-b p-3 md:p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between bg-gradient-to-r from-blue-50 to-purple-50 gap-3 sm:gap-0">
                <div className="flex items-center gap-3">
                  <div className="h-8 md:h-10 w-8 md:w-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-sm md:text-base">
                    {selectedCustomer.customerName.charAt(0)}
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 text-sm md:text-base">{selectedCustomer.customerName}</h3>
                    <p className="text-xs md:text-sm text-gray-600">{selectedCustomer.customerPhone}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    {selectedCustomer.isReadByAdmin ? (
                      <Badge variant="outline" className="text-xs">مقروءة</Badge>
                    ) : (
                      <Badge variant="destructive" className="text-xs">جديدة</Badge>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => markAsRead(selectedCustomer.customerId)}
                    className="text-xs flex-1 sm:flex-none"
                  >
                    <CheckCircle className="h-3 w-3 ml-1" />
                    مقروءة
                  </Button>
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => deleteCustomerChat(selectedCustomer.customerId)}
                    className="text-xs flex-1 sm:flex-none"
                  >
                    <Trash2 className="h-3 w-3 ml-1" />
                    حذف
                  </Button>
                </div>
              </div>

              {/* منطقة الرسائل */}
              <div className="flex-1 p-2 md:p-4 overflow-y-auto bg-gradient-to-b from-gray-50 to-white">
                <div className="space-y-3 md:space-y-4">
                  {selectedCustomer.messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${message.sender === 'support' ? 'justify-start' : 'justify-end'}`}
                    >
                      <div
                        className={`max-w-[85%] md:max-w-[75%] p-2.5 md:p-3 rounded-lg shadow-sm ${
                          message.sender === 'support'
                            ? 'bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-br-sm'
                            : 'bg-white text-gray-900 border border-gray-200 rounded-bl-sm'
                        }`}
                      >
                        <p className="text-xs md:text-sm leading-relaxed">{message.text}</p>
                        <div className="flex items-center justify-between mt-1.5 md:mt-2">
                          <span className={`text-xs ${
                            message.sender === 'support' ? 'text-blue-100' : 'text-gray-500'
                          }`}>
                            {formatTime(message.timestamp)}
                          </span>
                          {message.status && (
                            <span className={`text-xs ${
                              message.sender === 'support' ? 'text-blue-100' : 'text-gray-500'
                            }`}>
                              {message.status === 'sent' && '✓'}
                              {message.status === 'delivered' && '✓✓'}
                              {message.status === 'read' && '✓✓'}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* منطقة الإرسال */}
              <div className="border-t p-3 md:p-4 bg-gray-50">
                <div className="flex gap-2 md:gap-3">
                  <div className="flex-1">
                    <Input
                      placeholder="اكتب ردك هنا..."
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && sendAdminReply()}
                      className="border-gray-300 focus:border-blue-500 focus:ring-blue-500 text-sm md:text-base"
                    />
                  </div>
                  <Button 
                    onClick={sendAdminReply}
                    disabled={!newMessage.trim()}
                    className="px-3 md:px-6 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700"
                    size="sm"
                  >
                    <Send className="h-4 w-4 ml-1" />
                    <span className="hidden sm:inline">إرسال</span>
                  </Button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center bg-gradient-to-br from-gray-50 to-blue-50">
              <div className="text-center">
                <MessageCircle className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">اختر محادثة للبدء</h3>
                <p className="text-gray-500 text-sm">
                  اختر محادثة من القائمة الجانبية لعرض الرسائل والرد عليها
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}