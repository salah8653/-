import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useRoute, useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { 
  ArrowRight, 
  Settings, 
  Eye, 
  Image, 
  FileText, 
  Layout,
  Plus,
  Trash2,
  Save
} from 'lucide-react';
import { queryClient } from '@/lib/queryClient';

export const ProductPageManager = () => {
  const [, params] = useRoute('/admin/product-page/:id');
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('layout');

  // جلب بيانات المنتج
  const { data: product, isLoading } = useQuery({
    queryKey: ['/api/products', params?.id],
    enabled: !!params?.id,
  });

  // جلب بيانات صفحة المنتج المخصصة
  const { data: productPage } = useQuery({
    queryKey: ['/api/product-pages', params?.id],
    enabled: !!params?.id,
  });

  const [pageSettings, setPageSettings] = useState({
    showDescription: true,
    showPrice: true,
    showStock: true,
    showCategory: true,
    showImages: true,
    customSections: [],
    layout: 'default', // default, detailed, minimal
    primaryColor: '#8B5CF6',
    backgroundColor: '#FFFFFF',
    customCSS: '',
    seoTitle: '',
    seoDescription: '',
    showReviews: false,
    showRelatedProducts: true,
  });

  const [customSections, setCustomSections] = useState([]);
  const [imageGallery, setImageGallery] = useState([]);

  // حفظ إعدادات الصفحة
  const savePageMutation = useMutation({
    mutationFn: async (data: any) => {
      return await fetch(`/api/product-pages/${params?.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/product-pages'] });
      toast({
        title: "تم الحفظ",
        description: "تم حفظ إعدادات صفحة المنتج بنجاح",
      });
    },
  });

  const addCustomSection = () => {
    const newSection = {
      id: Date.now(),
      title: 'قسم جديد',
      content: '',
      type: 'text', // text, image, video, list
      visible: true,
      order: customSections.length,
    };
    setCustomSections([...customSections, newSection]);
  };

  const removeCustomSection = (id: number) => {
    setCustomSections(customSections.filter(section => section.id !== id));
  };

  const updateCustomSection = (id: number, updates: any) => {
    setCustomSections(customSections.map(section => 
      section.id === id ? { ...section, ...updates } : section
    ));
  };

  const handleSave = () => {
    const pageData = {
      productId: params?.id,
      settings: pageSettings,
      customSections,
      imageGallery,
      updatedAt: new Date().toISOString(),
    };
    savePageMutation.mutate(pageData);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">المنتج غير موجود</p>
        <Button onClick={() => setLocation('/admin/products')} className="mt-4">
          العودة للمنتجات
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setLocation('/admin/products')}
              >
                <ArrowRight className="w-4 h-4" />
              </Button>
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5" />
                  إدارة صفحة المنتج: {product.name}
                </CardTitle>
                <p className="text-sm text-gray-500 mt-1">
                  خصص صفحة المنتج وإعداداتها
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                onClick={() => setLocation(`/product/${product.id}`)}
              >
                <Eye className="w-4 h-4 ml-2" />
                معاينة الصفحة
              </Button>
              <Button
                onClick={handleSave}
                disabled={savePageMutation.isPending}
              >
                <Save className="w-4 h-4 ml-2" />
                حفظ التغييرات
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Product Info */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-4">
            {product.imageUrl && (
              <img 
                src={product.imageUrl} 
                alt={product.name}
                className="w-16 h-16 object-cover rounded-lg"
              />
            )}
            <div>
              <h3 className="font-semibold text-lg">{product.name}</h3>
              <p className="text-sm text-gray-500">{product.description}</p>
              <Badge variant="secondary" className="mt-1">
                {product.category?.name}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabs for different settings */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="layout">
            <Layout className="w-4 h-4 ml-2" />
            التخطيط
          </TabsTrigger>
          <TabsTrigger value="content">
            <FileText className="w-4 h-4 ml-2" />
            المحتوى
          </TabsTrigger>
          <TabsTrigger value="images">
            <Image className="w-4 h-4 ml-2" />
            الصور
          </TabsTrigger>
          <TabsTrigger value="seo">
            <Settings className="w-4 h-4 ml-2" />
            SEO
          </TabsTrigger>
        </TabsList>

        {/* Layout Settings */}
        <TabsContent value="layout" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>إعدادات التخطيط</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="showDescription">عرض الوصف</Label>
                  <Switch
                    id="showDescription"
                    checked={pageSettings.showDescription}
                    onCheckedChange={(checked) => 
                      setPageSettings({...pageSettings, showDescription: checked})
                    }
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="showPrice">عرض السعر</Label>
                  <Switch
                    id="showPrice"
                    checked={pageSettings.showPrice}
                    onCheckedChange={(checked) => 
                      setPageSettings({...pageSettings, showPrice: checked})
                    }
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="showStock">عرض المخزون</Label>
                  <Switch
                    id="showStock"
                    checked={pageSettings.showStock}
                    onCheckedChange={(checked) => 
                      setPageSettings({...pageSettings, showStock: checked})
                    }
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="showCategory">عرض الفئة</Label>
                  <Switch
                    id="showCategory"
                    checked={pageSettings.showCategory}
                    onCheckedChange={(checked) => 
                      setPageSettings({...pageSettings, showCategory: checked})
                    }
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="primaryColor">اللون الأساسي</Label>
                  <Input
                    id="primaryColor"
                    type="color"
                    value={pageSettings.primaryColor}
                    onChange={(e) => setPageSettings({...pageSettings, primaryColor: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="backgroundColor">لون الخلفية</Label>
                  <Input
                    id="backgroundColor"
                    type="color"
                    value={pageSettings.backgroundColor}
                    onChange={(e) => setPageSettings({...pageSettings, backgroundColor: e.target.value})}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Custom Content */}
        <TabsContent value="content" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>أقسام مخصصة</CardTitle>
                <Button onClick={addCustomSection} size="sm">
                  <Plus className="w-4 h-4 ml-2" />
                  إضافة قسم
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {customSections.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-gray-500">لا توجد أقسام مخصصة</p>
                  <Button onClick={addCustomSection} className="mt-4">
                    إضافة أول قسم
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {customSections.map((section: any) => (
                    <Card key={section.id} className="border-dashed">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-4">
                          <Input
                            value={section.title}
                            onChange={(e) => updateCustomSection(section.id, { title: e.target.value })}
                            placeholder="عنوان القسم"
                            className="max-w-xs"
                          />
                          <div className="flex items-center gap-2">
                            <Switch
                              checked={section.visible}
                              onCheckedChange={(checked) => 
                                updateCustomSection(section.id, { visible: checked })
                              }
                            />
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => removeCustomSection(section.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                        <Textarea
                          value={section.content}
                          onChange={(e) => updateCustomSection(section.id, { content: e.target.value })}
                          placeholder="محتوى القسم..."
                          rows={4}
                        />
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Images */}
        <TabsContent value="images" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>معرض الصور</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <p className="text-gray-500">سيتم إضافة إدارة الصور قريباً</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* SEO */}
        <TabsContent value="seo" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>إعدادات SEO</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="seoTitle">عنوان SEO</Label>
                <Input
                  id="seoTitle"
                  value={pageSettings.seoTitle}
                  onChange={(e) => setPageSettings({...pageSettings, seoTitle: e.target.value})}
                  placeholder="عنوان الصفحة في محركات البحث"
                />
              </div>
              <div>
                <Label htmlFor="seoDescription">وصف SEO</Label>
                <Textarea
                  id="seoDescription"
                  value={pageSettings.seoDescription}
                  onChange={(e) => setPageSettings({...pageSettings, seoDescription: e.target.value})}
                  placeholder="وصف الصفحة في محركات البحث"
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};