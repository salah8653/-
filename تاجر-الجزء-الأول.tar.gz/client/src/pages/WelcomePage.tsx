import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowLeft, ShoppingBag, TrendingUp, Users, Zap, Store, Crown } from "lucide-react";
import logoImage from "@assets/IMG_20250530_180323_709.jpg";

export const WelcomePage = () => {
  const [, setLocation] = useLocation();
  const [currentFeature, setCurrentFeature] = useState(0);

  const features = [
    {
      icon: <ShoppingBag className="w-8 h-8 text-purple-600" />,
      title: "إدارة المنتجات",
      description: "أضف وعدل منتجاتك بسهولة"
    },
    {
      icon: <TrendingUp className="w-8 h-8 text-purple-600" />,
      title: "تتبع الأرباح",
      description: "راقب أرباحك في الوقت الفعلي"
    },
    {
      icon: <Users className="w-8 h-8 text-purple-600" />,
      title: "إدارة العملاء",
      description: "تواصل مع عملائك بفعالية"
    },
    {
      icon: <Zap className="w-8 h-8 text-purple-600" />,
      title: "سرعة ومرونة",
      description: "تطبيق سريع وسهل الاستخدام"
    }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentFeature((prev) => (prev + 1) % features.length);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 flex flex-col items-center justify-center p-4">
      {/* الشعار والعنوان الرئيسي */}
      <div className="text-center mb-12">
        <div className="w-24 h-24 bg-gradient-to-br from-purple-600 to-purple-800 rounded-3xl flex items-center justify-center mb-6 mx-auto shadow-xl border-4 border-purple-200">
          <ShoppingBag className="w-12 h-12 text-white" />
        </div>
        
        <h1 className="text-5xl font-bold text-gray-900 mb-4">
          <span className="bg-gradient-to-r from-purple-600 to-purple-800 bg-clip-text text-transparent">
            تاجر
          </span>
        </h1>
        
        <p className="text-xl text-gray-600 font-medium mb-2">
          استغل وقتك في تحقيق الأرباح
        </p>
        
        <p className="text-lg text-gray-500">
          منصة التجارة الإلكترونية الذكية
        </p>
      </div>

      {/* المميزات المتحركة */}
      <div className="bg-white rounded-2xl shadow-xl p-8 mb-8 max-w-md w-full">
        <div className="text-center">
          <div className="flex justify-center mb-4">
            {features[currentFeature].icon}
          </div>
          <h3 className="text-xl font-bold text-gray-900 mb-2">
            {features[currentFeature].title}
          </h3>
          <p className="text-gray-600">
            {features[currentFeature].description}
          </p>
        </div>
        
        {/* مؤشر التقدم */}
        <div className="flex justify-center mt-6 space-x-2">
          {features.map((_, index) => (
            <div
              key={index}
              className={`w-2 h-2 rounded-full transition-colors duration-300 ${
                index === currentFeature ? 'bg-purple-600' : 'bg-gray-300'
              }`}
            />
          ))}
        </div>
      </div>

      {/* أزرار الإجراءات */}
      <div className="space-y-4 w-full max-w-md">
        <Button
          onClick={() => setLocation("/login")}
          className="w-full bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white py-4 text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300"
        >
          <ArrowLeft className="w-5 h-5 ml-2" />
          ابدأ الآن
        </Button>
        
        <Button
          variant="outline"
          onClick={() => setLocation("/register")}
          className="w-full border-2 border-purple-600 text-purple-600 hover:bg-purple-50 py-4 text-lg font-semibold rounded-xl transition-all duration-300"
        >
          إنشاء حساب جديد
        </Button>
      </div>

      {/* معلومات إضافية */}
      <div className="mt-12 text-center">
        <p className="text-sm text-gray-500">
          منصة آمنة وموثوقة لإدارة تجارتك الإلكترونية
        </p>
      </div>

      {/* تأثيرات بصرية */}
      <div className="absolute top-10 left-10 w-20 h-20 bg-purple-200 rounded-full opacity-50 animate-pulse"></div>
      <div className="absolute bottom-20 right-10 w-16 h-16 bg-blue-200 rounded-full opacity-50 animate-pulse delay-1000"></div>
      <div className="absolute top-1/3 right-20 w-12 h-12 bg-purple-300 rounded-full opacity-30 animate-bounce delay-500"></div>
    </div>
  );
};