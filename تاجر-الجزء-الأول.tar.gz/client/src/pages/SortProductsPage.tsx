import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useLocation } from "wouter";
import { 
  ArrowRight, 
  ArrowLeft,
  Package, 
  Heart,
  TrendingUp,
  TrendingDown,
  DollarSign
} from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { BottomNavigation } from "@/components/BottomNavigation";

type SortOption = 'high-to-low' | 'low-to-high';

export const SortProductsPage = () => {
  const [, setLocation] = useLocation();
  const { language, dir } = useLanguage();
  const [sortBy, setSortBy] = useState<SortOption>('high-to-low');

  const { data: products = [], isLoading } = useQuery({
    queryKey: ["/api/products"],
  });

  const { data: categories = [] } = useQuery({
    queryKey: ["/api/categories"],
  });

  // ترتيب المنتجات حسب السعر
  const sortedProducts = [...(products as any[])].sort((a, b) => {
    const priceA = parseFloat(a.price);
    const priceB = parseFloat(b.price);
    
    if (sortBy === 'high-to-low') {
      return priceB - priceA;
    } else {
      return priceA - priceB;
    }
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
        <BottomNavigation />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50" dir={dir}>
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => setLocation("/")}
            >
              {dir === 'rtl' ? (
                <ArrowRight className="h-5 w-5" />
              ) : (
                <ArrowLeft className="h-5 w-5" />
              )}
            </Button>
            <h1 className="text-xl font-bold text-gray-900">
              {language === 'ar' ? 'ترتيب المنتجات حسب السعر' : 'Sort Products by Price'}
            </h1>
          </div>
        </div>
      </div>

      {/* Sort Options */}
      <div className="p-4 bg-white border-b border-gray-200">
        <div className="flex gap-3">
          <Button
            variant={sortBy === 'high-to-low' ? 'default' : 'outline'}
            className={`flex items-center gap-2 ${
              sortBy === 'high-to-low' 
                ? 'bg-purple-600 text-white' 
                : 'bg-white text-gray-700 border-gray-300'
            }`}
            onClick={() => setSortBy('high-to-low')}
          >
            <TrendingDown className="h-4 w-4" />
            {language === 'ar' ? 'من الأعلى للأدنى' : 'High to Low'}
          </Button>
          
          <Button
            variant={sortBy === 'low-to-high' ? 'default' : 'outline'}
            className={`flex items-center gap-2 ${
              sortBy === 'low-to-high' 
                ? 'bg-purple-600 text-white' 
                : 'bg-white text-gray-700 border-gray-300'
            }`}
            onClick={() => setSortBy('low-to-high')}
          >
            <TrendingUp className="h-4 w-4" />
            {language === 'ar' ? 'من الأدنى للأعلى' : 'Low to High'}
          </Button>
        </div>
      </div>

      {/* Products Grid */}
      <div className="p-4">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <DollarSign className="h-5 w-5 text-purple-600" />
            <span className="text-sm text-gray-600">
              {language === 'ar' 
                ? `${sortedProducts.length} منتج مرتب حسب السعر` 
                : `${sortedProducts.length} products sorted by price`
              }
            </span>
          </div>
          <Badge variant="secondary" className="bg-purple-100 text-purple-800">
            {sortBy === 'high-to-low' 
              ? (language === 'ar' ? 'أعلى → أدنى' : 'High → Low')
              : (language === 'ar' ? 'أدنى → أعلى' : 'Low → High')
            }
          </Badge>
        </div>

        {sortedProducts.length === 0 ? (
          <div className="text-center py-12">
            <Package className="h-16 w-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">
              {language === 'ar' ? 'لا توجد منتجات متاحة' : 'No products available'}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3 pb-20">
            {sortedProducts.map((product: any) => (
              <Card 
                key={product.id} 
                className="border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => setLocation(`/product/${product.id}`)}
              >
                <CardContent className="p-3">
                  <div className="relative">
                    {product.imageUrl ? (
                      <img 
                        src={product.imageUrl} 
                        alt={product.name}
                        className="w-full h-32 object-cover rounded-lg mb-3"
                      />
                    ) : (
                      <div className="w-full h-32 bg-gray-100 rounded-lg mb-3 flex items-center justify-center">
                        <Package className="h-8 w-8 text-gray-400" />
                      </div>
                    )}
                    
                    {/* Price Badge */}
                    <div className="absolute top-2 left-2 bg-purple-600 text-white px-2 py-1 rounded-lg text-xs font-bold">
                      {parseFloat(product.price).toLocaleString()} د.ع
                    </div>

                    {/* Heart Icon */}
                    <Button
                      variant="ghost"
                      size="sm"
                      className="absolute top-2 right-2 h-8 w-8 p-0 bg-white/80 hover:bg-white text-gray-600 hover:text-red-500"
                      onClick={(e) => {
                        e.stopPropagation();
                        // Add save functionality here
                      }}
                    >
                      <Heart className="h-4 w-4" />
                    </Button>
                  </div>

                  <h3 className="font-semibold text-sm text-gray-800 mb-2 line-clamp-2">
                    {product.name}
                  </h3>
                  
                  <p className="text-xs text-gray-500 mb-2">
                    {language === 'ar' 
                      ? `متبقية ${product.stock} قطعة` 
                      : `${product.stock} pieces left`
                    }
                  </p>
                  
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-lg font-bold text-purple-600">
                        {parseFloat(product.price).toLocaleString()} د.ع
                      </span>
                      {product.category?.name && (
                        <Badge variant="outline" className="text-xs">
                          {product.category.name}
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      <BottomNavigation />
    </div>
  );
};