import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Plus, Package, User, Trash2 } from 'lucide-react';
import { apiRequest, queryClient } from '@/lib/queryClient';

const orderSchema = z.object({
  customerName: z.string().min(1, 'اسم العميل مطلوب'),
  customerPhone: z.string().min(1, 'رقم الهاتف مطلوب'),
  customerEmail: z.string().email('بريد إلكتروني غير صحيح').optional().or(z.literal('')),
  customerAddress: z.string().optional(),
  notes: z.string().optional(),
});

type OrderFormData = z.infer<typeof orderSchema>;

interface OrderItem {
  productId: number;
  productName: string;
  price: number;
  quantity: number;
  total: number;
}

export const NewOrderPage = () => {
  const { toast } = useToast();
  const [orderItems, setOrderItems] = useState<OrderItem[]>([]);
  const [selectedProductId, setSelectedProductId] = useState<string>('');
  const [quantity, setQuantity] = useState(1);

  const { data: products = [] } = useQuery({
    queryKey: ['/api/products'],
  });

  const form = useForm<OrderFormData>({
    resolver: zodResolver(orderSchema),
    defaultValues: {
      customerName: '',
      customerPhone: '',
      customerEmail: '',
      customerAddress: '',
      notes: '',
    },
  });

  const createOrderMutation = useMutation({
    mutationFn: async (data: OrderFormData) => {
      // إنشاء العميل أولاً
      const customerResponse = await apiRequest('POST', '/api/customers', {
        name: data.customerName,
        phone: data.customerPhone,
        email: data.customerEmail || undefined,
        address: data.customerAddress || undefined,
      });

      const total = orderItems.reduce((sum, item) => sum + item.total, 0);

      // إنشاء الطلب
      const orderResponse = await apiRequest('POST', '/api/orders', {
        customerId: customerResponse.id,
        total,
        status: 'pending',
        notes: data.notes || undefined,
      });

      // إضافة عناصر الطلب
      for (const item of orderItems) {
        await apiRequest('POST', '/api/order-items', {
          orderId: orderResponse.id,
          productId: item.productId,
          quantity: item.quantity,
          price: item.price,
        });
      }

      return orderResponse;
    },
    onSuccess: () => {
      toast({
        title: "تم إنشاء الطلب بنجاح",
        description: "تم إنشاء الطلب وإضافته لقائمة الطلبات",
      });
      
      // إعادة تعيين النموذج
      form.reset();
      setOrderItems([]);
      setSelectedProductId('');
      setQuantity(1);
      
      // تحديث البيانات
      queryClient.invalidateQueries({ queryKey: ['/api/orders'] });
      queryClient.invalidateQueries({ queryKey: ['/api/customers'] });
    },
    onError: () => {
      toast({
        title: "خطأ في إنشاء الطلب",
        description: "حدث خطأ أثناء إنشاء الطلب. يرجى المحاولة مرة أخرى",
        variant: "destructive",
      });
    },
  });

  const addItemToOrder = () => {
    if (!selectedProductId) {
      toast({
        title: "يرجى اختيار منتج",
        description: "يجب اختيار منتج قبل إضافته للطلب",
        variant: "destructive",
      });
      return;
    }

    const product = Array.isArray(products) ? products.find((p: any) => p.id === parseInt(selectedProductId)) : null;
    if (!product) {
      toast({
        title: "منتج غير موجود",
        description: "المنتج المحدد غير موجود",
        variant: "destructive",
      });
      return;
    }

    const existingItemIndex = orderItems.findIndex(item => item.productId === product.id);
    
    if (existingItemIndex >= 0) {
      // تحديث الكمية للمنتج الموجود
      const updatedItems = [...orderItems];
      updatedItems[existingItemIndex].quantity += quantity;
      updatedItems[existingItemIndex].total = updatedItems[existingItemIndex].quantity * product.price;
      setOrderItems(updatedItems);
    } else {
      // إضافة منتج جديد
      const newItem: OrderItem = {
        productId: product.id,
        productName: product.name,
        price: product.price,
        quantity,
        total: product.price * quantity,
      };
      setOrderItems([...orderItems, newItem]);
    }

    setSelectedProductId('');
    setQuantity(1);
  };

  const removeItemFromOrder = (productId: number) => {
    setOrderItems(orderItems.filter(item => item.productId !== productId));
  };

  const onSubmit = (data: OrderFormData) => {
    if (orderItems.length === 0) {
      toast({
        title: "لا توجد منتجات في الطلب",
        description: "يجب إضافة منتج واحد على الأقل للطلب",
        variant: "destructive",
      });
      return;
    }

    createOrderMutation.mutate(data);
  };

  const totalAmount = orderItems.reduce((sum, item) => sum + item.total, 0);

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
          <Plus className="w-6 h-6 text-blue-600" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-slate-900">إنشاء طلب جديد</h1>
          <p className="text-slate-600">أضف طلب جديد للعميل</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* بيانات العميل */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="w-5 h-5" />
              بيانات العميل
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div>
                <Label htmlFor="customerName">اسم العميل *</Label>
                <Input
                  id="customerName"
                  placeholder="أدخل اسم العميل"
                  {...form.register('customerName')}
                />
                {form.formState.errors.customerName && (
                  <p className="text-sm text-red-600 mt-1">{form.formState.errors.customerName.message}</p>
                )}
              </div>

              <div>
                <Label htmlFor="customerPhone">رقم الهاتف *</Label>
                <Input
                  id="customerPhone"
                  placeholder="أدخل رقم الهاتف"
                  {...form.register('customerPhone')}
                />
                {form.formState.errors.customerPhone && (
                  <p className="text-sm text-red-600 mt-1">{form.formState.errors.customerPhone.message}</p>
                )}
              </div>

              <div>
                <Label htmlFor="customerEmail">البريد الإلكتروني</Label>
                <Input
                  id="customerEmail"
                  type="email"
                  placeholder="أدخل البريد الإلكتروني"
                  {...form.register('customerEmail')}
                />
                {form.formState.errors.customerEmail && (
                  <p className="text-sm text-red-600 mt-1">{form.formState.errors.customerEmail.message}</p>
                )}
              </div>

              <div>
                <Label htmlFor="customerAddress">العنوان</Label>
                <Input
                  id="customerAddress"
                  placeholder="أدخل عنوان العميل"
                  {...form.register('customerAddress')}
                />
              </div>

              <div>
                <Label htmlFor="notes">ملاحظات</Label>
                <Input
                  id="notes"
                  placeholder="ملاحظات إضافية"
                  {...form.register('notes')}
                />
              </div>
            </form>
          </CardContent>
        </Card>

        {/* إضافة المنتجات */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Package className="w-5 h-5" />
              إضافة المنتجات
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <Label htmlFor="product">اختر المنتج</Label>
                <select
                  id="product"
                  value={selectedProductId}
                  onChange={(e) => setSelectedProductId(e.target.value)}
                  className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">اختر منتج</option>
                  {Array.isArray(products) && products.map((product: any) => (
                    <option key={product.id} value={product.id}>
                      {product.name} - {product.price?.toLocaleString()} د.ع
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <Label htmlFor="quantity">الكمية</Label>
                <Input
                  id="quantity"
                  type="number"
                  min="1"
                  value={quantity}
                  onChange={(e) => setQuantity(parseInt(e.target.value) || 1)}
                />
              </div>

              <Button onClick={addItemToOrder} className="w-full">
                <Plus className="w-4 h-4 ml-2" />
                إضافة للطلب
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* قائمة المنتجات المضافة */}
      {orderItems.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>منتجات الطلب</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {orderItems.map((item) => (
                <div key={item.productId} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                      <Package className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium text-slate-900">{item.productName}</p>
                      <p className="text-sm text-slate-600">
                        {item.price.toLocaleString()} د.ع × {item.quantity}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-semibold text-slate-900">
                      {item.total.toLocaleString()} د.ع
                    </span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeItemFromOrder(item.productId)}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
              
              <div className="border-t pt-3 mt-3">
                <div className="flex justify-between items-center">
                  <span className="text-lg font-semibold">المجموع الكلي:</span>
                  <span className="text-xl font-bold text-blue-600">
                    {totalAmount.toLocaleString()} د.ع
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* أزرار الإجراءات */}
      <div className="flex gap-3">
        <Button 
          onClick={form.handleSubmit(onSubmit)}
          disabled={createOrderMutation.isPending || orderItems.length === 0}
          className="flex-1"
        >
          {createOrderMutation.isPending ? 'جاري الإنشاء...' : 'إنشاء الطلب'}
        </Button>
        <Button variant="outline" onClick={() => window.history.back()}>
          إلغاء
        </Button>
      </div>
    </div>
  );
};