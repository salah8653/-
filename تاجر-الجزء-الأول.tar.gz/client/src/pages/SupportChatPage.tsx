import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowRight, 
  Send, 
  Phone, 
  Mail, 
  Clock,
  User,
  Bot,
  Trash2,
  Save,
  MapPin
} from "lucide-react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { useQuery } from '@tanstack/react-query';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'support';
  timestamp: Date;
  status?: 'sent' | 'delivered' | 'read';
}

export const SupportChatPage = () => {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [hasReceivedWelcome, setHasReceivedWelcome] = useState(false);

  // إزالة إعادة التوجيه الفورية لواتساب
  // useEffect(() => {
  //   const whatsappNumber = "9647801258110";
  //   const message = "مرحباً، أحتاج مساعدة";
  //   const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;
  //   
  //   // إعادة توجيه فورية
  //   window.location.href = whatsappUrl;
  // }, []);

  // دالة لتحميل الرسائل من Firebase
  const loadMessagesFromFirebase = async () => {
    try {
      const response = await fetch('/api/support-messages');
      if (response.ok) {
        const allMessages = await response.json();
        
        // تصفية الرسائل الخاصة بالمستخدم الحالي
        const userMessages = allMessages.filter((msg: any) => 
          msg.customerPhone === (user?.phone || '07801258110')
        );
        
        // تحويل إلى التنسيق المطلوب
        const formattedMessages = userMessages.map((msg: any) => ({
          id: msg.id,
          text: msg.message,
          sender: msg.isAdminReply ? 'support' : 'user',
          timestamp: new Date(msg.createdAt),
          status: 'delivered'
        }));
        
        // ترتيب الرسائل حسب الوقت
        formattedMessages.sort((a: any, b: any) => a.timestamp.getTime() - b.timestamp.getTime());
        
        setMessages(formattedMessages);
        setHasReceivedWelcome(formattedMessages.length > 0);
      }
    } catch (error) {
      console.error('❌ خطأ في تحميل رسائل الدعم:', error);
    }
  };

  // دالة لحفظ المحادثات
  const saveMessages = (messagesToSave: Message[]) => {
    if (!user?.id) return;
    
    try {
      localStorage.setItem(`support_chat_${user.id}`, JSON.stringify(messagesToSave));
    } catch (error) {
      console.error('خطأ في حفظ المحادثات:', error);
    }
  };

  // تحميل المحادثات عند تحميل المكون
  useEffect(() => {
    loadMessagesFromFirebase();
    // تحديث كل 5 ثوان
    const interval = setInterval(loadMessagesFromFirebase, 5000);
    return () => clearInterval(interval);
  }, [user?.id]);

  // جلب إعدادات التواصل من قاعدة البيانات
  const { data: contactSettings } = useQuery({
    queryKey: ['/api/settings/contact'],
    staleTime: 300000, // 5 دقائق
  });

  const quickReplies = [
    'استفسار عن منتج',
    'مشكلة في الدفع',
    'طلب إرجاع أو استبدال',
    'شكوى أو اقتراح'
  ];

  const supportInfo = {
    phone: '+9647801258110',
    email: 'TajerStore99@gmail.com',
    workingHours: 'السبت - الخميس: 9:00 - 18:00',
    location: 'اربيل،عينكاوة'
  };

  const sendMessage = async () => {
    if (!newMessage.trim()) return;

    const currentMessage = newMessage;
    setNewMessage('');

    // إرسال الرسالة إلى Firebase
    try {
      const response = await fetch('/api/support-messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          customerPhone: user?.phone || '07801258110',
          customerName: user?.fullName || 'عميل تاجر',
          message: currentMessage,
          isAdminReply: false
        })
      });
      
      if (response.ok) {
        console.log('✅ تم إرسال الرسالة إلى Firebase');
        // تحديث الرسائل فوراً
        loadMessagesFromFirebase();
      } else {
        console.error('❌ خطأ في إرسال الرسالة');
      }
    } catch (error) {
      console.error('❌ خطأ في الاتصال:', error);
    }
  };

  const sendQuickReply = (reply: string) => {
    setNewMessage(reply);
    setTimeout(() => sendMessage(), 100);
  };

  // دالة لمسح المحادثة
  const clearChat = () => {
    if (!user?.id) return;
    
    setMessages([]);
    setHasReceivedWelcome(false);
    localStorage.removeItem(`support_chat_${user.id}`);
  };

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-purple-800 text-white shadow-lg">
        <div className="p-4 flex items-center gap-3">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => setLocation("/profile")}
            className="text-white hover:bg-white/20"
          >
            <ArrowRight className="h-5 w-5" />
          </Button>
          <div className="flex items-center gap-3 flex-1">
            <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
              <Bot className="h-6 w-6 text-white" />
            </div>
            <div className="flex-1">
              <h1 className="text-xl font-bold">دعم تاجر</h1>
              <div className="flex items-center gap-2">
                <p className="text-purple-100 text-sm">متاح الآن للمساعدة</p>
                <div className="flex items-center gap-1 text-xs text-purple-200">
                  <Save className="w-3 h-3" />
                  <span>محفوظ تلقائياً</span>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 p-4 pb-32">
        <div className="space-y-4 max-w-4xl mx-auto">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-xs px-4 py-3 rounded-lg ${
                  message.sender === 'user'
                    ? 'bg-purple-600 text-white'
                    : 'bg-white text-slate-900 border shadow-sm'
                }`}
              >
                <div className="flex items-center gap-2 mb-2">
                  {message.sender === 'support' ? (
                    <Bot className="w-4 h-4 text-purple-600" />
                  ) : (
                    <User className="w-4 h-4 text-white" />
                  )}
                  <span className="text-xs font-medium">
                    {message.sender === 'support' ? 'دعم تاجر' : 'أنت'}
                  </span>
                  <span className="text-xs opacity-70">
                    {message.timestamp.toLocaleTimeString('ar-IQ', { 
                      hour: '2-digit', 
                      minute: '2-digit' 
                    })}
                  </span>
                </div>
                <p className="text-sm leading-relaxed">{message.text}</p>
                {message.status && message.sender === 'user' && (
                  <div className="flex items-center gap-1 mt-2">
                    <div className="text-xs opacity-70">
                      {message.status === 'sent' && '✓'}
                      {message.status === 'delivered' && '✓✓'}
                      {message.status === 'read' && '✓✓'}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}

          {/* Typing Indicator */}
          {isTyping && (
            <div className="flex justify-start">
              <div className="bg-white text-slate-900 border shadow-sm max-w-xs px-4 py-3 rounded-lg">
                <div className="flex items-center gap-2">
                  <Bot className="w-4 h-4 text-purple-600" />
                  <div className="flex gap-1">
                    <div className="w-2 h-2 bg-purple-600 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-purple-600 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                    <div className="w-2 h-2 bg-purple-600 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Quick Replies */}
        <div className="mt-6 max-w-4xl mx-auto">
          <p className="text-sm font-medium text-slate-700 mb-3">الردود السريعة:</p>
          <div className="flex flex-wrap gap-2">
            {quickReplies.map((reply, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                onClick={() => sendQuickReply(reply)}
                className="text-xs"
              >
                {reply}
              </Button>
            ))}
          </div>
        </div>

        {/* Contact Info */}
        <Card className="mt-6 max-w-4xl mx-auto">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Phone className="w-5 h-5 text-purple-600" />
              طرق التواصل الأخرى
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-sm">
              <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                  <Phone className="w-4 h-4 text-green-600" />
                </div>
                <span className="text-slate-700 font-medium">{supportInfo.phone}</span>
              </div>

              <div className="flex items-center gap-3 p-3 bg-orange-50 rounded-lg">
                <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center">
                  <Clock className="w-4 h-4 text-orange-600" />
                </div>
                <span className="text-slate-700 font-medium">{supportInfo.workingHours}</span>
              </div>

            </div>
          </CardContent>
        </Card>
      </div>

      {/* Message Input - Fixed at bottom */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg p-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex gap-3">
            <Input
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="اكتب رسالتك..."
              onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
              className="flex-1"
            />
            <Button
              onClick={sendMessage}
              disabled={!newMessage.trim()}
              className="bg-purple-600 hover:bg-purple-700"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};