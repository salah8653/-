import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Plus, 
  Edit, 
  Trash2, 
  Image, 
  Eye, 
  EyeOff,
  Upload,
  Save,
  X
} from "lucide-react";

interface BannerImage {
  url: string;
  title: string;
}

interface Banner {
  id: number;
  title: string;
  description?: string;
  images: BannerImage[];
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

interface BannerFormData {
  title: string;
  description: string;
  isActive: boolean;
  images: BannerImage[];
}

export default function BannersManagementPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [formData, setFormData] = useState<BannerFormData>({
    title: '',
    description: '',
    isActive: true,
    images: [
      { url: '', title: '' },
      { url: '', title: '' },
      { url: '', title: '' },
      { url: '', title: '' },
      { url: '', title: '' }
    ]
  });

  // جلب البانرات
  const { data: bannersData, isLoading, refetch } = useQuery({
    queryKey: ['/api/banners'],
    enabled: true
  });

  const banners = Array.isArray(bannersData) ? bannersData : [];

  // إضافة/تحديث بانر
  const saveBannerMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const url = editingId ? `/api/banners/${editingId}` : '/api/banners';
      const method = editingId ? 'PUT' : 'POST';
      return await apiRequest(method as any, url, data);
    },
    onSuccess: () => {
      toast({
        title: editingId ? "تم تحديث البانر بنجاح" : "تم إضافة البانر بنجاح",
        variant: "default"
      });
      resetForm();
      refetch();
    },
    onError: () => {
      toast({
        title: "حدث خطأ",
        description: "لم يتم حفظ البانر",
        variant: "destructive"
      });
    }
  });

  // حذف بانر
  const deleteBannerMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest('DELETE', `/api/banners/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "تم حذف البانر بنجاح",
        variant: "default"
      });
      refetch();
    },
    onError: () => {
      toast({
        title: "حدث خطأ",
        description: "لم يتم حذف البانر",
        variant: "destructive"
      });
    }
  });

  // تغيير حالة البانر
  const toggleBannerMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: number, isActive: boolean }) => {
      return await apiRequest('PUT', `/api/banners/${id}/toggle`, { isActive });
    },
    onSuccess: () => {
      toast({
        title: "تم تغيير حالة البانر بنجاح",
        variant: "default"
      });
      refetch();
    },
    onError: () => {
      toast({
        title: "حدث خطأ",
        description: "لم يتم تغيير حالة البانر",
        variant: "destructive"
      });
    }
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      setFormData({ ...formData, imageUrl: URL.createObjectURL(file) });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const form = new FormData();
    form.append('title', formData.title);
    form.append('description', formData.description);
    form.append('isActive', formData.isActive.toString());
    
    if (selectedFile) {
      form.append('image', selectedFile);
    }

    saveBannerMutation.mutate(form);
  };

  const handleEdit = (banner: Banner) => {
    setFormData({
      title: banner.title,
      description: banner.description || '',
      isActive: banner.isActive,
      imageUrl: banner.imageUrl || ''
    });
    setEditingId(banner.id);
    setIsFormOpen(true);
  };

  const handleDelete = (id: number) => {
    if (confirm('هل أنت متأكد من حذف هذا البانر؟')) {
      deleteBannerMutation.mutate(id);
    }
  };

  const handleToggleStatus = (id: number, currentStatus: boolean) => {
    toggleBannerMutation.mutate({ id, isActive: !currentStatus });
  };

  const resetForm = () => {
    setFormData({
      title: '',
      description: '',
      isActive: true,
      imageUrl: ''
    });
    setSelectedFile(null);
    setEditingId(null);
    setIsFormOpen(false);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6" dir="rtl">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">إدارة البانرات</h1>
        <Button 
          onClick={() => setIsFormOpen(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white"
        >
          <Plus className="h-4 w-4 ml-2" />
          إضافة بانر جديد
        </Button>
      </div>

      {/* نموذج إضافة/تحديث البانر */}
      {isFormOpen && (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex justify-between items-center">
              {editingId ? 'تحديث البانر' : 'إضافة بانر جديد'}
              <Button 
                variant="ghost" 
                size="icon"
                onClick={resetForm}
              >
                <X className="h-4 w-4" />
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="title">عنوان البانر</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="أدخل عنوان البانر"
                  required
                />
              </div>

              <div>
                <Label htmlFor="description">الوصف (اختياري)</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="أدخل وصف البانر"
                  rows={3}
                />
              </div>

              <div>
                <Label htmlFor="image">صورة البانر</Label>
                <div className="flex items-center gap-4">
                  <Input
                    id="image"
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    className="flex-1"
                  />
                  <Button type="button" variant="outline">
                    <Upload className="h-4 w-4 ml-2" />
                    رفع صورة
                  </Button>
                </div>
                
                {formData.imageUrl && (
                  <div className="mt-2">
                    <img 
                      src={formData.imageUrl} 
                      alt="معاينة البانر" 
                      className="h-32 w-auto rounded-lg border"
                    />
                  </div>
                )}
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  id="isActive"
                  checked={formData.isActive}
                  onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked })}
                />
                <Label htmlFor="isActive">البانر نشط</Label>
              </div>

              <div className="flex gap-2">
                <Button 
                  type="submit" 
                  disabled={saveBannerMutation.isPending}
                  className="bg-green-600 hover:bg-green-700"
                >
                  <Save className="h-4 w-4 ml-2" />
                  {saveBannerMutation.isPending ? 'جاري الحفظ...' : 'حفظ البانر'}
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={resetForm}
                >
                  إلغاء
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* قائمة البانرات */}
      <Card>
        <CardHeader>
          <CardTitle>البانرات المتاحة ({banners.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {banners.length === 0 ? (
            <div className="text-center py-12">
              <Image className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">لا توجد بانرات</p>
              <Button 
                onClick={() => setIsFormOpen(true)}
                className="mt-4"
                variant="outline"
              >
                إضافة أول بانر
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {banners.map((banner: Banner) => (
                <div
                  key={banner.id}
                  className="border rounded-lg p-4 hover:shadow-md transition-shadow"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="font-semibold text-lg">{banner.title}</h3>
                        <span className={`px-2 py-1 rounded-full text-xs ${
                          banner.isActive 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-gray-100 text-gray-800'
                        }`}>
                          {banner.isActive ? 'نشط' : 'غير نشط'}
                        </span>
                      </div>
                      
                      {banner.description && (
                        <p className="text-gray-600 mb-2">{banner.description}</p>
                      )}
                      
                      {banner.imageUrl && (
                        <div className="mb-2">
                          <img 
                            src={banner.imageUrl} 
                            alt={banner.title}
                            className="h-20 w-auto rounded border"
                          />
                        </div>
                      )}
                      
                      <p className="text-sm text-gray-500">
                        تم الإنشاء: {new Date(banner.createdAt).toLocaleDateString('ar-SA')}
                      </p>
                    </div>
                    
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleToggleStatus(banner.id, banner.isActive)}
                        disabled={toggleBannerMutation.isPending}
                      >
                        {banner.isActive ? (
                          <EyeOff className="h-4 w-4" />
                        ) : (
                          <Eye className="h-4 w-4" />
                        )}
                      </Button>
                      
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleEdit(banner)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => handleDelete(banner.id)}
                        disabled={deleteBannerMutation.isPending}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}