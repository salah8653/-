import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Search, ShoppingCart, User, Package, Heart, Grid3X3, Filter, SortAsc, ClipboardList } from "lucide-react";
import { useLocation } from "wouter";
import { useCart } from "@/hooks/useCart";
import { SafeBannerCarousel } from "@/components/SafeBannerCarousel";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useLanguage } from "@/contexts/LanguageContext";
import { BottomNavigation } from "@/components/BottomNavigation";

export const CustomerStorePage = () => {
  const { language, t, dir } = useLanguage();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState(language === 'ar' ? "الكل" : "All");
  const [, setLocation] = useLocation();
  const { getTotalItems } = useCart();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: products = [] } = useQuery({
    queryKey: ["/api/products"],
  });

  const { data: categories = [] } = useQuery({
    queryKey: ["/api/categories"],
  });

  const { data: bannersData = [] } = useQuery({
    queryKey: ["/api/banners"],
  });

  const banners = bannersData as any[];

  // نظام حفظ المنتجات البسيط مع Firebase
  const [savedProductIds, setSavedProductIds] = useState<number[]>([]);

  // جلب المنتجات المحفوظة
  const { data: savedData = [] } = useQuery({
    queryKey: ["/api/saved-products"]
  });

  // تحديث قائمة المنتجات المحفوظة
  useEffect(() => {
    if (Array.isArray(savedData) && savedData.length > 0) {
      const productIds = savedData.map((item: any) => item.productId);
      setSavedProductIds(productIds);
    }
  }, [savedData]);

  // دالة للتحقق من حفظ المنتج
  const isProductSaved = (productId: number) => {
    return savedProductIds.includes(productId);
  };

  // وظيفة حفظ/إلغاء حفظ المنتج
  const handleToggleSave = useMutation({
    mutationFn: async (productId: number) => {
      const isSaved = isProductSaved(productId);
      
      if (isSaved) {
        await apiRequest("DELETE", `/api/saved-products/${productId}`);
        setSavedProductIds(prev => prev.filter(id => id !== productId));
        return { action: 'removed' };
      } else {
        await apiRequest("POST", "/api/saved-products", { productId });
        setSavedProductIds(prev => [...prev, productId]);
        return { action: 'added' };
      }
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ["/api/saved-products"] });
      toast({
        title: result.action === 'added' ? "تم الحفظ" : "تم الحذف",
        description: result.action === 'added' ? "تم حفظ المنتج بنجاح" : "تم حذف المنتج من المحفوظات",
      });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "فشل في تحديث المنتجات المحفوظة",
        variant: "destructive",
      });
    },
  });

  // إضافة المنتج إلى السلة مباشرة من واجهة المتجر
  const addToCartMutation = useMutation({
    mutationFn: async (productId: number) => {
      const response = await fetch('/api/cart', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ productId, quantity: 1 }),
      });
      if (!response.ok) throw new Error('فشل في إضافة المنتج');
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: language === 'ar' ? "تم إضافة المنتج" : "Product Added",
        description: language === 'ar' ? "تم إضافة المنتج إلى السلة بنجاح" : "Product added to cart successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
      // لا نقوم بالتوجه للسلة من الواجهة الخارجية
    },
    onError: () => {
      toast({
        title: language === 'ar' ? "خطأ" : "Error",
        description: language === 'ar' ? "فشل في إضافة المنتج إلى السلة" : "Failed to add product to cart",
        variant: "destructive",
      });
    },
  });

  // ترجمة الفئات
  const translateCategory = (category: string) => {
    const translations: { [key: string]: string } = {
      'منتجات مطبخ': language === 'ar' ? 'منتجات مطبخ' : 'Kitchen Products',
      'إلكترونيات': language === 'ar' ? 'إلكترونيات' : 'Electronics',
      'ملابس': language === 'ar' ? 'ملابس' : 'Clothing',
      'كتب': language === 'ar' ? 'كتب' : 'Books',
      'رياضة': language === 'ar' ? 'رياضة' : 'Sports',
      'جمال': language === 'ar' ? 'جمال' : 'Beauty',
      'صحة': language === 'ar' ? 'صحة' : 'Health',
      'طعام': language === 'ar' ? 'طعام' : 'Food',
      'مشروبات': language === 'ar' ? 'مشروبات' : 'Drinks'
    };
    return translations[category] || category;
  };

  const allCategories = [
    language === 'ar' ? "الكل" : "All", 
    ...(categories as any[]).map((cat: any) => cat.name)
  ];



  const filteredProducts = (products as any[]).filter((product: any) => {
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase());
    
    // تصفية حسب الفئة
    if (selectedCategory === "الكل") {
      return matchesSearch;
    }
    
    // المنتجات الجديدة - المنتجات التي أُضيفت خلال أسبوع
    if (selectedCategory === "منتجات جديدة") {
      const oneWeekAgo = new Date();
      oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
      const productDate = new Date(product.createdAt);
      return matchesSearch && productDate >= oneWeekAgo;
    }
    
    // الأكثر مبيعاً - المنتجات التي طُلبت 25 مرة أو أكثر
    if (selectedCategory === "أكثر مبيعاً") {
      const orderCount = product.orderCount || 0;
      return matchesSearch && orderCount >= 25;
    }
    
    // الفئات العادية
    const matchesCategory = product.category?.name === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-gray-50" dir={dir}>
      {/* Header */}
      <div className="bg-white shadow-sm sticky top-0 z-10">
        <div className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-xl font-bold text-gray-800">{t('products')}</h1>
            <div className="flex items-center gap-2">
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => setLocation("/saved-products")}
              >
                <Heart className="h-5 w-5 text-red-500" />
              </Button>
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => setLocation("/cart")}
                className="relative"
              >
                <ShoppingCart className="h-5 w-5" />
                {getTotalItems() > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    {getTotalItems()}
                  </span>
                )}
              </Button>
            </div>
          </div>
          
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder={t('search')}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className={`${language === 'ar' ? 'pr-10' : 'pl-10'} bg-gray-100 border-0 rounded-xl`}
            />
          </div>
        </div>
      </div>

      {/* البانرات */}
      <div className="bg-white">
        <SafeBannerCarousel banners={banners} />
      </div>

      <div className="bg-white">
        {/* Categories */}
        <div className="px-4 pb-3">
          <div className="flex items-center gap-2 mb-3">
            <Button 
              variant="outline" 
              size="sm" 
              className="rounded-xl"
              onClick={() => setLocation('/categories')}
            >
              <Grid3X3 className={`h-4 w-4 ${language === 'ar' ? 'ml-1' : 'mr-1'}`} />
              {language === 'ar' ? 'الفئات' : 'Categories'}
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className="rounded-xl"
              onClick={() => setLocation('/sort-products')}
            >
              <SortAsc className={`h-4 w-4 ${language === 'ar' ? 'ml-1' : 'mr-1'}`} />
              {language === 'ar' ? 'ترتيب حسب السعر' : 'Sort by Price'}
            </Button>
          </div>
          
          <div className="flex gap-2 overflow-x-auto pb-2">
            {allCategories.map((category) => (
              <Badge
                key={category}
                variant={selectedCategory === category ? "default" : "secondary"}
                className={`whitespace-nowrap cursor-pointer px-4 py-2 rounded-xl ${
                  selectedCategory === category 
                    ? "bg-purple-600 text-white" 
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
                onClick={() => setSelectedCategory(category)}
              >
                {translateCategory(category)}
              </Badge>
            ))}
          </div>
        </div>
      </div>



      {/* Navigation Buttons - محسنة */}
      <div className="px-4 mb-6">
        <div className="grid grid-cols-2 gap-4">
          <Button 
            className="bg-gradient-to-br from-red-500 via-pink-500 to-red-600 text-white rounded-2xl py-6 flex flex-col items-center gap-2 hover:from-red-600 hover:to-pink-700 shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200"
            onClick={() => setSelectedCategory("أكثر مبيعاً")}
          >
            <div className="text-2xl mb-1">🔥</div>
            <span className="font-semibold text-sm">{language === 'ar' ? 'الأكثر مبيعاً' : 'Best Sellers'}</span>
            <span className="text-xs opacity-90">{language === 'ar' ? 'اشترِ الآن' : 'Buy Now'}</span>
          </Button>
          
          <Button 
            className="bg-gradient-to-br from-emerald-500 via-green-500 to-teal-600 text-white rounded-2xl py-6 flex flex-col items-center gap-2 hover:from-emerald-600 hover:to-teal-700 shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200"
            onClick={() => setSelectedCategory("منتجات جديدة")}
          >
            <div className="text-2xl mb-1">✨</div>
            <span className="font-semibold text-sm">{language === 'ar' ? 'منتجات جديدة' : 'New Products'}</span>
            <span className="text-xs opacity-90">{language === 'ar' ? 'اكتشف الجديد' : 'Discover New'}</span>
          </Button>
        </div>
      </div>

      {/* Products Section */}
      <div className="px-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold text-gray-800">{t('products')}</h2>
          <Button variant="ghost" size="sm" className="text-purple-600" onClick={() => setSelectedCategory(language === 'ar' ? "الكل" : "All")}>
            {language === 'ar' ? 'عرض الكل' : 'View All'}
          </Button>
        </div>

        {filteredProducts.length === 0 ? (
          <div className="text-center py-12">
            <Package className="h-16 w-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">{language === 'ar' ? 'لا توجد منتجات متاحة' : 'No products available'}</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3 pb-20">
            {filteredProducts.map((product: any) => (
              <Card 
                key={product.id} 
                className="border-0 shadow-md hover:shadow-lg transition-shadow cursor-pointer rounded-lg overflow-hidden"
                onClick={() => setLocation(`/product/${product.id}`)}
              >
                <CardContent className="p-0">
                  <div className="relative">
                    {product.imageUrl ? (
                      <img 
                        src={product.imageUrl} 
                        alt={product.name}
                        className="w-full h-36 object-cover"
                      />
                    ) : (
                      <div className="w-full h-36 bg-gray-100 flex items-center justify-center">
                        <Package className="h-10 w-10 text-gray-400" />
                      </div>
                    )}
                    
                    {/* عداد القطع المتبقية فوق الصورة */}
                    <div className={`absolute top-3 ${language === 'ar' ? 'right-3' : 'left-3'} bg-purple-600 text-white px-2 py-1 rounded-lg text-xs font-semibold`}>
                      {language === 'ar' ? `متبقي ${product.stock}` : `${product.stock} left`}
                    </div>
                    
                    {/* زر القلب */}
                    <Button
                      variant="ghost"
                      size="sm"
                      className={`absolute top-3 ${language === 'ar' ? 'left-3' : 'right-3'} p-2 rounded-full bg-white/90 backdrop-blur-sm shadow-sm ${
                        isProductSaved(product.id) ? 'text-red-500' : 'text-gray-600'
                      } hover:bg-white`}
                      onClick={(e) => {
                        e.stopPropagation();
                        handleToggleSave.mutate(product.id);
                      }}
                    >
                      <Heart 
                        className={`h-5 w-5 ${
                          isProductSaved(product.id) ? 'fill-current' : ''
                        }`} 
                      />
                    </Button>
                  </div>

                  <div className="p-3">
                    <h3 className="font-bold text-base text-gray-900 mb-2 line-clamp-2 leading-tight text-right">
                      {product.name}
                    </h3>
                    
                    {/* نص الربح */}
                    <div className="text-right mb-2">
                      <span className="text-xs text-green-600 font-semibold">
                        {language === 'ar' 
                          ? `اربح ${(Math.max(5000, Math.min(9000, Math.floor(parseFloat(product.price) * 0.5)))).toLocaleString()} د.ع أو أكثر` 
                          : `Earn ${(Math.max(5000, Math.min(9000, Math.floor(parseFloat(product.price) * 0.5)))).toLocaleString()} IQD or more`
                        }
                      </span>
                    </div>
                    
                    <div className="space-y-2">
                      {/* سعر الجملة */}
                      <div className="text-right">
                        <div className="text-sm font-medium text-gray-700 mb-1">
                          {language === 'ar' ? 'سعر الجملة' : 'Wholesale Price'}
                        </div>
                        <div className="text-sm font-semibold text-purple-600">
                          {parseFloat(product.price).toLocaleString()} {language === 'ar' ? 'د.ع' : 'IQD'}
                        </div>
                      </div>
                      
                      {/* زر إضافة إلى السلة */}
                      <Button
                        size="sm"
                        className="w-full bg-purple-600 hover:bg-purple-700 text-white text-xs py-2 rounded-lg font-semibold"
                        onClick={(e) => {
                          e.stopPropagation();
                          addToCartMutation.mutate(product.id);
                        }}
                        disabled={product.stock === 0 || addToCartMutation.isPending}
                      >
                        <ShoppingCart className={`h-4 w-4 ${language === 'ar' ? 'ml-1' : 'mr-1'}`} />
                        {language === 'ar' ? 'أضف إلى السلة' : 'Add to Cart'}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      <BottomNavigation />
    </div>
  );
};