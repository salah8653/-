import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Heart, ShoppingCart, ArrowRight, Trash2, Package, X } from "lucide-react";
import { useLocation } from "wouter";
import { useCart } from "@/hooks/useCart";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export const SavedProductsPage = () => {
  const [, navigate] = useLocation();
  const { addItem } = useCart();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // جلب المنتجات المحفوظة
  const { data: savedProducts = [], isLoading } = useQuery({
    queryKey: ["/api/saved-products"]
  });

  // جلب تفاصيل المنتجات
  const { data: allProducts = [] } = useQuery({
    queryKey: ["/api/products"]
  });

  // دمج المنتجات المحفوظة مع تفاصيلها
  const savedProductsWithDetails = Array.isArray(savedProducts) ? savedProducts.map((saved: any) => {
    const product = Array.isArray(allProducts) ? allProducts.find((p: any) => p.id === saved.productId) : null;
    return {
      ...saved,
      product
    };
  }).filter((item: any) => item.product) : [];

  // حذف منتج واحد من المحفوظات
  const removeMutation = useMutation({
    mutationFn: async (productId: number) => {
      await apiRequest("DELETE", `/api/saved-products/${productId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/saved-products"] });
      toast({
        title: "تم الحذف",
        description: "تم حذف المنتج من المحفوظات",
      });
    }
  });

  // حذف جميع المنتجات المحفوظة
  const clearAllMutation = useMutation({
    mutationFn: async () => {
      // حذف كل منتج على حدة
      for (const item of savedProductsWithDetails) {
        await apiRequest("DELETE", `/api/saved-products/${item.product.id}`);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/saved-products"] });
      toast({
        title: "تم الحذف",
        description: "تم حذف جميع المنتجات المحفوظة",
      });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "فشل في حذف المنتجات المحفوظة",
        variant: "destructive",
      });
    }
  });

  // إضافة للسلة والانتقال لصفحة السلة
  const handleAddToCart = (product: any) => {
    addItem(product, 1);  // تمرير كائل المنتج الكامل وليس فقط المعرف
    toast({
      title: "تم إضافة المنتج",
      description: "تم إضافة المنتج إلى السلة",
    });
    // الانتقال لصفحة السلة
    setTimeout(() => {
      navigate("/cart");
    }, 1000);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 p-6">
        <div className="container mx-auto">
          <div className="animate-pulse space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-32 bg-gray-200 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* الهيدر */}
      <div className="bg-white shadow-sm border-b sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate("/")}
                className="text-purple-600"
              >
                <ArrowRight className="h-5 w-5 ml-2" />
                العودة للمتجر
              </Button>
            </div>
            <div className="text-center">
              <h1 className="text-2xl font-bold text-gray-800">المنتجات المحفوظة</h1>
              <p className="text-sm text-gray-600">
                {savedProductsWithDetails.length} منتج محفوظ
              </p>
            </div>
            <div className="flex items-center gap-2">
              {savedProductsWithDetails.length > 0 && (
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-red-200 text-red-600 hover:bg-red-50"
                    >
                      <X className="h-4 w-4 ml-1" />
                      حذف الكل
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>تأكيد الحذف</AlertDialogTitle>
                      <AlertDialogDescription>
                        هل أنت متأكد من حذف جميع المنتجات المحفوظة؟ 
                        هذا الإجراء لا يمكن التراجع عنه.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>إلغاء</AlertDialogCancel>
                      <AlertDialogAction
                        onClick={() => clearAllMutation.mutate()}
                        className="bg-red-600 hover:bg-red-700"
                      >
                        حذف الكل
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* المحتوى */}
      <div className="container mx-auto px-4 py-6">
        {savedProductsWithDetails.length === 0 ? (
          <div className="text-center py-20">
            <Heart className="h-16 w-16 text-gray-300 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-gray-600 mb-2">
              لا توجد منتجات محفوظة
            </h2>
            <p className="text-gray-500 mb-6">
              ابدأ بحفظ المنتجات التي تعجبك من المتجر
            </p>
            <Button onClick={() => navigate("/")} className="bg-purple-600 hover:bg-purple-700">
              تصفح المنتجات
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {savedProductsWithDetails.map((item: any) => (
              <Card key={item.id} className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer">
                <CardContent className="p-0">
                  <div 
                    className="flex items-center"
                    onClick={() => navigate(`/product/${item.product.id}`)}
                  >
                    {/* صورة المنتج */}
                    <div className="w-24 h-24 bg-gray-100 flex-shrink-0">
                      {item.product.imageUrl ? (
                        <img
                          src={item.product.imageUrl}
                          alt={item.product.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full bg-gradient-to-br from-purple-100 to-purple-200 flex items-center justify-center">
                          <Package className="h-8 w-8 text-purple-400" />
                        </div>
                      )}
                    </div>

                    {/* تفاصيل المنتج */}
                    <div className="flex-1 p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="font-semibold text-lg text-gray-800 mb-1">
                            {item.product.name}
                          </h3>
                          
                          {item.product.description && (
                            <p className="text-gray-600 text-sm mb-2 line-clamp-2">
                              {item.product.description}
                            </p>
                          )}

                          {/* سعر الجملة */}
                          <div className="flex items-center gap-3 mb-2">
                            <div className="text-lg font-bold text-purple-600">
                              سعر الجملة: {parseInt(item.product.price).toLocaleString()} د.ع
                            </div>
                          </div>

                          {/* القطع المتوفرة */}
                          <div className="flex items-center gap-3 mb-3">
                            <Badge variant={item.product.stock > 0 ? "default" : "destructive"}>
                              متوفر {item.product.stock} قطعة
                            </Badge>
                          </div>

                          <div className="text-xs text-gray-500">
                            تم الحفظ: {new Date(item.savedAt).toLocaleDateString('ar-EG')}
                          </div>
                        </div>

                        {/* الأزرار */}
                        <div className="flex flex-col gap-2 ml-4">
                          <Button
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleAddToCart(item.product);
                            }}
                            disabled={item.product.stock === 0}
                            className="bg-purple-600 hover:bg-purple-700 text-white min-w-[100px]"
                          >
                            <ShoppingCart className="h-4 w-4 ml-1" />
                            أضف للسلة
                          </Button>
                          
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation();
                              removeMutation.mutate(item.product.id);
                            }}
                            className="border-red-200 text-red-600 hover:bg-red-50 min-w-[100px]"
                          >
                            <Trash2 className="h-4 w-4 ml-1" />
                            احذف
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};