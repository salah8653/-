import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Heart, Share2, ShoppingCart, Plus, Minus, Star, Package, ArrowRight, Bookmark } from "lucide-react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest } from "@/lib/queryClient";
import { ProductWithCategory } from "shared/schema";

export const EnhancedProductDetailsPage = () => {
  const [, params] = useRoute("/product/:id");
  const [, setLocation] = useLocation();
  const [quantity, setQuantity] = useState(1);
  const [selectedColor, setSelectedColor] = useState("");
  const [customPrice, setCustomPrice] = useState("");
  const [isSaved, setIsSaved] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: product, isLoading } = useQuery<ProductWithCategory>({
    queryKey: ["/api/products", params?.id],
    enabled: !!params?.id,
  });

  // جلب حالة الحفظ للمنتج
  const { data: savedProducts = [] } = useQuery({
    queryKey: ["/api/saved-products"],
    enabled: !!user,
  });

  useEffect(() => {
    if (savedProducts && Array.isArray(savedProducts) && product) {
      setIsSaved(savedProducts.some((sp: any) => sp.productId === product.id));
    }
  }, [savedProducts, product]);

  // إضافة/إزالة من المحفوظات
  const toggleSaveMutation = useMutation({
    mutationFn: async () => {
      if (isSaved) {
        return await fetch(`/api/saved-products/${product?.id}`, { method: "DELETE" });
      } else {
        return await fetch("/api/saved-products", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ productId: product?.id }),
        });
      }
    },
    onSuccess: () => {
      setIsSaved(!isSaved);
      queryClient.invalidateQueries({ queryKey: ["/api/saved-products"] });
      toast({
        title: isSaved ? "تم إزالة المنتج من المحفوظات" : "تم حفظ المنتج",
        description: isSaved ? "تم إزالة المنتج من قائمة المحفوظات" : "تم إضافة المنتج إلى قائمة المحفوظات",
      });
    },
    onError: () => {
      toast({
        title: "حدث خطأ",
        description: "فشل في تحديث حالة الحفظ",
        variant: "destructive",
      });
    },
  });

  // إضافة إلى السلة
  const addToCartMutation = useMutation({
    mutationFn: async () => {
      const finalPrice = customPrice ? parseFloat(customPrice) : parseFloat(product?.price || "0");
      
      // التحقق من الحد الأدنى والأعلى للسعر
      if (product?.minPrice && finalPrice < parseFloat(product.minPrice)) {
        throw new Error(`السعر يجب أن يكون أكبر من ${product.minPrice} د.ع`);
      }
      if (product?.maxPrice && finalPrice > parseFloat(product.maxPrice)) {
        throw new Error(`السعر يجب أن يكون أقل من ${product.maxPrice} د.ع`);
      }

      return await fetch("/api/cart", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          productId: product?.id,
          quantity,
          selectedColor,
          customPrice: customPrice ? finalPrice : null,
        }),
      });
    },
    onSuccess: () => {
      toast({
        title: "تم إضافة المنتج إلى السلة",
        description: "يمكنك الآن إتمام عملية الشراء",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
      // التوجه مباشرة إلى صفحة السلة
      setLocation('/cart');
    },
    onError: (error: any) => {
      toast({
        title: "فشل في إضافة المنتج",
        description: error.message || "حدث خطأ أثناء إضافة المنتج إلى السلة",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="text-center py-12">
        <Package className="w-16 h-16 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">المنتج غير موجود</h3>
        <Button onClick={() => setLocation("/")}>
          <ArrowRight className="w-4 h-4 ml-2" />
          العودة للرئيسية
        </Button>
      </div>
    );
  }

  const finalPrice = customPrice ? parseFloat(customPrice) : parseFloat(product.price);
  const totalPrice = finalPrice * quantity;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="flex items-center justify-between p-4">
          <Button variant="ghost" onClick={() => setLocation("/")}>
            <ArrowRight className="w-5 h-5" />
          </Button>
          
          <h1 className="font-semibold text-gray-900 truncate mx-4">
            {product.name}
          </h1>
          
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon">
              <Share2 className="w-5 h-5" />
            </Button>
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => toggleSaveMutation.mutate()}
              disabled={!user || toggleSaveMutation.isPending}
            >
              <Heart className={`h-5 w-5 ${isSaved ? 'fill-red-500 text-red-500' : ''}`} />
            </Button>
          </div>
        </div>
      </div>

      {/* Product Image */}
      <div className="bg-white">
        <div className="aspect-square relative">
          {product.imageUrl ? (
            <img 
              src={product.imageUrl} 
              alt={product.name}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full bg-gray-100 flex items-center justify-center">
              <Package className="h-20 w-20 text-gray-400" />
            </div>
          )}
          
          {/* Status Badge */}
          <div className="absolute top-4 right-4">
            <Badge className={product.stock > 0 ? "bg-green-500 text-white" : "bg-red-500 text-white"}>
              {product.stock > 0 ? "متوفر" : "غير متوفر"}
            </Badge>
          </div>

          {/* Save Button */}
          <div className="absolute top-4 left-4">
            <Button 
              variant="ghost" 
              size="icon"
              className="bg-white/80 backdrop-blur-sm"
              onClick={() => toggleSaveMutation.mutate()}
              disabled={!user || toggleSaveMutation.isPending}
            >
              <Bookmark className={`h-5 w-5 ${isSaved ? 'fill-blue-500 text-blue-500' : ''}`} />
            </Button>
          </div>
        </div>
      </div>

      {/* Product Details */}
      <div className="p-4 space-y-4 pb-32">
        {/* Basic Info */}
        <Card>
          <CardContent className="p-4">
            <div className="space-y-3">
              <h1 className="text-xl font-bold text-gray-900">
                {product.name}
              </h1>
              
              <div className="flex items-center gap-2">
                <div className="flex items-center">
                  {[1,2,3,4,5].map((star) => (
                    <Star key={star} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <span className="text-sm text-gray-500">(4.8) • 120 تقييم</span>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <span className="text-2xl font-bold text-purple-600">
                    {parseFloat(product.price).toLocaleString()} د.ع
                  </span>
                  {product.minPrice && product.maxPrice && (
                    <div className="text-sm text-gray-500 mt-1">
                      من {parseFloat(product.minPrice).toLocaleString()} إلى {parseFloat(product.maxPrice).toLocaleString()} د.ع
                    </div>
                  )}
                </div>
                <Badge variant="outline" className="text-xs">
                  {product.category?.name || 'غير محدد'}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Description */}
        <Card>
          <CardContent className="p-4">
            <h2 className="font-semibold text-gray-900 mb-2">وصف المنتج</h2>
            <p className="text-gray-600 leading-relaxed">
              {product.description || "لا يوجد وصف متاح للمنتج"}
            </p>
          </CardContent>
        </Card>



        {/* Custom Price */}
        {(product.minPrice || product.maxPrice) && (
          <Card>
            <CardContent className="p-4">
              <h2 className="font-semibold text-gray-900 mb-3">تحديد السعر المخصص</h2>
              
              <div className="mb-4 p-3 bg-blue-50 rounded-lg">
                <div className="flex justify-between items-center text-sm">
                  <span className="text-gray-600">الحد الأدنى:</span>
                  <span className="font-bold text-blue-600">
                    {product.minPrice ? parseFloat(product.minPrice).toLocaleString() : "غير محدد"} د.ع
                  </span>
                </div>
                <div className="flex justify-between items-center text-sm mt-1">
                  <span className="text-gray-600">الحد الأعلى:</span>
                  <span className="font-bold text-blue-600">
                    {product.maxPrice ? parseFloat(product.maxPrice).toLocaleString() : "غير محدد"} د.ع
                  </span>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="customPrice">السعر المطلوب (اختياري)</Label>
                <Input
                  id="customPrice"
                  type="number"
                  placeholder={`السعر الافتراضي: ${parseFloat(product.price).toLocaleString()} د.ع`}
                  value={customPrice}
                  onChange={(e) => setCustomPrice(e.target.value)}
                  min={product.minPrice ? parseFloat(product.minPrice) : undefined}
                  max={product.maxPrice ? parseFloat(product.maxPrice) : undefined}
                />
                {customPrice && product.minPrice && parseFloat(customPrice) < parseFloat(product.minPrice) && (
                  <p className="text-sm text-red-600">
                    السعر يجب أن يكون أكبر من {parseFloat(product.minPrice).toLocaleString()} د.ع
                  </p>
                )}
                {customPrice && product.maxPrice && parseFloat(customPrice) > parseFloat(product.maxPrice) && (
                  <p className="text-sm text-red-600">
                    السعر يجب أن يكون أقل من {parseFloat(product.maxPrice).toLocaleString()} د.ع
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Quantity Selection */}
        <Card>
          <CardContent className="p-4">
            <h2 className="font-semibold text-gray-900 mb-3">الكمية</h2>
            
            <div className="flex items-center justify-center gap-4 mb-4">
              <Button 
                variant="outline" 
                size="icon"
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                disabled={quantity <= 1}
              >
                <Minus className="h-4 w-4" />
              </Button>
              
              <span className="text-xl font-semibold w-12 text-center">
                {quantity}
              </span>
              
              <Button 
                variant="outline" 
                size="icon"
                onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                disabled={quantity >= product.stock}
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            
            <div className="text-center">
              <span className="text-sm text-gray-500">
                المخزون المتاح: {product.stock} قطعة
              </span>
            </div>
            
            <div className="mt-3 text-center">
              <span className="text-lg font-bold text-purple-600">
                الإجمالي: {totalPrice.toLocaleString()} د.ع
              </span>
            </div>
          </CardContent>
        </Card>

        {/* Specifications */}
        <Card>
          <CardContent className="p-4">
            <h2 className="font-semibold text-gray-900 mb-3">المواصفات</h2>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-500">رقم المنتج:</span>
                <span className="font-medium">{product.sku}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">الفئة:</span>
                <span className="font-medium">{product.category?.name || 'غير محدد'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">المخزون:</span>
                <span className="font-medium">{product.stock} قطعة</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">الحالة:</span>
                <span className="font-medium">
                  {product.status === 'active' ? 'نشط' : 'غير نشط'}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Fixed Bottom Add to Cart */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4 shadow-lg">
        <div className="flex gap-3">
          <Button 
            onClick={() => setLocation("/saved-products")}
            variant="outline"
            size="icon"
            className="flex-shrink-0"
          >
            <Bookmark className="h-5 w-5" />
          </Button>
          
          <Button 
            onClick={() => addToCartMutation.mutate()}
            disabled={!user || product.stock === 0 || addToCartMutation.isPending}
            className="flex-1"
            size="lg"
          >
            <ShoppingCart className="w-5 h-5 ml-2" />
            {addToCartMutation.isPending ? "جاري الإضافة..." : "إضافة إلى السلة"}
          </Button>
        </div>
        
        {!user && (
          <p className="text-sm text-center text-gray-500 mt-2">
            يجب تسجيل الدخول أولاً لإضافة المنتجات إلى السلة
          </p>
        )}
      </div>
    </div>
  );
};