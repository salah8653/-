import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { ArrowRight, Phone, Shield, Lock, AlertCircle, CheckCircle, Clock } from "lucide-react";
import { z } from "zod";

// مخططات استعادة كلمة المرور
const forgotPasswordSchema = z.object({
  phone: z.string().min(10, 'رقم الهاتف يجب أن يكون على الأقل 10 أرقام'),
});

const verifyResetCodeSchema = z.object({
  phone: z.string().min(10, 'رقم الهاتف مطلوب'),
  code: z.string().min(4, 'الكود يجب أن يكون على الأقل 4 أرقام'),
});

const resetPasswordSchema = z.object({
  phone: z.string().min(10, 'رقم الهاتف مطلوب'),
  code: z.string().min(4, 'الكود مطلوب'),
  newPassword: z.string().min(6, 'كلمة المرور يجب أن تكون على الأقل 6 أحرف'),
  confirmPassword: z.string().min(6, 'تأكيد كلمة المرور مطلوب'),
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: "كلمة المرور وتأكيدها غير متطابقتين",
  path: ["confirmPassword"],
});

type Step = 'phone' | 'code' | 'password';

type ForgotPasswordForm = z.infer<typeof forgotPasswordSchema>;
type VerifyCodeForm = z.infer<typeof verifyResetCodeSchema>;
type ResetPasswordForm = z.infer<typeof resetPasswordSchema>;

export const EnhancedForgotPasswordPage = () => {
  const [step, setStep] = useState<Step>('phone');
  const [phone, setPhone] = useState('');
  const [resetCode, setResetCode] = useState('');
  const [countdown, setCountdown] = useState(0);
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  // نموذج إدخال رقم الهاتف
  const phoneForm = useForm<ForgotPasswordForm>({
    resolver: zodResolver(forgotPasswordSchema),
    defaultValues: { phone: '' },
  });

  // نموذج التحقق من الكود
  const codeForm = useForm<VerifyCodeForm>({
    resolver: zodResolver(verifyResetCodeSchema),
    defaultValues: { phone: '', code: '' },
  });

  // نموذج إعادة تعيين كلمة المرور
  const passwordForm = useForm<ResetPasswordForm>({
    resolver: zodResolver(resetPasswordSchema),
    defaultValues: { 
      phone: '', 
      code: '', 
      newPassword: '', 
      confirmPassword: '' 
    },
  });

  // إرسال كود إعادة التعيين
  const sendCodeMutation = useMutation({
    mutationFn: async (data: ForgotPasswordForm) => {
      const response = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'حدث خطأ في إرسال الكود');
      }
      
      return response.json();
    },
    onSuccess: (_, variables) => {
      setPhone(variables.phone);
      setStep('code');
      codeForm.setValue('phone', variables.phone);
      
      // بدء العد التنازلي
      setCountdown(60);
      const timer = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      toast({
        title: "تم إرسال الكود",
        description: `تم إرسال كود التحقق إلى ${variables.phone}`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في إرسال الكود",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // التحقق من الكود
  const verifyCodeMutation = useMutation({
    mutationFn: async (data: VerifyCodeForm) => {
      const response = await fetch('/api/auth/verify-reset-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'الكود غير صحيح');
      }
      
      return response.json();
    },
    onSuccess: (_, variables) => {
      setResetCode(variables.code);
      setStep('password');
      passwordForm.setValue('phone', variables.phone);
      passwordForm.setValue('code', variables.code);
      
      toast({
        title: "تم التحقق من الكود",
        description: "يمكنك الآن إعادة تعيين كلمة المرور",
      });
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في التحقق",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // إعادة تعيين كلمة المرور
  const resetPasswordMutation = useMutation({
    mutationFn: async (data: ResetPasswordForm) => {
      const response = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'حدث خطأ في إعادة تعيين كلمة المرور');
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم تغيير كلمة المرور",
        description: "تم إعادة تعيين كلمة المرور بنجاح. يمكنك الآن تسجيل الدخول",
      });
      
      setTimeout(() => {
        setLocation('/login');
      }, 2000);
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في إعادة التعيين",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onPhoneSubmit = (data: ForgotPasswordForm) => {
    sendCodeMutation.mutate(data);
  };

  const onCodeSubmit = (data: VerifyCodeForm) => {
    verifyCodeMutation.mutate(data);
  };

  const onPasswordSubmit = (data: ResetPasswordForm) => {
    resetPasswordMutation.mutate(data);
  };

  const resendCode = () => {
    if (countdown === 0) {
      sendCodeMutation.mutate({ phone });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50 flex items-center justify-center p-4" dir="rtl">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1 text-center">
          <div className="flex items-center justify-center w-12 h-12 bg-purple-100 rounded-full mx-auto mb-4">
            {step === 'phone' && <Phone className="w-6 h-6 text-purple-600" />}
            {step === 'code' && <Shield className="w-6 h-6 text-purple-600" />}
            {step === 'password' && <Lock className="w-6 h-6 text-purple-600" />}
          </div>
          
          <CardTitle className="text-2xl font-bold text-gray-900">
            {step === 'phone' && 'استعادة كلمة المرور'}
            {step === 'code' && 'التحقق من الكود'}
            {step === 'password' && 'كلمة مرور جديدة'}
          </CardTitle>
          
          <p className="text-gray-600 text-sm">
            {step === 'phone' && 'أدخل رقم هاتفك لتلقي كود التحقق'}
            {step === 'code' && `أدخل الكود المرسل إلى ${phone}`}
            {step === 'password' && 'أدخل كلمة المرور الجديدة'}
          </p>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* خطوة إدخال رقم الهاتف */}
          {step === 'phone' && (
            <form onSubmit={phoneForm.handleSubmit(onPhoneSubmit)} className="space-y-4">
              <div>
                <Label htmlFor="phone">رقم الهاتف</Label>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="+966500000000"
                  {...phoneForm.register('phone')}
                  className="text-right"
                />
                {phoneForm.formState.errors.phone && (
                  <p className="text-sm text-red-600 mt-1">
                    {phoneForm.formState.errors.phone.message}
                  </p>
                )}
              </div>

              <Button 
                type="submit" 
                className="w-full" 
                disabled={sendCodeMutation.isPending}
              >
                {sendCodeMutation.isPending ? 'جاري الإرسال...' : 'إرسال كود التحقق'}
              </Button>
            </form>
          )}

          {/* خطوة التحقق من الكود */}
          {step === 'code' && (
            <form onSubmit={codeForm.handleSubmit(onCodeSubmit)} className="space-y-4">
              <div>
                <Label htmlFor="code">كود التحقق</Label>
                <Input
                  id="code"
                  type="text"
                  placeholder="أدخل الكود"
                  {...codeForm.register('code')}
                  className="text-center text-lg tracking-widest"
                  maxLength={6}
                />
                {codeForm.formState.errors.code && (
                  <p className="text-sm text-red-600 mt-1">
                    {codeForm.formState.errors.code.message}
                  </p>
                )}
              </div>

              {countdown > 0 && (
                <Alert>
                  <Clock className="h-4 w-4" />
                  <AlertDescription>
                    يمكنك طلب كود جديد خلال {countdown} ثانية
                  </AlertDescription>
                </Alert>
              )}

              <Button 
                type="submit" 
                className="w-full" 
                disabled={verifyCodeMutation.isPending}
              >
                {verifyCodeMutation.isPending ? 'جاري التحقق...' : 'تحقق من الكود'}
              </Button>

              <Button
                type="button"
                variant="outline"
                className="w-full"
                onClick={resendCode}
                disabled={countdown > 0 || sendCodeMutation.isPending}
              >
                {countdown > 0 ? `إعادة الإرسال خلال ${countdown}s` : 'إعادة إرسال الكود'}
              </Button>
            </form>
          )}

          {/* خطوة إعادة تعيين كلمة المرور */}
          {step === 'password' && (
            <form onSubmit={passwordForm.handleSubmit(onPasswordSubmit)} className="space-y-4">
              <div>
                <Label htmlFor="newPassword">كلمة المرور الجديدة</Label>
                <Input
                  id="newPassword"
                  type="password"
                  placeholder="أدخل كلمة المرور الجديدة"
                  {...passwordForm.register('newPassword')}
                />
                {passwordForm.formState.errors.newPassword && (
                  <p className="text-sm text-red-600 mt-1">
                    {passwordForm.formState.errors.newPassword.message}
                  </p>
                )}
              </div>

              <div>
                <Label htmlFor="confirmPassword">تأكيد كلمة المرور</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  placeholder="أدخل كلمة المرور مرة أخرى"
                  {...passwordForm.register('confirmPassword')}
                />
                {passwordForm.formState.errors.confirmPassword && (
                  <p className="text-sm text-red-600 mt-1">
                    {passwordForm.formState.errors.confirmPassword.message}
                  </p>
                )}
              </div>

              <Alert>
                <CheckCircle className="h-4 w-4" />
                <AlertDescription>
                  كلمة المرور يجب أن تكون على الأقل 6 أحرف وتحتوي على أرقام وحروف
                </AlertDescription>
              </Alert>

              <Button 
                type="submit" 
                className="w-full" 
                disabled={resetPasswordMutation.isPending}
              >
                {resetPasswordMutation.isPending ? 'جاري التحديث...' : 'تحديث كلمة المرور'}
              </Button>
            </form>
          )}

          {/* رابط العودة */}
          <div className="text-center pt-4">
            <Button
              variant="ghost"
              onClick={() => setLocation('/login')}
              className="text-sm"
            >
              <ArrowRight className="w-4 h-4 ml-1" />
              العودة لتسجيل الدخول
            </Button>
          </div>

          {/* تحذير الأمان */}
          <Alert className="mt-4">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="text-xs">
              لحمايتك، سيتم حظر الحساب مؤقتاً لمدة 15 دقيقة بعد 10 محاولات تسجيل دخول خاطئة متتالية
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    </div>
  );
};