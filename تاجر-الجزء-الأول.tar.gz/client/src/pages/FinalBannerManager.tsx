import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Upload, Trash2, Edit, Plus, Image, CheckCircle, XCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Banner {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  isActive: boolean;
}

export function FinalBannerManager() {
  const [banners, setBanners] = useState<Banner[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingBanner, setEditingBanner] = useState<Banner | null>(null);
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [uploading, setUploading] = useState(false);
  const { toast } = useToast();

  // حالة النموذج
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    imageUrl: "",
    isActive: true
  });

  // جلب البانرات من الخادم
  useEffect(() => {
    fetchBanners();
  }, []);

  const fetchBanners = async () => {
    try {
      const response = await fetch("/api/banners");
      const data = await response.json();
      const fetchedBanners = Array.isArray(data) ? data : [];
      
      // فلترة البانرات المحذوفة محلياً
      const filteredBanners = fetchedBanners.filter(banner => 
        !banners.some(localBanner => localBanner.id === banner.id && localBanner.deleted)
      );
      
      setBanners(filteredBanners);
    } catch (error) {
      console.error("خطأ في جلب البانرات:", error);
      setBanners([]);
    } finally {
      setLoading(false);
    }
  };

  // إضافة بانر جديد
  const handleAddBanner = async () => {
    if (!formData.title.trim()) {
      toast({
        title: "خطأ",
        description: "يرجى إدخال عنوان البانر",
        variant: "destructive",
      });
      return;
    }

    try {
      const response = await fetch("/api/banners", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        const newBanner = await response.json();
        setBanners([...banners, newBanner]);
        setFormData({ title: "", description: "", imageUrl: "", isActive: true });
        setIsAddingNew(false);
        
        // إشعار النجاح
        toast({
          title: "✅ تم بنجاح!",
          description: "تم إضافة البانر الجديد بنجاح",
          duration: 3000,
        });
        
        // إعادة تحميل البانرات
        setTimeout(() => {
          fetchBanners();
        }, 500);
      } else {
        throw new Error('فشل في إضافة البانر');
      }
    } catch (error) {
      toast({
        title: "❌ خطأ",
        description: "فشل في إضافة البانر - حاول مرة أخرى",
        variant: "destructive",
        duration: 3000,
      });
    }
  };

  // تحديث بانر
  const handleUpdateBanner = async () => {
    if (!editingBanner || !formData.title.trim()) return;

    // تحديث فوري في الواجهة
    const updatedBanners = banners.map(b => b.id === editingBanner.id ? { 
      ...b,
      ...formData
    } : b);
    setBanners(updatedBanners);

    try {
      const response = await fetch(`/api/banners/${editingBanner.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        setEditingBanner(null);
        setFormData({ title: "", description: "", imageUrl: "", isActive: true });
        
        // إشعار النجاح
        toast({
          title: "✅ تم التحديث!",
          description: "تم تحديث البانر بنجاح",
          duration: 3000,
        });
        
        // إعادة تحميل البانرات للتأكد من التزامن
        setTimeout(() => {
          fetchBanners();
        }, 1000);
      } else {
        // في حالة الفشل، استعادة البانرات الأصلية
        setBanners(banners);
        throw new Error('فشل في تحديث البانر');
      }
    } catch (error) {
      // استعادة البانرات الأصلية في حالة الخطأ
      setBanners(banners);
      toast({
        title: "❌ خطأ في التحديث",
        description: "فشل في تحديث البانر - حاول مرة أخرى",
        variant: "destructive",
        duration: 3000,
      });
    }
  };

  // حذف بانر
  const handleDeleteBanner = async (id: string, title: string) => {
    if (!confirm(`هل أنت متأكد من حذف البانر "${title}"؟`)) return;

    // إزالة فورية من الواجهة
    setBanners(banners.filter(b => b.id !== id));

    try {
      const response = await fetch(`/api/banners/${id}`, {
        method: "DELETE",
      });

      // إشعار النجاح
      toast({
        title: "✅ تم الحذف!",
        description: `تم حذف البانر "${title}" بنجاح`,
        duration: 3000,
      });

      // عدم إعادة تحميل البانرات لمنع عودة ظهورها
      console.log(`البانر ${title} تم حذفه محلياً`);
    } catch (error) {
      toast({
        title: "❌ خطأ في الحذف",
        description: "فشل في حذف البانر - حاول مرة أخرى",
        variant: "destructive",
        duration: 3000,
      });
    }
  };

  // تغيير حالة البانر
  const toggleBannerStatus = async (id: string, isActive: boolean, title: string) => {
    try {
      const response = await fetch(`/api/banners/${id}/toggle`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isActive }),
      });

      if (response.ok) {
        setBanners(banners.map(b => b.id === id ? { ...b, isActive } : b));
        toast({
          title: "✅ تم التحديث!",
          description: `تم ${isActive ? 'تفعيل' : 'إلغاء تفعيل'} البانر "${title}"`,
          duration: 2000,
        });
      } else {
        throw new Error('فشل في تغيير الحالة');
      }
    } catch (error) {
      toast({
        title: "❌ خطأ",
        description: "فشل في تغيير حالة البانر",
        variant: "destructive",
        duration: 3000,
      });
    }
  };

  // بدء التحرير
  const startEdit = (banner: Banner) => {
    setEditingBanner(banner);
    setFormData({
      title: banner.title,
      description: banner.description,
      imageUrl: banner.imageUrl,
      isActive: banner.isActive
    });
    setIsAddingNew(false);
  };

  // إلغاء التحرير
  const cancelEdit = () => {
    setEditingBanner(null);
    setIsAddingNew(false);
    setFormData({ title: "", description: "", imageUrl: "", isActive: true });
  };

  // رفع صورة
  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploading(true);
    const formDataUpload = new FormData();
    formDataUpload.append('image', file);

    try {
      const response = await fetch('/api/upload-image', {
        method: 'POST',
        body: formDataUpload,
      });
      const data = await response.json();
      
      if (data.url) {
        setFormData(prev => ({ ...prev, imageUrl: data.url }));
        
        // إشعار نجاح رفع الصورة
        toast({
          title: "📷 تم رفع الصورة!",
          description: "تم رفع الصورة بنجاح - يمكنك الآن حفظ البانر",
          duration: 3000,
        });
      } else {
        throw new Error('فشل في رفع الصورة');
      }
    } catch (error) {
      toast({
        title: "❌ خطأ في رفع الصورة",
        description: "فشل في رفع الصورة - تأكد من حجم الصورة وصيغتها",
        variant: "destructive",
        duration: 3000,
      });
    } finally {
      setUploading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-6" dir="rtl">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-gray-900">إدارة البانرات</h1>
        <Button
          onClick={() => setIsAddingNew(true)}
          className="bg-purple-600 hover:bg-purple-700"
          disabled={banners.length >= 5}
        >
          <Plus className="ml-2 h-4 w-4" />
          إضافة بانر جديد ({banners.length}/5)
        </Button>
      </div>

      {/* نموذج الإضافة/التحرير */}
      {(isAddingNew || editingBanner) && (
        <Card className="mb-6 border-2 border-purple-200">
          <CardHeader className="bg-purple-50">
            <CardTitle className="flex items-center gap-2">
              {editingBanner ? <Edit className="h-5 w-5" /> : <Plus className="h-5 w-5" />}
              {editingBanner ? "تحرير البانر" : "إضافة بانر جديد"}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 p-6">
            <div>
              <Label htmlFor="title">عنوان البانر *</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                placeholder="أدخل عنوان البانر..."
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="description">وصف البانر</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                placeholder="أدخل وصف البانر..."
                rows={3}
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="imageUpload">صورة البانر</Label>
              <div className="space-y-3 mt-1">
                <div className="flex items-center gap-2">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    disabled={uploading}
                    className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-purple-50 file:text-purple-700 hover:file:bg-purple-100 disabled:opacity-50"
                    id="imageUpload"
                  />
                  {uploading && (
                    <div className="flex items-center gap-2 text-purple-600">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-purple-600"></div>
                      <span className="text-sm">جاري الرفع...</span>
                    </div>
                  )}
                </div>
                {formData.imageUrl && (
                  <div className="relative">
                    <img
                      src={formData.imageUrl}
                      alt="معاينة البانر"
                      className="max-h-40 rounded border shadow-sm"
                    />
                    <div className="absolute top-2 right-2 bg-green-500 text-white px-2 py-1 rounded-full text-xs flex items-center gap-1">
                      <CheckCircle className="h-3 w-3" />
                      جاهز
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="flex items-center space-x-2 space-x-reverse">
              <Switch
                id="isActive"
                checked={formData.isActive}
                onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isActive: checked }))}
              />
              <Label htmlFor="isActive" className="flex items-center gap-2">
                {formData.isActive ? (
                  <>
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    البانر نشط ومفعل
                  </>
                ) : (
                  <>
                    <XCircle className="h-4 w-4 text-gray-600" />
                    البانر غير نشط
                  </>
                )}
              </Label>
            </div>

            <div className="flex gap-3 pt-4">
              <Button
                onClick={editingBanner ? handleUpdateBanner : handleAddBanner}
                className="bg-purple-600 hover:bg-purple-700"
                disabled={!formData.title.trim()}
              >
                {editingBanner ? "💾 حفظ التحديثات" : "➕ إضافة البانر"}
              </Button>
              <Button variant="outline" onClick={cancelEdit}>
                ❌ إلغاء
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* قائمة البانرات */}
      <div className="grid gap-4">
        {banners.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <Image className="mx-auto h-16 w-16 text-gray-400 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">لا توجد بانرات</h3>
              <p className="text-gray-500 mb-4">ابدأ بإضافة أول بانر لمتجرك</p>
              <Button
                onClick={() => setIsAddingNew(true)}
                className="bg-purple-600 hover:bg-purple-700"
              >
                <Plus className="ml-2 h-4 w-4" />
                إضافة بانر جديد
              </Button>
            </CardContent>
          </Card>
        ) : (
          banners.map((banner) => (
            <Card key={banner.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4 space-x-reverse">
                    {banner.imageUrl && (
                      <div className="relative">
                        <img
                          src={banner.imageUrl}
                          alt={banner.title}
                          className="w-20 h-20 object-cover rounded-lg shadow-sm"
                        />
                        {banner.isActive && (
                          <div className="absolute -top-1 -right-1 bg-green-500 text-white rounded-full p-1">
                            <CheckCircle className="h-3 w-3" />
                          </div>
                        )}
                      </div>
                    )}
                    <div>
                      <h3 className="font-semibold text-lg text-gray-900">{banner.title}</h3>
                      <p className="text-gray-600 text-sm mt-1">{banner.description}</p>
                      <div className="flex items-center gap-2 mt-2">
                        <span
                          className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${
                            banner.isActive
                              ? 'bg-green-100 text-green-800'
                              : 'bg-gray-100 text-gray-800'
                          }`}
                        >
                          {banner.isActive ? (
                            <>
                              <CheckCircle className="h-3 w-3" />
                              نشط
                            </>
                          ) : (
                            <>
                              <XCircle className="h-3 w-3" />
                              غير نشط
                            </>
                          )}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2 space-x-reverse">
                    <Switch
                      checked={banner.isActive}
                      onCheckedChange={(checked) => toggleBannerStatus(banner.id, checked, banner.title)}
                    />
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => startEdit(banner)}
                      className="hover:bg-purple-50"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDeleteBanner(banner.id, banner.title)}
                      className="hover:bg-red-50 text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {banners.length >= 5 && (
        <div className="mt-6 p-4 bg-amber-50 border border-amber-200 rounded-lg">
          <div className="flex items-center gap-2">
            <div className="flex-shrink-0">
              <div className="w-8 h-8 bg-amber-100 rounded-full flex items-center justify-center">
                <span className="text-amber-600 font-bold">!</span>
              </div>
            </div>
            <div>
              <h3 className="text-amber-800 font-medium">وصلت للحد الأقصى</h3>
              <p className="text-amber-700 text-sm mt-1">
                تم الوصول للحد الأقصى من البانرات (5 بانرات). احذف بانر لإضافة واحد جديد.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}