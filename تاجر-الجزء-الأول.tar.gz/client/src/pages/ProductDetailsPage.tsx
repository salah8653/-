import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowRight, Heart, Share2, ShoppingCart, Plus, Minus, Star, Package, Bookmark } from "lucide-react";
import { useLocation } from "wouter";
import { useCart } from "@/hooks/useCart";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest } from "@/lib/queryClient";
import { ProductWithCategory } from "shared/schema";

export const ProductDetailsPage = () => {
  const [, params] = useRoute("/product/:id");
  const [, setLocation] = useLocation();
  const [quantity, setQuantity] = useState(1);
  const [customPrice, setCustomPrice] = useState("");
  const [isSaved, setIsSaved] = useState(false);
  const { addItem } = useCart();
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: product, isLoading } = useQuery<ProductWithCategory>({
    queryKey: ["/api/products", params?.id],
    enabled: !!params?.id,
  });

  // جلب حالة الحفظ للمنتج
  const { data: savedProducts = [] } = useQuery({
    queryKey: ["/api/saved-products"],
    enabled: !!user,
  });

  // تحديث حالة الحفظ عند تحميل البيانات
  useEffect(() => {
    if (Array.isArray(savedProducts) && product) {
      const isProductSaved = savedProducts.some((saved: any) => saved.productId === product.id);
      setIsSaved(isProductSaved);
    }
  }, [savedProducts, product]);

  // تعيين السعر الافتراضي عند تحميل المنتج
  useEffect(() => {
    if (product) {
      setCustomPrice(product.price);
    }
  }, [product]);

  // حفظ/إلغاء حفظ المنتج
  const toggleSaveMutation = useMutation({
    mutationFn: async () => {
      if (isSaved) {
        return await apiRequest('DELETE', `/api/saved-products/${product?.id}`);
      } else {
        return await apiRequest('POST', '/api/saved-products', {
          productId: product?.id,
        });
      }
    },
    onSuccess: () => {
      setIsSaved(!isSaved);
      queryClient.invalidateQueries({ queryKey: ['/api/saved-products'] });
      toast({
        title: isSaved ? "تم إلغاء الحفظ" : "تم حفظ المنتج",
        description: isSaved ? "تم إزالة المنتج من المحفوظات" : "تم إضافة المنتج إلى المحفوظات",
      });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "حدث خطأ، يرجى المحاولة مرة أخرى",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-gray-500">المنتج غير موجود</p>
      </div>
    );
  }

  // التحقق من صحة السعر المخصص
  const isValidPrice = () => {
    const price = parseFloat(customPrice);
    if (!product) return false;
    
    const minPrice = product.minPrice ? parseFloat(product.minPrice) : 0;
    const maxPrice = product.maxPrice ? parseFloat(product.maxPrice) : Infinity;
    
    return price >= minPrice && price <= maxPrice;
  };

  const handleAddToCart = () => {
    if (product && isValidPrice()) {
      const productWithCustomPrice = {
        ...product,
        price: customPrice
      };
      addItem(productWithCustomPrice, quantity);
      toast({
        title: "تم إضافة المنتج",
        description: `تم إضافة ${quantity} من ${product.name} إلى العربة`,
      });
    } else {
      toast({
        title: "خطأ في السعر",
        description: "يرجى إدخال سعر صحيح ضمن الحدود المسموحة",
        variant: "destructive",
      });
    }
  };

  const handleQuantityChange = (newQuantity: number) => {
    if (newQuantity >= 1 && newQuantity <= (product?.stock || 0)) {
      setQuantity(newQuantity);
    }
  };

  const handlePriceChange = (value: string) => {
    // السماح بالأرقام والنقطة العشرية فقط
    if (/^\d*\.?\d*$/.test(value)) {
      setCustomPrice(value);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      {/* Header */}
      <div className="bg-white shadow-sm sticky top-0 z-10">
        <div className="p-4 flex items-center justify-between">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => setLocation("/")}
          >
            <ArrowRight className="h-5 w-5" />
          </Button>
          
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon">
              <Share2 className="h-5 w-5" />
            </Button>
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => toggleSaveMutation.mutate()}
              disabled={!user || toggleSaveMutation.isPending}
            >
              <Bookmark className={`h-5 w-5 ${isSaved ? 'fill-blue-500 text-blue-500' : ''}`} />
            </Button>
          </div>
        </div>
      </div>

      {/* Product Image */}
      <div className="bg-white">
        <div className="aspect-square relative">
          {product.imageUrl ? (
            <img 
              src={product.imageUrl} 
              alt={product.name}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full bg-gray-100 flex items-center justify-center">
              <Package className="h-20 w-20 text-gray-400" />
            </div>
          )}
          
          {/* Discount Badge */}
          <div className="absolute top-4 right-4">
            <Badge className="bg-red-500 text-white">
              خصم 25%
            </Badge>
          </div>
        </div>
      </div>

      {/* Product Info */}
      <div className="p-4 space-y-4">
        <Card>
          <CardContent className="p-4">
            <div className="space-y-3">
              <h1 className="text-xl font-bold text-gray-900">
                {product.name}
              </h1>
              
              <div className="flex items-center gap-2">
                <div className="flex items-center">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star 
                      key={star} 
                      className="h-4 w-4 fill-yellow-400 text-yellow-400" 
                    />
                  ))}
                </div>
                <span className="text-sm text-gray-500">(124 تقييم)</span>
              </div>

              <div className="flex items-center gap-3">
                <span className="text-2xl font-bold text-purple-600">
                  {parseFloat(product.price).toLocaleString()} د.ع
                </span>
                <span className="text-lg text-gray-400 line-through">
                  {(parseFloat(product.price) * 1.33).toLocaleString()} د.ع
                </span>
                <Badge variant="secondary" className="bg-green-100 text-green-700">
                  وفر {((parseFloat(product.price) * 0.33)).toLocaleString()} د.ع
                </Badge>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-sm text-gray-500">المتوفر:</span>
                <Badge variant={product.stock > 10 ? "default" : "destructive"}>
                  {product.stock} قطعة
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Description */}
        <Card>
          <CardContent className="p-4">
            <h2 className="font-semibold text-gray-900 mb-2">وصف المنتج</h2>
            <p className="text-gray-600 leading-relaxed">
              {product.description}
            </p>
          </CardContent>
        </Card>

        {/* Quantity Selector */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-gray-900">الكمية</h3>
              <div className="flex items-center gap-3">
                <Button 
                  variant="outline" 
                  size="icon"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  disabled={quantity <= 1}
                >
                  <Minus className="h-4 w-4" />
                </Button>
                
                <span className="text-lg font-semibold min-w-[2rem] text-center">
                  {quantity}
                </span>
                
                <Button 
                  variant="outline" 
                  size="icon"
                  onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                  disabled={quantity >= product.stock}
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Specifications */}
        <Card>
          <CardContent className="p-4">
            <h2 className="font-semibold text-gray-900 mb-3">المواصفات</h2>
            <div className="space-y-2 text-sm">

              <div className="flex justify-between">
                <span className="text-gray-500">الفئة:</span>
                <span className="font-medium">{product.category?.name || "غير محدد"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">الحالة:</span>
                <Badge variant="default" className="bg-green-500">
                  متوفر
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bottom Actions */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4">
        <div className="flex gap-3">
          <Button 
            variant="outline" 
            className="flex-1"
            onClick={() => toggleSaveMutation.mutate()}
            disabled={!user || toggleSaveMutation.isPending}
          >
            <Bookmark className={`h-4 w-4 ml-2 ${isSaved ? 'fill-blue-500 text-blue-500' : ''}`} />
            {isSaved ? 'محفوظ' : 'حفظ'}
          </Button>
          
          <Button 
            className="flex-1 bg-purple-600 hover:bg-purple-700"
            onClick={handleAddToCart}
          >
            <ShoppingCart className="h-4 w-4 ml-2" />
            إضافة للعربة
          </Button>
        </div>
      </div>
    </div>
  );
};