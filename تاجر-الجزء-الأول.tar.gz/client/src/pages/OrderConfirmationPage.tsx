import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { ArrowRight, CheckCircle, Package, Truck, CreditCard, Phone, DollarSign } from 'lucide-react';
import { formatCurrency, getOrderStatus, getOrderStatusColor } from './utils/formatters';

interface CartItem {
  id: number;
  productId: number;
  quantity: number;
  product: {
    id: number;
    name: string;
    price: string;
    imageUrl: string;
    description: string;
    minPrice?: string;
    maxPrice?: string;
  };
}

export const OrderConfirmationPage = () => {
  const [, setLocation] = useLocation();
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [customerPrice, setCustomerPrice] = useState(0);
  const [deliveryFee, setDeliveryFee] = useState(5000); // سعر التوصيل الافتراضي
  const [deliveryContribution, setDeliveryContribution] = useState(0); // مساهمة العميل في التوصيل
  const [customerInfo, setCustomerInfo] = useState<any>({});
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchOrderData();
  }, []);

  const fetchOrderData = async () => {
    try {
      // جلب بيانات السلة
      const cartResponse = await fetch('/api/cart');
      if (cartResponse.ok) {
        const cartItems = await cartResponse.json();
        setCartItems(cartItems);
      }

      // جلب البيانات المحفوظة من localStorage
      const savedPrice = localStorage.getItem('customerPrice');
      const savedDeliveryFee = localStorage.getItem('deliveryFee');
      const savedCustomerInfo = localStorage.getItem('customerInfo');

      if (savedPrice) {
        setCustomerPrice(parseFloat(savedPrice));
      }
      if (savedDeliveryFee) {
        setDeliveryFee(parseFloat(savedDeliveryFee));
      }
      if (savedCustomerInfo) {
        setCustomerInfo(JSON.parse(savedCustomerInfo));
      }
    } catch (error) {
      console.error('خطأ في جلب بيانات الطلب:', error);
    }
  };

  const getWholesaleTotal = () => {
    return cartItems.reduce((total, item) => {
      return total + (parseFloat(item.product.price) * item.quantity);
    }, 0);
  };

  const getProfit = () => {
    const wholesaleTotal = getWholesaleTotal();
    // الربح ينقص عندما ندفع من ربحنا لتغطية التوصيل
    const profit = customerPrice - wholesaleTotal - deliveryContribution;
    return profit < 0 ? 0 : profit;
  };

  // التحكم في مساهمة العميل في كلفة التوصيل
  const handleDeliveryContributionChange = (value: number[]) => {
    const contribution = value[0];
    setDeliveryContribution(contribution);
    // كلما زادت المساهمة، قل سعر التوصيل على العميل
    const newDeliveryFee = 5000 - contribution;
    setDeliveryFee(newDeliveryFee);
  };

  const getTotalWithDelivery = () => {
    return customerPrice + deliveryFee;
  };

  const getTotalItems = () => {
    return cartItems.reduce((sum, item) => sum + item.quantity, 0);
  };

  const isValidPhoneNumber = (phone: string) => {
    // التحقق من أن رقم الهاتف يحتوي على 11 رقماً فقط
    const phoneRegex = /^[0-9]{11}$/;
    return phoneRegex.test(phone);
  };

  const handleConfirmOrder = async () => {
    if (!isValidPhoneNumber(customerInfo.phone)) {
      alert('يرجى إدخال رقم هاتف صحيح (11 رقماً فقط)');
      return;
    }

    setLoading(true);
    try {
      const orderData = {
        customerInfo,
        items: cartItems,
        customerPrice,
        deliveryFee,
        totalWithDelivery: getTotalWithDelivery(),
        wholesaleTotal: getWholesaleTotal(),
        profit: getProfit(),
        totalItems: getTotalItems(),
        orderDate: new Date().toISOString()
      };

      const response = await fetch('/api/orders', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(orderData)
      });

      if (response.ok) {
        const result = await response.json();
        console.log('تم حفظ الطلب بنجاح:', result);
        
        // مسح بيانات السلة و localStorage
        await fetch('/api/cart', { method: 'DELETE' });
        localStorage.removeItem('customerPrice');
        localStorage.removeItem('deliveryFee');
        localStorage.removeItem('customerInfo');
        
        // تحديث السلة في المكون
        setCartItems([]);
        setCustomerPrice(0);
        
        alert('تم تثبيت الطلب بنجاح! سيتم توجيهك لصفحة الطلبات الآن.');
        
        // التوجه إلى صفحة الطلبات تلقائياً
        setTimeout(() => {
          setLocation('/orders');
        }, 1000);
      } else {
        throw new Error('فشل في حفظ الطلب');
      }
    } catch (error) {
      console.error('خطأ في تثبيت الطلب:', error);
      alert('حدث خطأ في تثبيت الطلب');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-100 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <CheckCircle className="w-8 h-8 text-green-500" />
            <h1 className="text-3xl font-bold text-gray-800">تثبيت الطلب</h1>
          </div>
          
          {/* Progress Steps */}
          <div className="flex items-center justify-center gap-4 mb-6">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-green-500 text-white rounded-full flex items-center justify-center text-sm font-bold">✓</div>
              <span className="text-gray-600">تفاصيل التوصيل</span>
            </div>
            <ArrowRight className="w-5 h-5 text-gray-400" />
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-purple-500 text-white rounded-full flex items-center justify-center text-sm font-bold">2</div>
              <span className="text-purple-600 font-semibold">تثبيت الطلب</span>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Left Column - Order Summary */}
          <div className="space-y-6">
            {/* Customer Info Summary */}
            <Card className="bg-white rounded-2xl shadow-lg border border-purple-100">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <Package className="w-6 h-6 text-purple-600" />
                  <h3 className="text-xl font-bold text-gray-800">معلومات التوصيل</h3>
                </div>
                <div className="space-y-3 text-gray-700">
                  <div><span className="font-semibold">الاسم:</span> {customerInfo.name}</div>
                  <div><span className="font-semibold">رقم الهاتف:</span> {customerInfo.phone}</div>
                  <div><span className="font-semibold">المحافظة:</span> {customerInfo.governorate}</div>
                  <div><span className="font-semibold">المنطقة:</span> {customerInfo.area}</div>
                  <div><span className="font-semibold">العنوان:</span> {customerInfo.address}</div>
                  {customerInfo.notes && (
                    <div><span className="font-semibold">الملاحظات:</span> {customerInfo.notes}</div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Order Items */}
            <Card className="bg-white rounded-2xl shadow-lg border border-purple-100">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <Package className="w-6 h-6 text-purple-600" />
                  <h3 className="text-xl font-bold text-gray-800">المنتجات ({getTotalItems()} قطعة)</h3>
                </div>
                <div className="space-y-3">
                  {cartItems.map((item) => (
                    <div key={item.id} className="flex items-center gap-4 p-3 bg-gray-50 rounded-xl">
                      <img 
                        src={item.product.imageUrl} 
                        alt={item.product.name}
                        className="w-16 h-16 object-cover rounded-lg"
                      />
                      <div className="flex-1">
                        <h4 className="font-semibold text-gray-800">{item.product.name}</h4>
                        <p className="text-gray-600">الكمية: {item.quantity}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-gray-800">
                          {(parseFloat(item.product.price) * item.quantity).toLocaleString()} د.ع
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Price Summary */}
          <div className="space-y-6">

            {/* Delivery Fee Contribution Slider */}
            <Card className="bg-white rounded-2xl shadow-lg border border-orange-100">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <DollarSign className="w-6 h-6 text-orange-600" />
                  <h3 className="text-lg font-bold text-gray-800">ادفع كلفة التوصيل من ربحك</h3>
                </div>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-gray-600">مساهمتك في التوصيل:</span>
                    <span className="text-lg font-bold text-orange-600">
                      {deliveryContribution.toLocaleString()} د.ع
                    </span>
                  </div>
                  
                  <div className="px-2">
                    <Slider
                      value={[deliveryContribution]}
                      onValueChange={handleDeliveryContributionChange}
                      max={5000}
                      min={0}
                      step={250}
                      className="w-full"
                      dir="rtl"
                    />
                    <div className="flex justify-between text-xs text-gray-500 mt-2">
                      <span>5,000 د.ع</span>
                      <span>مجاني</span>
                    </div>
                  </div>
                  
                  <div className="bg-gradient-to-r from-blue-50 to-green-50 rounded-xl p-3 border border-blue-200">
                    <div className="space-y-2">
                      <div className="flex justify-between items-center text-sm">
                        <span className="text-gray-600">أجرة التوصيل الفعلية:</span>
                        <span className="font-semibold text-blue-600">
                          {deliveryFee.toLocaleString()} د.ع
                        </span>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <span className="text-gray-600">ربحك المحدث:</span>
                        <span className="font-semibold text-green-600">
                          {getProfit().toLocaleString()} د.ع
                        </span>
                      </div>
                    </div>
                    <p className="text-xs text-gray-500 mt-2">
                      كلما زادت مساهمتك، قل سعر التوصيل وقل ربحك
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Price Summary */}
            <Card className="bg-gradient-to-r from-purple-50 to-indigo-50 rounded-2xl shadow-lg border border-purple-100">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-6">
                  <CreditCard className="w-6 h-6 text-purple-600" />
                  <h3 className="text-xl font-bold text-gray-800">ملخص الفاتورة</h3>
                </div>
                
                <div className="space-y-4">
                  <div className="flex justify-between items-center py-2 border-b border-purple-200">
                    <span className="text-gray-600">إجمالي سعر الجملة:</span>
                    <span className="font-semibold text-gray-800">{getWholesaleTotal().toLocaleString()} د.ع</span>
                  </div>
                  
                  <div className="flex justify-between items-center py-2 border-b border-purple-200">
                    <span className="text-gray-600">سعر البيع للزبون:</span>
                    <span className="font-semibold text-purple-600">{customerPrice.toLocaleString()} د.ع</span>
                  </div>
                  
                  <div className="flex justify-between items-center py-2 border-b border-purple-200">
                    <span className="text-gray-600">أجرة التوصيل:</span>
                    <span className="font-semibold text-orange-600">{deliveryFee.toLocaleString()} د.ع</span>
                  </div>
                  
                  <div className="flex justify-between items-center py-2 border-b border-purple-200">
                    <span className="text-gray-600">الربح المحقق:</span>
                    <span className="font-semibold text-green-600">{getProfit().toLocaleString()} د.ع</span>
                  </div>
                  
                  <div className="bg-gradient-to-r from-purple-100 to-indigo-100 p-4 rounded-xl border border-purple-200">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-800 font-bold text-lg">إجمالي المبلغ النهائي:</span>
                      <span className="font-bold text-purple-700 text-2xl">
                        {getTotalWithDelivery().toLocaleString()} د.ع
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Confirm Button */}
            <div className="space-y-4">
              <Button
                onClick={handleConfirmOrder}
                disabled={!isValidPhoneNumber(customerInfo.phone) || loading}
                className="w-full bg-green-500 hover:bg-green-600 text-white py-4 text-lg font-bold rounded-2xl disabled:bg-gray-300 disabled:cursor-not-allowed"
              >
                {loading ? 'جاري تثبيت الطلب...' : 'تثبيت الطلب نهائياً'}
              </Button>
              
              <Button
                onClick={() => setLocation('/checkout')}
                variant="outline"
                className="w-full border-purple-200 text-purple-600 hover:bg-purple-50 py-3 text-lg rounded-2xl"
              >
                العودة للتعديل
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};