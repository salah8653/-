import { Button } from "@/components/ui/button";
import { ArrowRight, ArrowLeft } from "lucide-react";
import { useLocation } from "wouter";
import { LanguageSettings } from "@/components/LanguageSettings";
import { useLanguage } from "@/contexts/LanguageContext";

export const LanguageSettingsPage = () => {
  const [, setLocation] = useLocation();
  const { t, dir } = useLanguage();

  return (
    <div className="min-h-screen bg-gray-50" dir={dir}>
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="p-4 flex items-center gap-3">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => setLocation("/user-settings")}
          >
            {dir === 'rtl' ? (
              <ArrowRight className="h-5 w-5" />
            ) : (
              <ArrowLeft className="h-5 w-5" />
            )}
          </Button>
          <h1 className="text-xl font-bold">{t('settings.language')}</h1>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        <LanguageSettings />
      </div>
    </div>
  );
};