import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { ArrowRight, CreditCard, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest } from "@/lib/queryClient";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const mastercardSchema = z.object({
  cardNumber: z.string()
    .min(10, "رقم البطاقة يجب أن يكون 10 أو 12 رقم")
    .max(12, "رقم البطاقة يجب أن يكون 10 أو 12 رقم")
    .regex(/^[0-9]+$/, "يجب أن يحتوي على أرقام فقط")
    .refine((val) => val.length === 10 || val.length === 12, {
      message: "رقم البطاقة يجب أن يكون 10 أو 12 رقم بالضبط"
    }),
  fullName: z.string()
    .min(6, "الاسم الثلاثي مطلوب")
    .max(50, "الاسم طويل جداً"),
});

type MastercardFormData = z.infer<typeof mastercardSchema>;

export const MastercardWithdrawPage = () => {
  const [, setLocation] = useLocation();
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [formData, setFormData] = useState<MastercardFormData | null>(null);
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const form = useForm<MastercardFormData>({
    resolver: zodResolver(mastercardSchema),
    defaultValues: {
      cardNumber: "",
      fullName: "",
    },
  });

  const withdrawMutation = useMutation({
    mutationFn: async (data: MastercardFormData) => {
      return apiRequest("POST", "/api/withdraw", {
        method: "mastercard",
        cardNumber: data.cardNumber,
        fullName: data.fullName,
        userPhone: user?.phone,
      });
    },
    onSuccess: (response: any) => {
      toast({
        title: "تم تأكيد الطلب بنجاح",
        description: `تم تصفير الأرباح وإرسال الطلب. المبلغ: ${response.withdrawnAmount?.toLocaleString()} د.ع`,
      });
      // تحديث جميع البيانات المرتبطة بالأرباح
      queryClient.invalidateQueries({ queryKey: [`/api/user-stats/${user?.phone}`] });
      queryClient.invalidateQueries({ queryKey: ['/api/orders'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
      
      // توجيه المستخدم لصفحة الملف الشخصي لمشاهدة الأرباح المحدثة
      setTimeout(() => {
        setLocation("/profile");
      }, 2000);
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في تأكيد الطلب",
        description: error.message || "حدث خطأ أثناء طلب السحب",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: MastercardFormData) => {
    setFormData(data);
    setShowConfirmDialog(true);
  };

  const handleConfirm = () => {
    if (formData) {
      withdrawMutation.mutate(formData);
    }
    setShowConfirmDialog(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-md mx-auto">
        {/* Header */}
        <div className="flex items-center mb-6">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLocation("/withdraw")}
            className="p-2"
          >
            <ArrowRight className="w-5 h-5" />
          </Button>
          <h1 className="text-xl font-bold text-gray-900 mr-3">
            سحب عبر ماستر كارد الرافدين
          </h1>
        </div>

        {/* Form Card */}
        <Card>
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CreditCard className="w-8 h-8 text-purple-600" />
            </div>
            <CardTitle>بيانات ماستر كارد الرافدين</CardTitle>
          </CardHeader>
          
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="cardNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>الرقم الذي تحت الاسم في البطاقة (10 أو 12 رقم)</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="1234567890"
                          {...field}
                          className="text-center"
                          dir="ltr"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="fullName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>الاسم الثلاثي</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="أحمد محمد علي"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button 
                  type="submit" 
                  className="w-full bg-purple-600 hover:bg-purple-700"
                  disabled={withdrawMutation.isPending}
                >
                  {withdrawMutation.isPending ? "جاري المعالجة..." : "تأكيد الطلب"}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>

        {/* Info Card */}
        <Card className="mt-6 bg-orange-50 border-orange-200">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-orange-600 mt-0.5" />
              <div className="text-sm text-orange-800">
                <p className="font-medium mb-1">معلومات مهمة:</p>
                <ul className="space-y-1 text-xs">
                  <li>• أدخل الرقم المكتوب تحت اسمك في البطاقة</li>
                  <li>• الاسم يجب أن يطابق اسم البطاقة</li>
                  <li>• تأكد من صحة البيانات قبل التأكيد</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Confirmation Dialog */}
      <AlertDialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>تأكيد سحب الأرباح</AlertDialogTitle>
            <AlertDialogDescription className="text-right">
              هل أنت متأكد من سحب الأرباح بالبيانات التالية؟
              <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                <p><strong>رقم البطاقة:</strong> {formData?.cardNumber}</p>
                <p><strong>الاسم:</strong> {formData?.fullName}</p>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirm}>
              نعم، سحب الأرباح
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};