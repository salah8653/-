import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Package, Edit, Save, X, Upload } from "lucide-react";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";

export default function ProductsList() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [editingProduct, setEditingProduct] = useState<any>(null);
  const [editForm, setEditForm] = useState({
    name: '',
    price: '',
    minPrice: '',
    maxPrice: '',
    stock: '0',
    description: '',
    categoryId: '',
    imageUrl: '',
    additionalImages: []
  });
  
  const [selectedEditImage, setSelectedEditImage] = useState<File | null>(null);
  const [editPreviewUrl, setEditPreviewUrl] = useState<string>('');
  const [selectedAdditionalImages, setSelectedAdditionalImages] = useState<File[]>([]);
  const [additionalPreviewUrls, setAdditionalPreviewUrls] = useState<string[]>([]);

  const { data: products, isLoading } = useQuery({
    queryKey: ['/api/products'],
    queryFn: async () => {
      const response = await fetch('/api/products');
      if (!response.ok) throw new Error('فشل في جلب المنتجات');
      return response.json();
    }
  });

  // جلب الفئات
  const { data: categories = [] } = useQuery<any[]>({
    queryKey: ['/api/categories'],
  });

  // حذف جميع المنتجات
  const clearProductsMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/products/clear-all', {
        method: 'POST'
      });
      if (!response.ok) throw new Error('فشل في حذف المنتجات');
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم الحذف! ✅",
        description: "تم حذف جميع المنتجات بنجاح",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
    }
  });

  // تحديث المنتج
  const updateProductMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number, data: any }) => {
      const response = await fetch(`/api/products/update-direct`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, ...data })
      });
      if (!response.ok) throw new Error('فشل في تحديث المنتج');
      return response.json();
    },
    onSuccess: (updatedProduct) => {
      toast({
        title: "تم التحديث! ✅",
        description: "تم تحديث المنتج بنجاح",
      });
      
      // تحديث البيانات المحلية فوراً
      queryClient.setQueryData(['/api/products'], (oldData: any) => {
        if (!oldData) return oldData;
        return oldData.map((product: any) => 
          product.id === updatedProduct.id ? updatedProduct : product
        );
      });
      
      // إعادة جلب البيانات للتأكد
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      setEditingProduct(null);
    },
    onError: () => {
      toast({
        title: "خطأ في التحديث ❌",
        description: "حاول مرة أخرى",
        variant: "destructive",
      });
    }
  });

  const handleEdit = (product: any) => {
    setEditingProduct(product);
    setEditForm({
      name: product.name || '',
      price: product.price?.toString() || '',
      minPrice: product.minPrice?.toString() || '',
      maxPrice: product.maxPrice?.toString() || '',
      stock: product.stock?.toString() || '0',
      description: product.description || '',
      categoryId: product.categoryId?.toString() || '',
      imageUrl: product.imageUrl || '',
      additionalImages: product.additionalImages || []
    });
    setEditPreviewUrl(product.imageUrl || '');
    setSelectedEditImage(null);
    setSelectedAdditionalImages([]);
    setAdditionalPreviewUrls(product.additionalImages || []);
  };

  const handleEditImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedEditImage(file);
      const reader = new FileReader();
      reader.onload = () => {
        setEditPreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAdditionalImagesChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length > 0 && files.length <= 2) {
      setSelectedAdditionalImages(files);
      
      // إنشاء معاينات للصور
      const previews: string[] = [];
      files.forEach((file, index) => {
        const reader = new FileReader();
        reader.onload = () => {
          previews[index] = reader.result as string;
          if (previews.length === files.length) {
            setAdditionalPreviewUrls(previews);
          }
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const removeAdditionalImage = (index: number) => {
    const newFiles = selectedAdditionalImages.filter((_, i) => i !== index);
    const newPreviews = additionalPreviewUrls.filter((_, i) => i !== index);
    setSelectedAdditionalImages(newFiles);
    setAdditionalPreviewUrls(newPreviews);
  };

  const handleSave = async () => {
    if (!editForm.name.trim() || !editForm.price || !editForm.minPrice || !editForm.maxPrice) {
      toast({
        title: "بيانات ناقصة",
        description: "يرجى ملء جميع الحقول المطلوبة",
        variant: "destructive",
      });
      return;
    }

    let imageUrl = editForm.imageUrl;
    let additionalImages = editForm.additionalImages || [];

    // رفع الصورة الرئيسية الجديدة إذا تم اختيارها
    if (selectedEditImage) {
      try {
        const formData = new FormData();
        formData.append('image', selectedEditImage);
        
        const uploadResponse = await fetch('/api/upload-image', {
          method: 'POST',
          body: formData,
        });
        
        if (uploadResponse.ok) {
          const result = await uploadResponse.json();
          imageUrl = result.url;
        }
      } catch (error) {
        toast({
          title: "خطأ في رفع الصورة الرئيسية",
          description: "لم يتم رفع الصورة، سيتم حفظ باقي البيانات",
          variant: "destructive",
        });
      }
    }

    // رفع الصور الإضافية إذا تم اختيارها
    if (selectedAdditionalImages.length > 0) {
      try {
        const uploadedAdditionalImages = [];
        
        for (const file of selectedAdditionalImages) {
          const formData = new FormData();
          formData.append('image', file);
          
          const uploadResponse = await fetch('/api/upload-image', {
            method: 'POST',
            body: formData,
          });
          
          if (uploadResponse.ok) {
            const result = await uploadResponse.json();
            uploadedAdditionalImages.push(result.url);
          }
        }
        
        // دمج الصور الجديدة مع الموجودة
        additionalImages = [...additionalImages, ...uploadedAdditionalImages];
      } catch (error) {
        toast({
          title: "خطأ في رفع الصور الإضافية",
          description: "لم يتم رفع بعض الصور، سيتم حفظ باقي البيانات",
          variant: "destructive",
        });
      }
    }

    const updateData = {
      name: editForm.name.trim(),
      price: parseFloat(editForm.price),
      minPrice: parseFloat(editForm.minPrice),
      maxPrice: parseFloat(editForm.maxPrice),
      stock: parseInt(editForm.stock) || 0,
      description: editForm.description.trim(),
      categoryId: editForm.categoryId ? parseInt(editForm.categoryId) : 1748523924381,
      imageUrl: imageUrl,
      additionalImages: additionalImages
    };
    
    console.log('بيانات التحديث المرسلة:', updateData);
    
    updateProductMutation.mutate({
      id: editingProduct.id,
      data: updateData
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 p-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center py-12">
            <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full mx-auto"></div>
            <p className="mt-4 text-gray-600">جاري تحميل المنتجات...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-2 md:p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-4 md:mb-6 gap-4">
          <div className="flex items-center space-x-4">
            <Package className="h-6 w-6 md:h-8 md:w-8 text-blue-600" />
            <div>
              <h1 className="text-xl md:text-2xl font-bold text-gray-900">إدارة المنتجات</h1>
              <p className="text-sm md:text-base text-gray-600">
                {products?.length || 0} منتج في المتجر
              </p>
            </div>
          </div>
          
          <div className="flex gap-3">
            <Link href="/categories/new">
              <Button variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-50">
                <Plus className="h-4 w-4 ml-2" />
                إضافة فئة
              </Button>
            </Link>
            <Link href="/products/new">
              <Button className="bg-green-600 hover:bg-green-700">
                <Plus className="h-4 w-4 ml-2" />
                إضافة منتج جديد
              </Button>
            </Link>
          </div>
        </div>

        {/* Products Grid */}
        {!products || products.length === 0 ? (
          <Card className="text-center py-12">
            <CardContent>
              <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                لا توجد منتجات حتى الآن
              </h3>
              <p className="text-gray-600 mb-6">
                ابدأ بإضافة منتجك الأول للمتجر
              </p>
              <Link href="/products/new">
                <Button className="bg-green-600 hover:bg-green-700">
                  <Plus className="h-4 w-4 ml-2" />
                  إضافة منتج جديد
                </Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 md:gap-6">
            {products.map((product: any) => (
              <Card key={product.id} className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-2 md:pb-3">
                  <div className="flex items-start justify-between">
                    <CardTitle className="text-base md:text-lg line-clamp-2">
                      {product.name || 'منتج بدون اسم'}
                    </CardTitle>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleEdit(product)}
                      className="flex-shrink-0"
                    >
                      <Edit className="h-3 w-3 md:h-4 md:w-4" />
                    </Button>
                  </div>
                </CardHeader>
                
                <CardContent className="pt-0">
                  {/* صورة المنتج */}
                  <div className="mb-4">
                    {product.imageUrl ? (
                      <img
                        src={product.imageUrl}
                        alt={product.name}
                        className="w-full h-24 sm:h-28 md:h-32 object-cover rounded-lg"
                      />
                    ) : (
                      <div className="w-full h-32 bg-gray-100 rounded-lg flex items-center justify-center">
                        <Package className="h-8 w-8 text-gray-400" />
                      </div>
                    )}
                  </div>

                  {/* تفاصيل المنتج */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">سعر الجملة:</span>
                      <span className="font-semibold text-purple-600">
                        {product.price} دينار
                      </span>
                    </div>
                    
                    {product.minPrice && product.maxPrice && (
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">نطاق السعر:</span>
                        <span className="font-semibold text-green-600">
                          {product.minPrice} - {product.maxPrice} دينار
                        </span>
                      </div>
                    )}
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">الكمية:</span>
                      <span className="font-semibold">
                        {product.stock}
                      </span>
                    </div>

                    {product.description && (
                      <p className="text-sm text-gray-600 line-clamp-2">
                        {product.description}
                      </p>
                    )}
                  </div>

                  {/* أزرار الإجراءات */}
                  <div className="flex justify-center mt-4">
                    <Button 
                      variant="outline" 
                      onClick={() => handleEdit(product)}
                      className="w-full"
                    >
                      <Edit className="h-4 w-4 ml-2" />
                      تعديل
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* نافذة التعديل المباشرة */}
        {editingProduct && (
          <Dialog open={!!editingProduct} onOpenChange={() => setEditingProduct(null)}>
            <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>تعديل المنتج</DialogTitle>
              </DialogHeader>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-name">اسم المنتج *</Label>
                  <Input
                    id="edit-name"
                    value={editForm.name}
                    onChange={(e) => setEditForm(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="أدخل اسم المنتج"
                    className="text-right"
                  />
                </div>

                {/* تعديل الصورة */}
                <div className="space-y-2">
                  <Label>صورة المنتج</Label>
                  <div className="flex flex-col gap-3">
                    {editPreviewUrl && (
                      <div className="w-20 h-20 rounded-lg overflow-hidden border border-gray-200">
                        <img
                          src={editPreviewUrl}
                          alt="معاينة المنتج"
                          className="w-full h-full object-cover"
                        />
                      </div>
                    )}
                    <div className="flex items-center gap-2">
                      <Input
                        type="file"
                        accept="image/*"
                        onChange={handleEditImageChange}
                        className="hidden"
                        id="edit-image-upload"
                      />
                      <Label
                        htmlFor="edit-image-upload"
                        className="flex items-center gap-2 px-3 py-2 border border-gray-300 rounded-md cursor-pointer hover:bg-gray-50 text-sm"
                      >
                        <Upload className="w-4 h-4" />
                        {selectedEditImage ? 'تم اختيار صورة جديدة' : 'اختر صورة جديدة'}
                      </Label>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="edit-price" className="text-purple-600 font-semibold">
                      سعر الجملة *
                    </Label>
                    <Input
                      id="edit-price"
                      type="text"
                      value={editForm.price}
                      onChange={(e) => {
                        const value = e.target.value.replace(/[^\d.]/g, '');
                        setEditForm(prev => ({ ...prev, price: value }));
                      }}
                      placeholder="0"
                      className="text-purple-700 font-semibold text-left"
                      style={{ direction: 'ltr', fontFamily: 'monospace' }}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="edit-minPrice" className="text-blue-600 font-semibold">
                      الحد الأدنى *
                    </Label>
                    <Input
                      id="edit-minPrice"
                      type="text"
                      value={editForm.minPrice}
                      onChange={(e) => {
                        const value = e.target.value.replace(/[^\d.]/g, '');
                        setEditForm(prev => ({ ...prev, minPrice: value }));
                      }}
                      placeholder="0"
                      className="text-blue-700 font-semibold text-left"
                      style={{ direction: 'ltr', fontFamily: 'monospace' }}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="edit-maxPrice" className="text-green-600 font-semibold">
                      الحد الأعلى *
                    </Label>
                    <Input
                      id="edit-maxPrice"
                      type="text"
                      value={editForm.maxPrice}
                      onChange={(e) => {
                        const value = e.target.value.replace(/[^\d.]/g, '');
                        setEditForm(prev => ({ ...prev, maxPrice: value }));
                      }}
                      placeholder="0"
                      className="text-green-700 font-semibold text-left"
                      style={{ direction: 'ltr', fontFamily: 'monospace' }}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="edit-stock">الكمية</Label>
                  <Input
                    id="edit-stock"
                    type="text"
                    value={editForm.stock}
                    onChange={(e) => {
                      const value = e.target.value.replace(/[^\d]/g, '');
                      setEditForm(prev => ({ ...prev, stock: value }));
                    }}
                    placeholder="0"
                    className="text-left max-w-xs"
                    style={{ direction: 'ltr', fontFamily: 'monospace' }}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="edit-description">الوصف</Label>
                  <Input
                    id="edit-description"
                    value={editForm.description}
                    onChange={(e) => setEditForm(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="وصف المنتج..."
                    className="text-right"
                  />
                </div>

                {/* الصور الإضافية */}
                <div className="space-y-2">
                  <Label>الصور الإضافية (حتى صورتين)</Label>
                  <div className="space-y-3">
                    {/* عرض الصور الإضافية الحالية */}
                    {additionalPreviewUrls.length > 0 && (
                      <div className="flex gap-2 flex-wrap">
                        {additionalPreviewUrls.map((url, index) => (
                          <div key={index} className="relative w-16 h-16 rounded-lg overflow-hidden border border-gray-200">
                            <img
                              src={url}
                              alt={`صورة إضافية ${index + 1}`}
                              className="w-full h-full object-cover"
                            />
                            <button
                              onClick={() => removeAdditionalImage(index)}
                              className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white rounded-full text-xs flex items-center justify-center hover:bg-red-600"
                              type="button"
                            >
                              <X className="w-3 h-3" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                    
                    {/* رفع صور جديدة */}
                    {additionalPreviewUrls.length < 2 && (
                      <div className="flex items-center gap-2">
                        <Input
                          type="file"
                          accept="image/*"
                          multiple
                          onChange={handleAdditionalImagesChange}
                          className="hidden"
                          id="additional-images-upload"
                        />
                        <Label
                          htmlFor="additional-images-upload"
                          className="flex items-center gap-2 px-3 py-2 border border-gray-300 rounded-md cursor-pointer hover:bg-gray-50 text-sm"
                        >
                          <Upload className="w-4 h-4" />
                          {selectedAdditionalImages.length > 0 ? 
                            `تم اختيار ${selectedAdditionalImages.length} صورة` : 
                            'اختر صور إضافية (حتى 2)'
                          }
                        </Label>
                      </div>
                    )}
                  </div>
                </div>

                {/* الفئة */}
                <div className="space-y-2">
                  <Label htmlFor="edit-categoryId">الفئة</Label>
                  <Select 
                    value={editForm.categoryId?.toString() || ''} 
                    onValueChange={(value) => {
                      console.log('تم اختيار الفئة:', value);
                      setEditForm(prev => ({ ...prev, categoryId: value }));
                    }}
                  >
                    <SelectTrigger className="text-right">
                      <SelectValue placeholder="اختر الفئة" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories?.map((category: any) => (
                        <SelectItem key={category.id} value={category.categoryId?.toString() || category.id.toString()}>
                          {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex gap-3 pt-4">
                  <Button
                    onClick={handleSave}
                    disabled={updateProductMutation.isPending}
                    className="flex-1"
                  >
                    <Save className="h-4 w-4 ml-2" />
                    {updateProductMutation.isPending ? 'جاري الحفظ...' : 'حفظ التعديلات'}
                  </Button>
                  
                  <Button
                    variant="outline"
                    onClick={() => setEditingProduct(null)}
                    disabled={updateProductMutation.isPending}
                  >
                    <X className="h-4 w-4 ml-2" />
                    إلغاء
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </div>
  );
}