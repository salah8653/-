import { useState, useRef } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { ArrowRight, Camera, User, Phone, Mail, MapPin, Upload, AlertTriangle, X } from "lucide-react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";

const editProfileSchema = z.object({
  fullName: z.string().min(1, 'الاسم الكامل مطلوب'),
  address: z.string().optional(),
});

type EditProfileFormData = z.infer<typeof editProfileSchema>;

export const EditProfilePage = () => {
  const [, setLocation] = useLocation();
  const { user, updateUser } = useAuth();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [profileImage, setProfileImage] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [showWarning, setShowWarning] = useState(true);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const form = useForm<EditProfileFormData>({
    resolver: zodResolver(editProfileSchema),
    defaultValues: {
      fullName: user?.fullName || '',
      address: user?.address || '',
    },
  });

  const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB
        toast({
          title: "حجم الصورة كبير",
          description: "يجب أن يكون حجم الصورة أقل من 5 ميجابايت",
          variant: "destructive",
        });
        return;
      }

      setImageFile(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        setProfileImage(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const onSubmit = async (data: EditProfileFormData) => {
    setIsLoading(true);
    try {
      let imageUrl = profileImage;

      // رفع الصورة إذا تم اختيار صورة جديدة
      if (imageFile) {
        const formData = new FormData();
        formData.append('file', imageFile);
        
        const uploadResponse = await fetch('/api/upload', {
          method: 'POST',
          body: formData,
        });
        
        if (uploadResponse.ok) {
          const uploadResult = await uploadResponse.json();
          imageUrl = uploadResult.url;
        }
      }

      // تحديث بيانات المستخدم
      await apiRequest('PUT', `/api/users/${user?.id}`, {
        ...data,
        profileImage: imageUrl,
      });

      // تحديث البيانات محلياً
      updateUser({
        fullName: data.fullName,
        phone: user?.phone, // الحفاظ على رقم الهاتف الحالي
        email: user?.email, // الحفاظ على البريد الإلكتروني الحالي
        address: data.address || undefined,
        profileImage: imageUrl || undefined,
      });

      toast({
        title: "تم تحديث الملف الشخصي",
        description: "تم حفظ تغييراتك بنجاح",
      });

      setLocation("/profile");
    } catch (error) {
      console.error('خطأ في تحديث الملف الشخصي:', error);
      toast({
        title: "خطأ في التحديث",
        description: "حدث خطأ أثناء تحديث الملف الشخصي",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="p-4 flex items-center gap-3">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => setLocation("/profile")}
          >
            <ArrowRight className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-bold">تعديل الملف الشخصي</h1>
        </div>
      </div>

      <div className="p-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-center">معلوماتي الشخصية</CardTitle>
          </CardHeader>
          <CardContent>
            {/* صورة الملف الشخصي */}
            <div className="flex flex-col items-center mb-6">
              <div className="relative">
                <div className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center overflow-hidden">
                  {profileImage ? (
                    <img 
                      src={profileImage} 
                      alt="الصورة الشخصية" 
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <User className="h-12 w-12 text-gray-400" />
                  )}
                </div>
                <Button
                  type="button"
                  size="icon"
                  className="absolute -bottom-2 -right-2 rounded-full w-8 h-8 bg-purple-600 hover:bg-purple-700"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Camera className="h-4 w-4" />
                </Button>
              </div>
              
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                className="hidden"
              />
              
              <p className="text-sm text-gray-500 text-center mt-2">
                اضغط على الكاميرا لتغيير الصورة
              </p>
            </div>

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="fullName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center gap-2">
                        <User className="w-4 h-4" />
                        الاسم الكامل
                      </FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="أدخل اسمك الكامل"
                          {...field}
                          className="h-11"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* حقل رقم الهاتف للعرض فقط */}
                <div className="space-y-2">
                  <label className="flex items-center gap-2 text-sm font-medium">
                    <Phone className="w-4 h-4" />
                    رقم الهاتف
                  </label>
                  <Input 
                    value={user?.phone || ''}
                    disabled
                    className="h-11 bg-gray-100 text-gray-600 cursor-not-allowed"
                    placeholder="رقم الهاتف غير قابل للتعديل"
                  />
                  <p className="text-xs text-gray-500">
                    رقم الهاتف لا يمكن تغييره لحماية الحساب
                  </p>
                </div>

                {/* حقل البريد الإلكتروني للعرض فقط */}
                <div className="space-y-2">
                  <label className="flex items-center gap-2 text-sm font-medium">
                    <Mail className="w-4 h-4" />
                    البريد الإلكتروني
                  </label>
                  <Input 
                    value={user?.email || ''}
                    disabled
                    className="h-11 bg-gray-100 text-gray-600 cursor-not-allowed"
                    placeholder="البريد الإلكتروني غير قابل للتعديل"
                  />
                  <p className="text-xs text-gray-500">
                    البريد الإلكتروني لا يمكن تغييره لحماية الحساب
                  </p>
                </div>

                <FormField
                  control={form.control}
                  name="address"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center gap-2">
                        <MapPin className="w-4 h-4" />
                        العنوان
                      </FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="العنوان (اختياري)"
                          {...field}
                          className="h-11"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex gap-3 pt-4">
                  <Button
                    type="submit"
                    disabled={isLoading}
                    className="flex-1 bg-purple-600 hover:bg-purple-700"
                  >
                    {isLoading ? (
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        جاري الحفظ...
                      </div>
                    ) : (
                      "حفظ التغييرات"
                    )}
                  </Button>
                  
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setLocation("/profile")}
                    className="flex-1"
                  >
                    إلغاء
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};