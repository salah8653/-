import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { 
  ArrowRight, 
  ArrowLeft,
  Package, 
  Grid3X3,
  ShoppingBag,
  Eye,
  Heart,
  ShoppingCart
} from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { BottomNavigation } from "@/components/BottomNavigation";

export const CategoriesPage = () => {
  const [, setLocation] = useLocation();
  const { language, dir } = useLanguage();
  const [expandedCategory, setExpandedCategory] = useState<number | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: products = [], isLoading: productsLoading } = useQuery({
    queryKey: ["/api/products"],
  });

  const { data: categories = [], isLoading: categoriesLoading } = useQuery({
    queryKey: ["/api/categories"],
  });

  // إضافة المنتج إلى السلة مباشرة من صفحة الفئات
  const addToCartMutation = useMutation({
    mutationFn: async (productId: number) => {
      const response = await fetch('/api/cart', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ productId, quantity: 1 }),
      });
      if (!response.ok) throw new Error('فشل في إضافة المنتج');
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: language === 'ar' ? "تم إضافة المنتج" : "Product Added",
        description: language === 'ar' ? "تم إضافة المنتج إلى السلة بنجاح" : "Product added to cart successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
      // لا نقوم بالتوجه للسلة من الواجهة الخارجية
    },
    onError: () => {
      toast({
        title: language === 'ar' ? "خطأ" : "Error",
        description: language === 'ar' ? "فشل في إضافة المنتج إلى السلة" : "Failed to add product to cart",
        variant: "destructive",
      });
    },
  });

  // ترجمة الفئات
  const translateCategory = (category: string) => {
    const translations: { [key: string]: string } = {
      'منتجات مطبخ': language === 'ar' ? 'منتجات مطبخ' : 'Kitchen Products',
      'إلكترونيات': language === 'ar' ? 'إلكترونيات' : 'Electronics',
      'ملابس': language === 'ar' ? 'ملابس' : 'Clothing',
      'كتب': language === 'ar' ? 'كتب' : 'Books',
      'رياضة': language === 'ar' ? 'رياضة' : 'Sports',
      'جمال': language === 'ar' ? 'جمال' : 'Beauty',
      'صحة': language === 'ar' ? 'صحة' : 'Health',
      'طعام': language === 'ar' ? 'طعام' : 'Food',
      'مشروبات': language === 'ar' ? 'مشروبات' : 'Drinks'
    };
    return translations[category] || category;
  };

  // تجميع المنتجات حسب الفئة
  const getProductsByCategory = (categoryName: string) => {
    return (products as any[]).filter(product => product.category?.name === categoryName);
  };

  // عد المنتجات في كل فئة
  const getCategoryProductCount = (categoryName: string) => {
    return getProductsByCategory(categoryName).length;
  };

  if (productsLoading || categoriesLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
        <BottomNavigation />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50" dir={dir}>
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => setLocation("/")}
            >
              {dir === 'rtl' ? (
                <ArrowRight className="h-5 w-5" />
              ) : (
                <ArrowLeft className="h-5 w-5" />
              )}
            </Button>
            <Grid3X3 className="h-6 w-6 text-purple-600" />
            <h1 className="text-xl font-bold text-gray-900">
              {language === 'ar' ? 'جميع الفئات' : 'All Categories'}
            </h1>
          </div>
          <Badge variant="secondary" className="bg-purple-100 text-purple-800">
            {(categories as any[]).length} {language === 'ar' ? 'فئة' : 'Categories'}
          </Badge>
        </div>
      </div>

      {/* Categories List */}
      <div className="p-4 space-y-4 pb-20">
        {(categories as any[]).length === 0 ? (
          <div className="text-center py-12">
            <Grid3X3 className="h-16 w-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">
              {language === 'ar' ? 'لا توجد فئات متاحة' : 'No categories available'}
            </p>
          </div>
        ) : (
          (categories as any[]).map((category: any) => {
            const categoryProducts = getProductsByCategory(category.name);
            const isExpanded = expandedCategory === category.id;
            
            return (
              <Card key={category.id} className="border border-gray-200 shadow-sm">
                <CardHeader 
                  className="cursor-pointer hover:bg-gray-50 transition-colors"
                  onClick={() => setExpandedCategory(isExpanded ? null : category.id)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                        <Grid3X3 className="h-6 w-6 text-purple-600" />
                      </div>
                      <div>
                        <CardTitle className="text-lg text-gray-900">
                          {translateCategory(category.name)}
                        </CardTitle>
                        <p className="text-sm text-gray-500">
                          {getCategoryProductCount(category.name)} {language === 'ar' ? 'منتج' : 'products'}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="bg-purple-50 text-purple-700">
                        {getCategoryProductCount(category.name)}
                      </Badge>
                      <Button variant="ghost" size="sm">
                        <Eye className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>

                {/* Products in Category */}
                {isExpanded && (
                  <CardContent className="pt-0">
                    <div className="border-t border-gray-100 pt-4">
                      {categoryProducts.length === 0 ? (
                        <div className="text-center py-8">
                          <Package className="h-12 w-12 text-gray-300 mx-auto mb-3" />
                          <p className="text-gray-500 text-sm">
                            {language === 'ar' ? 'لا توجد منتجات في هذه الفئة' : 'No products in this category'}
                          </p>
                        </div>
                      ) : (
                        <div className="grid grid-cols-2 gap-3">
                          {categoryProducts.map((product: any) => (
                            <Card 
                              key={product.id}
                              className="border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer bg-gray-50"
                              onClick={() => setLocation(`/product/${product.id}`)}
                            >
                              <CardContent className="p-3">
                                <div className="relative">
                                  {product.imageUrl ? (
                                    <img 
                                      src={product.imageUrl} 
                                      alt={product.name}
                                      className="w-full h-24 object-cover rounded-lg mb-3"
                                    />
                                  ) : (
                                    <div className="w-full h-24 bg-gray-200 rounded-lg mb-3 flex items-center justify-center">
                                      <Package className="h-6 w-6 text-gray-400" />
                                    </div>
                                  )}
                                  
                                  {/* Heart Icon */}
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="absolute top-1 right-1 h-6 w-6 p-0 bg-white/80 hover:bg-white text-gray-600 hover:text-red-500"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                    }}
                                  >
                                    <Heart className="h-3 w-3" />
                                  </Button>
                                </div>

                                <h4 className="font-semibold text-xs text-gray-800 mb-1 line-clamp-2">
                                  {product.name}
                                </h4>
                                
                                <div className="space-y-2">
                                  <div className="flex items-center justify-between">
                                    <span className="text-sm font-bold text-purple-600">
                                      {parseFloat(product.price).toLocaleString()} د.ع
                                    </span>
                                    <span className="text-xs text-gray-500">
                                      {product.stock} {language === 'ar' ? 'متوفر' : 'available'}
                                    </span>
                                  </div>
                                  
                                  {/* زر إضافة إلى السلة */}
                                  <Button
                                    size="sm"
                                    className="w-full bg-purple-600 hover:bg-purple-700 text-white text-xs py-1"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      addToCartMutation.mutate(product.id);
                                    }}
                                    disabled={product.stock === 0 || addToCartMutation.isPending}
                                  >
                                    <ShoppingCart className={`h-3 w-3 ${language === 'ar' ? 'ml-1' : 'mr-1'}`} />
                                    {language === 'ar' ? 'إضافة للسلة' : 'Add to Cart'}
                                  </Button>
                                </div>
                              </CardContent>
                            </Card>
                          ))}
                        </div>
                      )}
                      
                      {/* View All Products in Category Button */}
                      {categoryProducts.length > 0 && (
                        <div className="mt-4 text-center">
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="w-full"
                            onClick={() => {
                              // Navigate to store with category filter
                              setLocation(`/?category=${encodeURIComponent(category.name)}`);
                            }}
                          >
                            <ShoppingBag className="h-4 w-4 mr-2" />
                            {language === 'ar' ? 'عرض جميع المنتجات' : 'View All Products'}
                          </Button>
                        </div>
                      )}
                    </div>
                  </CardContent>
                )}
              </Card>
            );
          })
        )}
      </div>

      <BottomNavigation />
    </div>
  );
};