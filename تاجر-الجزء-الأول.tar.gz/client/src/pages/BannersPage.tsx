import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Plus, 
  Edit, 
  Trash2, 
  Image, 
  Eye, 
  EyeOff,
  Save,
  X,
  Upload
} from "lucide-react";

interface Banner {
  id: number;
  title: string;
  description?: string;
  imageUrl?: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

interface BannerFormData {
  title: string;
  description: string;
  isActive: boolean;
  imageUrl: string;
}

export function BannersPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState<BannerFormData>({
    title: '',
    description: '',
    isActive: true,
    imageUrl: ''
  });
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadingImage, setUploadingImage] = useState(false);

  // جلب البانرات
  const { data: bannersData, isLoading } = useQuery({
    queryKey: ["/api/banners"],
  });

  const banners = (bannersData as Banner[]) || [];

  // دالة تحميل الصورة وتحويلها إلى base64
  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.type.startsWith('image/')) {
        setSelectedFile(file);
        setUploadingImage(true);
        
        const reader = new FileReader();
        reader.onload = (e) => {
          const result = e.target?.result as string;
          setFormData(prev => ({ ...prev, imageUrl: result }));
          setUploadingImage(false);
        };
        reader.readAsDataURL(file);
      } else {
        toast({
          title: "خطأ في نوع الملف",
          description: "يرجى اختيار ملف صورة فقط",
          variant: "destructive",
        });
      }
    }
  };

  // إنشاء بانر جديد
  const createMutation = useMutation({
    mutationFn: async (data: Omit<BannerFormData, 'id'>) => {
      const response = await apiRequest("POST", "/api/banners", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم إنشاء البانر بنجاح",
        description: "تم إضافة البانر الجديد",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/banners"] });
      resetForm();
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "فشل في إنشاء البانر",
        variant: "destructive",
      });
    },
  });

  // تحديث بانر
  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<BannerFormData> }) => {
      const response = await apiRequest("PUT", `/api/banners/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم تحديث البانر بنجاح",
        description: "تم حفظ التغييرات",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/banners"] });
      resetForm();
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "فشل في تحديث البانر",
        variant: "destructive",
      });
    },
  });

  // حذف بانر
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/banners/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "تم حذف البانر",
        description: "تم حذف البانر بنجاح",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/banners"] });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "فشل في حذف البانر",
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setFormData({
      title: '',
      description: '',
      isActive: true,
      imageUrl: ''
    });
    setSelectedFile(null);
    setUploadingImage(false);
    setEditingId(null);
    setIsFormOpen(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title.trim()) {
      toast({
        title: "خطأ",
        description: "يرجى إدخال عنوان البانر",
        variant: "destructive",
      });
      return;
    }

    if (editingId) {
      updateMutation.mutate({ id: editingId, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleEdit = (banner: Banner) => {
    setFormData({
      title: banner.title,
      description: banner.description || '',
      isActive: banner.isActive,
      imageUrl: banner.imageUrl || ''
    });
    setEditingId(banner.id);
    setIsFormOpen(true);
  };

  const handleDelete = (id: number) => {
    if (confirm('هل أنت متأكد من حذف هذا البانر؟')) {
      deleteMutation.mutate(id);
    }
  };

  const toggleBannerStatus = (banner: Banner) => {
    updateMutation.mutate({
      id: banner.id,
      data: { ...banner, isActive: !banner.isActive }
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">إدارة البانرات</h1>
        <Button
          onClick={() => setIsFormOpen(true)}
          className="flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          إضافة بانر جديد
        </Button>
      </div>

      {/* نموذج إضافة/تحديث البانر */}
      {isFormOpen && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>{editingId ? 'تحديث البانر' : 'إضافة بانر جديد'}</span>
              <Button
                variant="ghost"
                size="sm"
                onClick={resetForm}
              >
                <X className="w-4 h-4" />
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="title">عنوان البانر *</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="عنوان البانر"
                    required
                  />
                </div>
                <div>
                  <Label>صورة البانر</Label>
                  <div className="space-y-3">
                    {/* زر تحميل الصورة */}
                    <div>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleFileSelect}
                        className="hidden"
                        id="imageFile"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => document.getElementById('imageFile')?.click()}
                        disabled={uploadingImage}
                        className="w-full flex items-center gap-2"
                      >
                        <Upload className="w-4 h-4" />
                        {uploadingImage ? 'جاري تحميل الصورة...' : 'تحميل صورة من الجهاز'}
                      </Button>
                    </div>
                    
                    {/* أو رابط الصورة */}
                    <div className="relative">
                      <div className="absolute inset-0 flex items-center">
                        <span className="w-full border-t" />
                      </div>
                      <div className="relative flex justify-center text-xs uppercase">
                        <span className="bg-background px-2 text-muted-foreground">أو</span>
                      </div>
                    </div>
                    
                    <Input
                      id="imageUrl"
                      value={formData.imageUrl.startsWith('data:') ? '' : formData.imageUrl}
                      onChange={(e) => setFormData({ ...formData, imageUrl: e.target.value })}
                      placeholder="https://example.com/image.jpg"
                      disabled={uploadingImage}
                    />
                  </div>
                  
                  {/* معاينة الصورة */}
                  {formData.imageUrl && (
                    <div className="mt-3">
                      <img
                        src={formData.imageUrl}
                        alt="معاينة البانر"
                        className="w-full h-32 object-cover rounded-lg border"
                      />
                    </div>
                  )}
                </div>
              </div>

              <div>
                <Label htmlFor="description">وصف البانر</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="وصف البانر"
                  rows={3}
                />
              </div>

              <div className="flex items-center space-x-2 space-x-reverse">
                <Switch
                  checked={formData.isActive}
                  onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked })}
                />
                <Label>البانر نشط</Label>
              </div>

              <div className="flex gap-2">
                <Button 
                  type="submit" 
                  disabled={createMutation.isPending || updateMutation.isPending}
                  className="flex items-center gap-2"
                >
                  <Save className="w-4 h-4" />
                  {editingId ? 'تحديث البانر' : 'إضافة البانر'}
                </Button>
                <Button type="button" variant="outline" onClick={resetForm}>
                  إلغاء
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* قائمة البانرات */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Image className="w-5 h-5" />
            البانرات المتوفرة ({banners.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {banners.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <Image className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>لا توجد بانرات متوفرة</p>
              <p className="text-sm">قم بإضافة بانر جديد لعرضه للعملاء</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {banners.map((banner) => (
                <div key={banner.id} className="border rounded-lg p-4 space-y-3">
                  {/* صورة البانر */}
                  <div className="aspect-video bg-gray-100 rounded-lg overflow-hidden">
                    {banner.imageUrl ? (
                      <img
                        src={banner.imageUrl}
                        alt={banner.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-gray-400">
                        <span>لا توجد صورة</span>
                      </div>
                    )}
                  </div>
                  
                  {/* معلومات البانر */}
                  <div>
                    <h3 className="font-semibold text-lg">{banner.title}</h3>
                    {banner.description && (
                      <p className="text-gray-600 text-sm mt-1">{banner.description}</p>
                    )}
                  </div>

                  {/* حالة البانر */}
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${banner.isActive ? 'bg-green-500' : 'bg-gray-400'}`} />
                    <span className="text-sm text-gray-600">
                      {banner.isActive ? 'نشط' : 'غير نشط'}
                    </span>
                  </div>

                  {/* أزرار التحكم */}
                  <div className="flex gap-2 pt-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleEdit(banner)}
                      className="flex items-center gap-1"
                    >
                      <Edit className="w-3 h-3" />
                      تحرير
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => toggleBannerStatus(banner)}
                      className="flex items-center gap-1"
                    >
                      {banner.isActive ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                      {banner.isActive ? 'إخفاء' : 'إظهار'}
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleDelete(banner.id)}
                      className="flex items-center gap-1"
                    >
                      <Trash2 className="w-3 h-3" />
                      حذف
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}