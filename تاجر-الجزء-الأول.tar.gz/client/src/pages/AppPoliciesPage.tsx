import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  ArrowRight,
  Truck,
  RotateCcw,
  FileText,
  Info,
  HelpCircle,
  Phone,
  MapPin,
  Building,
  ChevronDown,
  ChevronUp
} from "lucide-react";
import { useLocation } from "wouter";

export const AppPoliciesPage = () => {
  const [, setLocation] = useLocation();
  const [expandedSection, setExpandedSection] = useState<string | null>(null);

  // جلب سياسات التطبيق
  const { data: policies, isLoading } = useQuery({
    queryKey: ['/api/app-policies'],
  });

  const toggleSection = (section: string) => {
    setExpandedSection(expandedSection === section ? null : section);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center" dir="rtl">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-600">جاري تحميل السياسات...</p>
        </div>
      </div>
    );
  }

  const policyItems = [
    {
      id: 'delivery',
      icon: Truck,
      title: 'سياسة التوصيل',
      subtitle: 'أسعار ومواعيد التوصيل',
      data: policies?.delivery
    },
    {
      id: 'return',
      icon: RotateCcw,
      title: 'سياسة الاستبدال',
      subtitle: 'شروط وأحكام الاستبدال',
      data: policies?.returnPolicy
    },
    {
      id: 'terms',
      icon: FileText,
      title: 'الشروط والأحكام',
      subtitle: 'الشروط القانونية للاستخدام',
      data: policies?.termsAndConditions
    },
    {
      id: 'app',
      icon: Info,
      title: 'حول التطبيق',
      subtitle: 'معلومات عن التطبيق والمطور',
      data: policies?.appInfo
    },
    {
      id: 'faq',
      icon: HelpCircle,
      title: 'الأسئلة الشائعة',
      subtitle: 'إجابات على الأسئلة المتكررة',
      data: policies?.faq
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      {/* Header */}
      <div className="bg-white shadow-sm sticky top-0 z-10">
        <div className="p-4 flex items-center gap-3">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => setLocation("/profile")}
          >
            <ArrowRight className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-bold">سياسة التطبيق</h1>
        </div>
      </div>

      <div className="p-4 space-y-4">
        {/* نظرة عامة */}
        <Card className="bg-gradient-to-r from-purple-600 to-purple-800 text-white border-0">
          <CardContent className="p-6">
            <div className="flex items-center gap-3 mb-3">
              <FileText className="h-6 w-6" />
              <h2 className="text-xl font-bold">مرحباً بك في تاجر</h2>
            </div>
            <p className="text-purple-100 leading-relaxed">
              منصة تجارة إلكترونية متقدمة مصممة لخدمة السوق العراقي بأفضل الحلول والخدمات
            </p>
          </CardContent>
        </Card>

        {/* قائمة السياسات */}
        {policyItems.map((item) => (
          <Card key={item.id} className="border border-gray-200">
            <CardHeader 
              className="cursor-pointer hover:bg-gray-50 transition-colors"
              onClick={() => toggleSection(item.id)}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-purple-100 rounded-lg">
                    <item.icon className="h-5 w-5 text-purple-600" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">{item.title}</CardTitle>
                    <p className="text-sm text-gray-600 mt-1">{item.subtitle}</p>
                  </div>
                </div>
                {expandedSection === item.id ? (
                  <ChevronUp className="h-5 w-5 text-gray-400" />
                ) : (
                  <ChevronDown className="h-5 w-5 text-gray-400" />
                )}
              </div>
            </CardHeader>

            {expandedSection === item.id && (
              <CardContent className="pt-0">
                <Separator className="mb-4" />
                <ScrollArea className="max-h-96">
                  {item.id === 'delivery' && item.data && (
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="bg-blue-50 p-3 rounded-lg">
                          <p className="text-sm font-medium text-blue-800">بغداد</p>
                          <p className="text-xl font-bold text-blue-600">{item.data.baghdadPrice} د.ع</p>
                        </div>
                        <div className="bg-green-50 p-3 rounded-lg">
                          <p className="text-sm font-medium text-green-800">المحافظات</p>
                          <p className="text-xl font-bold text-green-600">{item.data.provincesPrice} د.ع</p>
                        </div>
                      </div>
                      <div className="bg-gray-50 p-3 rounded-lg">
                        <p className="text-sm font-medium text-gray-800">مدة التوصيل</p>
                        <p className="text-gray-600">{item.data.estimatedTime}</p>
                        <p className="text-sm text-gray-500 mt-1">{item.data.description}</p>
                      </div>
                    </div>
                  )}

                  {item.id === 'return' && item.data && (
                    <div className="space-y-3">
                      <h4 className="font-semibold text-gray-800 mb-3">{item.data.title}</h4>
                      {item.data.rules.map((rule: string, index: number) => (
                        <div key={index} className="flex items-start gap-2">
                          <Badge variant="outline" className="mt-1 text-xs">
                            {index + 1}
                          </Badge>
                          <p className="text-gray-700 text-sm leading-relaxed">{rule}</p>
                        </div>
                      ))}
                    </div>
                  )}

                  {item.id === 'terms' && item.data && (
                    <div className="space-y-4">
                      {item.data.sections.map((section: any, index: number) => (
                        <div key={index} className="border-l-4 border-purple-200 pl-4">
                          <h4 className="font-semibold text-gray-800 mb-2">{section.title}</h4>
                          <div className="space-y-2">
                            {section.content.map((item: string, itemIndex: number) => (
                              <p key={itemIndex} className="text-gray-600 text-sm leading-relaxed">
                                • {item}
                              </p>
                            ))}
                          </div>
                        </div>
                      ))}
                      
                      {item.data.contact && (
                        <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
                          <h4 className="font-semibold text-blue-800 mb-3 flex items-center gap-2">
                            <Phone className="h-4 w-4" />
                            معلومات التواصل
                          </h4>
                          <div className="space-y-2 text-sm">
                            <div className="flex items-center gap-2">
                              <Building className="h-4 w-4 text-blue-600" />
                              <span className="text-blue-700">{item.data.contact.company}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <MapPin className="h-4 w-4 text-blue-600" />
                              <span className="text-blue-700">{item.data.contact.location}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Phone className="h-4 w-4 text-blue-600" />
                              <span className="text-blue-700">{item.data.contact.phone}</span>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {item.id === 'app' && item.data && (
                    <div className="space-y-4">
                      <div className="text-center p-4 bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg">
                        <h4 className="font-bold text-purple-800 mb-2">{item.data.title}</h4>
                        <p className="text-purple-600 mb-3">{item.data.description}</p>
                        <div className="bg-white p-3 rounded-lg border border-purple-200">
                          <p className="text-sm font-medium text-purple-800 mb-1">المطور</p>
                          <p className="text-purple-600">{item.data.creator}</p>
                        </div>
                      </div>
                      
                      <div>
                        <h5 className="font-semibold text-gray-800 mb-3">ميزات التطبيق</h5>
                        <div className="grid grid-cols-2 gap-2">
                          {item.data.features.map((feature: string, index: number) => (
                            <div key={index} className="bg-gray-50 p-2 rounded-lg">
                              <p className="text-sm text-gray-700">• {feature}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}

                  {item.id === 'faq' && item.data && (
                    <div className="space-y-3">
                      {item.data.slice(0, 10).map((faq: any, index: number) => (
                        <div key={index} className="border border-gray-200 rounded-lg p-3">
                          <h5 className="font-medium text-gray-800 mb-2">{faq.question}</h5>
                          <p className="text-gray-600 text-sm leading-relaxed">{faq.answer}</p>
                        </div>
                      ))}
                      
                      {item.data.length > 10 && (
                        <div className="text-center p-4 bg-gray-50 rounded-lg">
                          <p className="text-gray-600 mb-3">
                            عرض {item.data.length - 10} سؤال إضافي
                          </p>
                          <Button 
                            variant="outline" 
                            onClick={() => setLocation("/ecommerce-assistant")}
                            className="text-purple-600 border-purple-200 hover:bg-purple-50"
                          >
                            استخدم المساعد الذكي للمزيد
                          </Button>
                        </div>
                      )}
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            )}
          </Card>
        ))}

        {/* معلومات إضافية */}
        <Card className="border-2 border-dashed border-gray-300 bg-gray-50">
          <CardContent className="p-6 text-center">
            <HelpCircle className="h-12 w-12 text-gray-400 mx-auto mb-3" />
            <h3 className="font-semibold text-gray-800 mb-2">هل تحتاج لمساعدة إضافية؟</h3>
            <p className="text-gray-600 mb-4">
              يمكنك استخدام المساعد الذكي للحصول على إجابات مفصلة
            </p>
            <Button 
              onClick={() => setLocation("/ecommerce-assistant")}
              className="bg-purple-600 hover:bg-purple-700"
            >
              تجربة المساعد الذكي
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};