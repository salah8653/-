import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { 
  MessageCircle, 
  Send, 
  User, 
  Clock,
  CheckCheck,
  AlertCircle,
  Search,
  Bot
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'support';
  timestamp: Date;
  status?: 'sent' | 'delivered' | 'read';
}

interface CustomerChat {
  customerId: number;
  customerName: string;
  customerPhone: string;
  messages: Message[];
  lastMessageTime: Date;
  unreadCount: number;
  isActive: boolean;
}

export const AdminSupportPage = () => {
  const { user } = useAuth();
  const [customerChats, setCustomerChats] = useState<CustomerChat[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState<CustomerChat | null>(null);
  const [newMessage, setNewMessage] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  // جلب بيانات المستخدمين من قاعدة البيانات
  const { data: users = [] } = useQuery({
    queryKey: ['/api/users'],
    select: (data: any[]) => data.filter(u => u.role === 'customer')
  });

  // تحميل محادثات العملاء من Firebase والـ localStorage
  const loadCustomerChats = async () => {
    try {
      // جلب الرسائل من Firebase
      const response = await fetch('/api/support-messages');
      const allChats: CustomerChat[] = [];
      
      if (response.ok) {
        const supportMessages = await response.json();
        console.log('📥 تم جلب رسائل الدعم من Firebase:', supportMessages.length);
        
        // تجميع الرسائل حسب العميل
        const chatsMap = new Map<string, CustomerChat>();
        
        supportMessages.forEach((message: any) => {
          const customerPhone = message.customerPhone;
          const customerId = message.customerId;
          
          // تخطي الرسائل المحذوفة من المدير فقط
          if (message.isDeletedByAdmin) return;
          
          if (!chatsMap.has(customerPhone)) {
            const user = users?.find((u: any) => u.phone === customerPhone || u.id === customerId);
            
            chatsMap.set(customerPhone, {
              customerId: customerId || user?.id || 0,
              customerName: message.customerName || user?.fullName || `عميل ${customerPhone}`,
              customerPhone: customerPhone,
              messages: [],
              lastMessageTime: new Date(message.createdAt),
              unreadCount: 0,
              isActive: true
            });
          }
          
          const chat = chatsMap.get(customerPhone)!;
          chat.messages.push({
            id: message.id,
            text: message.message,
            sender: message.isAdminReply ? 'support' : 'user',
            timestamp: new Date(message.createdAt),
            status: message.isReadByAdmin ? 'read' : 'delivered'
          });
          
          if (!message.isAdminReply && !message.isReadByAdmin) {
            chat.unreadCount++;
          }
        });
        
        // إضافة المحادثات من Firebase
        chatsMap.forEach(chat => {
          if (chat.messages.length > 0) {
            chat.messages.sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
            chat.lastMessageTime = chat.messages[chat.messages.length - 1].timestamp;
            allChats.push(chat);
          }
        });
      }
      
      // إضافة المحادثات من localStorage (للتوافق مع النظام القديم)
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith('support_chat_')) {
          try {
            const customerId = parseInt(key.replace('support_chat_', ''));
            const chatData = localStorage.getItem(key);
            
            if (chatData) {
              const messages = JSON.parse(chatData).map((msg: any) => ({
                ...msg,
                timestamp: new Date(msg.timestamp)
              }));

              if (messages.length === 0) continue;

              // تحقق من عدم وجود المحادثة مسبقاً من Firebase
              const existingChat = allChats.find(chat => chat.customerId === customerId);
              if (existingChat) continue;

              const customerData = users.find((u: any) => u.id === customerId);
              const unreadCount = messages.filter((msg: Message) => 
                msg.sender === 'user' && msg.status !== 'read'
              ).length;

              const lastMessage = messages[messages.length - 1];
              
              allChats.push({
                customerId,
                customerName: customerData?.fullName || customerData?.phone || `عميل ${customerId}`,
                customerPhone: customerData?.phone || 'غير محدد',
                messages,
                lastMessageTime: lastMessage?.timestamp || new Date(),
                unreadCount,
                isActive: true
              });
            }
          } catch (error) {
            console.error('خطأ في تحميل محادثة من localStorage:', error);
          }
        }
      }

      // ترتيب المحادثات حسب آخر رسالة
      allChats.sort((a, b) => b.lastMessageTime.getTime() - a.lastMessageTime.getTime());
      setCustomerChats(allChats);
      
    } catch (error) {
      console.error('❌ خطأ في تحميل رسائل الدعم:', error);
    }
  };

  // إرسال رد من المدير
  const sendAdminReply = async () => {
    if (!newMessage.trim() || !selectedCustomer) return;

    try {
      // إرسال الرسالة إلى Firebase
      const response = await fetch('/api/support-messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          customerPhone: selectedCustomer.customerPhone,
          customerName: selectedCustomer.customerName,
          message: newMessage.trim(),
          isAdminReply: true,
          customerId: selectedCustomer.customerId
        })
      });

      if (response.ok) {
        const savedMessage = await response.json();
        
        const adminMessage: Message = {
          id: savedMessage.id || Date.now().toString(),
          text: newMessage.trim(),
          sender: 'support',
          timestamp: new Date(),
          status: 'delivered'
        };

        // تحديث المحادثة المحلية
        const updatedMessages = [...selectedCustomer.messages, adminMessage];
        
        // حفظ في localStorage أيضاً
        localStorage.setItem(
          `support_chat_${selectedCustomer.customerId}`, 
          JSON.stringify(updatedMessages)
        );

        // تحديث الحالة
        setSelectedCustomer({
          ...selectedCustomer,
          messages: updatedMessages,
          lastMessageTime: new Date()
        });

        // تحديث قائمة المحادثات
        setCustomerChats(prev => prev.map(chat => 
          chat.customerId === selectedCustomer.customerId 
            ? {
                ...chat,
                messages: updatedMessages,
                lastMessageTime: new Date()
              }
            : chat
        ));

        setNewMessage('');
        console.log('✅ تم إرسال الرد بنجاح');
      } else {
        console.error('❌ فشل في إرسال الرد');
        alert('فشل في إرسال الرد. يرجى المحاولة لاحقاً.');
      }
    } catch (error) {
      console.error('❌ خطأ في إرسال الرد:', error);
      alert('حدث خطأ أثناء إرسال الرد.');
    }
  };

  // تحديد المحادثة كمقروءة
  const markAsRead = async (customerId: number) => {
    const chatKey = `support_chat_${customerId}`;
    const chatData = localStorage.getItem(chatKey);
    
    if (chatData) {
      try {
        const messages = JSON.parse(chatData).map((msg: any) => ({
          ...msg,
          timestamp: new Date(msg.timestamp),
          status: msg.sender === 'user' ? 'read' : msg.status
        }));

        localStorage.setItem(chatKey, JSON.stringify(messages));
        
        // تحديث المحادثة المحددة
        if (selectedCustomer && selectedCustomer.customerId === customerId) {
          setSelectedCustomer({
            ...selectedCustomer,
            messages
          });
        }

        // تحديث قائمة المحادثات
        setCustomerChats(prev => prev.map(chat => 
          chat.customerId === customerId 
            ? { ...chat, messages, unreadCount: 0 }
            : chat
        ));
      } catch (error) {
        console.error('خطأ في تحديث حالة القراءة:', error);
      }
    }

    // تحديث حالة القراءة في Firebase
    try {
      const customerData = customerChats.find(chat => chat.customerId === customerId);
      if (customerData) {
        await fetch('/api/support-messages/mark-read', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            customerPhone: customerData.customerPhone
          })
        });
      }
    } catch (error) {
      console.error('خطأ في تحديث حالة القراءة في Firebase:', error);
    }
  };

  // حذف محادثة كاملة من قبل المدير (يحذف من كلا الطرفين)
  const deleteCustomerChat = async (customerId: number) => {
    const customerData = customerChats.find(chat => chat.customerId === customerId);
    if (!customerData) return;

    // تأكيد الحذف
    if (!confirm(`هل تريد حذف محادثة ${customerData.customerName} نهائياً؟ لن يتمكن العميل من رؤية المحادثة أيضاً.`)) {
      return;
    }

    try {
      // حذف المحادثة نهائياً من Firebase
      const response = await fetch('/api/support-messages/delete-completely', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          customerPhone: customerData.customerPhone
        })
      });

      if (response.ok) {
        console.log('✅ تم حذف المحادثة نهائياً من كلا الطرفين');
        
        // حذف من localStorage أيضاً
        localStorage.removeItem(`support_chat_${customerId}`);
        
        // تحديث الحالة
        setCustomerChats(prev => prev.filter(chat => chat.customerId !== customerId));
        
        // إغلاق المحادثة المفتوحة إذا كانت نفس المحذوفة
        if (selectedCustomer?.customerId === customerId) {
          setSelectedCustomer(null);
        }
      } else {
        console.error('❌ فشل في حذف المحادثة من Firebase');
        alert('فشل في حذف المحادثة. يرجى المحاولة لاحقاً.');
      }
    } catch (error) {
      console.error('❌ خطأ في حذف المحادثة:', error);
      alert('حدث خطأ أثناء حذف المحادثة.');
    }
  };

  // تحميل المحادثات عند تحميل بيانات المستخدمين
  useEffect(() => {
    if (users && users.length > 0) {
      loadCustomerChats();
      
      // تحديث المحادثات كل 30 ثانية
      const interval = setInterval(loadCustomerChats, 30000);
      return () => clearInterval(interval);
    }
  }, [users]);

  // تصفية المحادثات حسب البحث
  const filteredChats = customerChats.filter(chat =>
    chat.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    chat.customerPhone.includes(searchTerm)
  );

  // الردود السريعة للمديرين
  const quickReplies = [
    'شكراً لتواصلك معنا، سنساعدك فوراً.',
    'تم استلام طلبك وسيتم معالجته خلال 24 ساعة.',
    'نعتذر عن التأخير، سيتم حل المشكلة قريباً.',
    'هل تحتاج مساعدة إضافية؟',
    'تم حل المشكلة، شكراً لصبرك.',
    'يمكنك التواصل معنا في أي وقت.'
  ];

  return (
    <div className="h-screen flex bg-gray-50" dir="rtl">
      {/* Sidebar - قائمة المحادثات */}
      <div className="w-1/3 bg-white border-l border-gray-200 flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-gray-200">
          <div className="flex justify-between items-center mb-3">
            <h2 className="text-xl font-bold text-gray-900">إدارة الدعم الفني</h2>
            <Button
              onClick={loadCustomerChats}
              variant="outline"
              size="sm"
              className="text-xs"
            >
              تحديث
            </Button>
          </div>
          <div className="relative">
            <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="البحث في المحادثات..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pr-10"
            />
          </div>
        </div>

        {/* Statistics */}
        <div className="p-4 border-b border-gray-100">
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">{customerChats.length}</div>
              <div className="text-xs text-gray-500">إجمالي المحادثات</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-red-600">
                {customerChats.reduce((acc, chat) => acc + chat.unreadCount, 0)}
              </div>
              <div className="text-xs text-gray-500">رسائل جديدة</div>
            </div>
          </div>
        </div>

        {/* Chat List */}
        <div className="flex-1 overflow-y-auto">
          {filteredChats.length === 0 ? (
            <div className="p-4 text-center text-gray-500">
              <MessageCircle className="w-12 h-12 mx-auto mb-2 text-gray-300" />
              <p>لا توجد محادثات</p>
            </div>
          ) : (
            filteredChats.map((chat) => (
              <div
                key={chat.customerId}
                onClick={() => {
                  setSelectedCustomer(chat);
                  markAsRead(chat.customerId);
                }}
                className={`p-4 border-b border-gray-100 cursor-pointer hover:bg-gray-50 ${
                  selectedCustomer?.customerId === chat.customerId ? 'bg-purple-50 border-purple-200' : ''
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                      <User className="w-6 h-6 text-purple-600" />
                    </div>
                    <div>
                      <div className="font-medium text-gray-900">{chat.customerName}</div>
                      <div className="text-sm text-gray-500">{chat.customerPhone}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {chat.unreadCount > 0 && (
                      <Badge variant="destructive" className="text-xs">
                        {chat.unreadCount}
                      </Badge>
                    )}
                    <Button
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteCustomerChat(chat.customerId);
                      }}
                      variant="ghost"
                      size="sm"
                      className="text-red-500 hover:text-red-700 hover:bg-red-50 p-1"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                      </svg>
                    </Button>
                  </div>
                </div>
                
                <div className="text-sm text-gray-600 mb-1">
                  {chat.messages[chat.messages.length - 1]?.text.substring(0, 50)}...
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="text-xs text-gray-400 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {chat.lastMessageTime.toLocaleTimeString('ar-IQ', { 
                      hour: '2-digit', 
                      minute: '2-digit' 
                    })}
                  </div>
                  {chat.isActive && (
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {selectedCustomer ? (
          <>
            {/* Chat Header */}
            <div className="p-6 bg-gradient-to-r from-purple-600 to-blue-600 text-white shadow-lg">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center border border-white/30">
                    <User className="w-7 h-7 text-white" />
                  </div>
                  <div>
                    <div className="font-bold text-xl">{selectedCustomer.customerName}</div>
                    <div className="text-purple-100 flex items-center gap-2">
                      <span>{selectedCustomer.customerPhone}</span>
                      {selectedCustomer.unreadCount > 0 && (
                        <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                          {selectedCustomer.unreadCount} جديد
                        </span>
                      )}
                    </div>
                    <div className="text-purple-200 text-sm mt-1">
                      آخر نشاط: {selectedCustomer.lastMessageTime.toLocaleString('ar-EG')}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="bg-white/10 backdrop-blur-sm rounded-lg px-3 py-2 border border-white/20">
                    <span className="text-sm font-medium">{selectedCustomer.messages.length} رسالة</span>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setSelectedCustomer(null)}
                    className="bg-white/10 border-white/30 text-white hover:bg-white/20"
                  >
                    إغلاق المحادثة
                  </Button>
                </div>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-gradient-to-b from-gray-50 to-white">
              {selectedCustomer.messages.length === 0 ? (
                <div className="flex items-center justify-center h-full">
                  <div className="text-center text-gray-500">
                    <MessageCircle className="w-20 h-20 mx-auto mb-4 text-gray-300" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">لا توجد رسائل بعد</h3>
                    <p className="text-sm">ابدأ المحادثة بإرسال رسالة ترحيب للعميل</p>
                  </div>
                </div>
              ) : (
                selectedCustomer.messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${message.sender === 'support' ? 'justify-start' : 'justify-end'}`}
                  >
                    <div
                      className={`max-w-xs px-4 py-3 rounded-lg ${
                        message.sender === 'support'
                          ? 'bg-purple-600 text-white'
                          : 'bg-white text-slate-900 border shadow-sm'
                      }`}
                    >
                      <div className="flex items-center gap-2 mb-2">
                        {message.sender === 'support' ? (
                          <Bot className="w-4 h-4 text-white" />
                        ) : (
                          <User className="w-4 h-4 text-purple-600" />
                        )}
                        <span className="text-xs font-medium">
                          {message.sender === 'support' ? 'دعم تاجر' : selectedCustomer.customerName}
                        </span>
                        <span className="text-xs opacity-70">
                          {message.timestamp.toLocaleTimeString('ar-IQ', { 
                            hour: '2-digit', 
                            minute: '2-digit' 
                          })}
                        </span>
                      </div>
                      <p className="text-sm leading-relaxed">{message.text}</p>
                      {message.status && (
                        <div className="flex items-center gap-1 mt-2">
                          <div className="text-xs opacity-70">
                            {message.status === 'sent' && '✓'}
                            {message.status === 'delivered' && '✓✓'}
                            {message.status === 'read' && '✓✓'}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Quick Replies */}
            <div className="p-4 border-t border-gray-100">
              <p className="text-sm font-medium text-gray-700 mb-2">الردود السريعة:</p>
              <div className="flex flex-wrap gap-2 mb-4">
                {quickReplies.map((reply, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    onClick={() => setNewMessage(reply)}
                    className="text-xs"
                  >
                    {reply}
                  </Button>
                ))}
              </div>
            </div>

            {/* Message Input */}
            <div className="p-4 bg-white border-t border-gray-200">
              <div className="flex gap-3">
                <Textarea
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder="اكتب ردك..."
                  onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), sendAdminReply())}
                  className="flex-1 min-h-[60px] max-h-[120px]"
                />
                <Button
                  onClick={sendAdminReply}
                  disabled={!newMessage.trim()}
                  className="bg-purple-600 hover:bg-purple-700 px-6"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center bg-gray-50">
            <div className="text-center">
              <MessageCircle className="w-16 h-16 mx-auto mb-4 text-gray-300" />
              <h3 className="text-xl font-medium text-gray-900 mb-2">اختر محادثة للبدء</h3>
              <p className="text-gray-500">اختر عميل من القائمة الجانبية لبدء المحادثة</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};