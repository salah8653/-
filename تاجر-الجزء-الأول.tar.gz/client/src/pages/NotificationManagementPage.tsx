import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { 
  Bell, 
  Send, 
  Users, 
  MessageCircle, 
  Clock, 
  CheckCircle, 
  XCircle, 
  Truck, 
  DollarSign, 
  Wrench,
  User
} from 'lucide-react';

interface Notification {
  id: string;
  title: string;
  message: string;
  type: string;
  recipients: string[];
  status: string;
  createdAt: string;
  sentAt?: string;
}

export const NotificationManagementPage = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [notificationForm, setNotificationForm] = useState({
    type: 'general',
    title: '',
    message: '',
    recipients: 'all',
    specificPhones: ''
  });

  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);

  // جلب قائمة المستخدمين
  const { data: users = [], isLoading: isLoadingUsers } = useQuery({
    queryKey: ['/api/users'],
    queryFn: async () => {
      console.log('🔍 جلب المستخدمين من API...');
      const response = await fetch('/api/users', {
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw new Error(`خطأ HTTP: ${response.status}`);
      }
      
      const data = await response.json();
      console.log('📋 استجابة API للمستخدمين:', data);
      console.log('📊 نوع البيانات:', typeof data);
      console.log('📈 عدد المستخدمين:', Array.isArray(data) ? data.length : 'ليس مصفوفة');
      
      if (Array.isArray(data)) {
        console.log('✅ البيانات صحيحة - مصفوفة تحتوي على:', data.length, 'مستخدم');
        data.forEach((user, index) => {
          console.log(`👤 المستخدم ${index + 1}:`, {
            id: user.id,
            name: user.fullName || user.name,
            phone: user.phone,
            role: user.role
          });
        });
        return data;
      } else {
        console.log('❌ البيانات غير صحيحة - ليست مصفوفة');
        return [];
      }
    }
  });

  // جلب سجل الإشعارات
  const { data: notifications = [], isLoading } = useQuery({
    queryKey: ['/api/notifications'],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/notifications');
      return Array.isArray(response) ? response : [];
    }
  });

  // إرسال إشعار
  const sendNotificationMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest('POST', '/api/send-notification', data);
    },
    onSuccess: () => {
      toast({
        title: "تم إرسال الإشعار بنجاح",
        description: "سيتم توصيل الإشعار للمستلمين المحددين"
      });
      
      // إعادة تعيين النموذج
      setNotificationForm({
        type: 'general',
        title: '',
        message: '',
        recipients: 'all',
        specificPhones: ''
      });
      setSelectedUsers([]);

      // تحديث قائمة الإشعارات
      queryClient.invalidateQueries({ queryKey: ['/api/notifications'] });
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في إرسال الإشعار",
        description: error.message || "حدث خطأ أثناء إرسال الإشعار",
        variant: "destructive"
      });
    }
  });

  const handleSendNotification = () => {
    if (!notificationForm.title.trim() || !notificationForm.message.trim()) {
      toast({
        title: "بيانات ناقصة",
        description: "يرجى ملء جميع الحقول المطلوبة",
        variant: "destructive"
      });
      return;
    }

    let recipients: string[] = [];
    
    if (notificationForm.recipients === 'all') {
      recipients = users?.map((u: any) => u.phone).filter(Boolean) || [];
    } else {
      const selectedPhones = users
        ?.filter((u: any) => selectedUsers.includes(u.phone || u.email || u.id))
        ?.map((u: any) => u.phone)
        ?.filter(Boolean) || [];
      recipients = selectedPhones;
    }

    if (recipients.length === 0) {
      toast({
        title: "لا يوجد مستلمين",
        description: "يرجى تحديد المستلمين",
        variant: "destructive"
      });
      return;
    }

    sendNotificationMutation.mutate({
      title: notificationForm.title,
      message: notificationForm.message,
      type: notificationForm.type,
      targetType: notificationForm.recipients,
      selectedUsers: recipients
    });
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'order': return <Truck className="w-4 h-4" />;
      case 'payment': return <DollarSign className="w-4 h-4" />;
      case 'maintenance': return <Wrench className="w-4 h-4" />;
      default: return <Bell className="w-4 h-4" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'sent':
        return <Badge variant="default" className="bg-green-100 text-green-800">تم الإرسال</Badge>;
      case 'pending':
        return <Badge variant="default" className="bg-yellow-100 text-yellow-800">قيد الإرسال</Badge>;
      case 'failed':
        return <Badge variant="destructive">فشل الإرسال</Badge>;
      default:
        return <Badge variant="secondary">غير محدد</Badge>;
    }
  };

  const applyTemplate = (template: string) => {
    switch (template) {
      case 'delivery':
        setNotificationForm(prev => ({
          ...prev,
          type: 'order',
          title: 'تم توصيل طلبك بنجاح',
          message: 'عزيزي العميل، تم توصيل طلبك بنجاح. نشكرك لاختيارك متجرنا ونتمنى أن تكون راضياً عن منتجاتنا.'
        }));
        break;
      case 'rejected':
        setNotificationForm(prev => ({
          ...prev,
          type: 'order',
          title: 'تم رفض طلبك',
          message: 'نعتذر، تم رفض طلبك لأسباب فنية. يرجى التواصل معنا للمزيد من التفاصيل.'
        }));
        break;
      case 'maintenance':
        setNotificationForm(prev => ({
          ...prev,
          type: 'maintenance',
          title: 'صيانة مجدولة للنظام',
          message: 'سيكون النظام متوقفاً مؤقتاً للصيانة. نعتذر عن أي إزعاج قد يحدث.'
        }));
        break;
      case 'profit':
        setNotificationForm(prev => ({
          ...prev,
          type: 'payment',
          title: 'تحديث الأرباح',
          message: 'تم تحديث أرباحك. يمكنك مراجعة تفاصيل الأرباح في حسابك.'
        }));
        break;
    }
  };

  return (
    <div className="container mx-auto px-4 py-8" dir="rtl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">إدارة الإشعارات</h1>
        <p className="text-gray-600">إرسال إشعارات للمستخدمين وإدارة الرسائل</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* نموذج إرسال الإشعارات */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Send className="w-5 h-5" />
              إرسال إشعار جديد
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* قوالب الإشعارات الجاهزة */}
            <div>
              <label className="text-sm font-medium mb-2 block">قوالب جاهزة</label>
              <div className="grid grid-cols-2 gap-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => applyTemplate('delivery')}
                  className="justify-start"
                >
                  <Truck className="w-4 h-4 ml-2" />
                  تم التوصيل
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => applyTemplate('rejected')}
                  className="justify-start"
                >
                  <XCircle className="w-4 h-4 ml-2" />
                  تم الرفض
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => applyTemplate('maintenance')}
                  className="justify-start"
                >
                  <Wrench className="w-4 h-4 ml-2" />
                  صيانة
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => applyTemplate('profit')}
                  className="justify-start"
                >
                  <DollarSign className="w-4 h-4 ml-2" />
                  الأرباح
                </Button>
              </div>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">نوع الإشعار</label>
              <Select 
                value={notificationForm.type} 
                onValueChange={(value: any) => setNotificationForm(prev => ({ ...prev, type: value }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="order">الطلبات</SelectItem>
                  <SelectItem value="payment">الدفع والأرباح</SelectItem>
                  <SelectItem value="maintenance">الصيانة</SelectItem>
                  <SelectItem value="general">عام</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">عنوان الإشعار</label>
              <Input
                value={notificationForm.title}
                onChange={(e) => setNotificationForm(prev => ({ ...prev, title: e.target.value }))}
                placeholder="أدخل عنوان الإشعار"
              />
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">نص الرسالة</label>
              <Textarea
                value={notificationForm.message}
                onChange={(e) => setNotificationForm(prev => ({ ...prev, message: e.target.value }))}
                placeholder="أدخل نص الرسالة"
                rows={4}
              />
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">المستلمين</label>
              <Select 
                value={notificationForm.recipients} 
                onValueChange={(value: any) => setNotificationForm(prev => ({ ...prev, recipients: value }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع المستخدمين</SelectItem>
                  <SelectItem value="specific">مستخدمين محددين</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* قائمة المستخدمين للاختيار */}
            {notificationForm.recipients === 'specific' && (
              <div className="space-y-3">
                <label className="text-sm font-medium mb-2 block">اختيار المستخدمين</label>
                
                {/* إضافة زر لتحديد/إلغاء تحديد الكل */}
                <div className="flex gap-2 mb-2">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => setSelectedUsers(users?.map((u: any) => u.phone || u.email || u.id) || [])}
                    className="text-xs"
                  >
                    تحديد الكل
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => setSelectedUsers([])}
                    className="text-xs"
                  >
                    إلغاء الكل
                  </Button>
                </div>

                <div className="border rounded-lg p-3 max-h-64 overflow-y-auto bg-gray-50">
                  {isLoadingUsers ? (
                    <div className="text-center py-6">
                      <div className="w-8 h-8 border-2 border-purple-600 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
                      <p className="text-sm text-gray-600">جاري تحميل المستخدمين...</p>
                    </div>
                  ) : users && users.length > 0 ? (
                    <div className="space-y-1">
                      {users.map((user: any, index: number) => (
                        <label 
                          key={user.id || index} 
                          className="flex items-center space-x-2 space-x-reverse cursor-pointer hover:bg-white p-3 rounded-lg border border-transparent hover:border-purple-200 transition-all duration-200"
                        >
                          <input
                            type="checkbox"
                            checked={selectedUsers.includes(user.phone || user.email || user.id)}
                            onChange={(e) => {
                              const userIdentifier = user.phone || user.email || user.id;
                              if (e.target.checked) {
                                setSelectedUsers(prev => [...prev, userIdentifier]);
                              } else {
                                setSelectedUsers(prev => prev.filter(id => id !== userIdentifier));
                              }
                            }}
                            className="rounded border-gray-300 text-purple-600 focus:ring-purple-500 focus:ring-2"
                          />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <User className="w-4 h-4 text-purple-500 flex-shrink-0" />
                              <span className="text-sm font-medium text-gray-900 truncate">
                                {user.fullName || user.name || `مستخدم ${index + 1}`}
                              </span>
                              {user.role && (
                                <Badge 
                                  variant={user.role === 'admin' ? 'default' : 'secondary'} 
                                  className="text-xs flex-shrink-0"
                                >
                                  {user.role === 'admin' ? 'مدير' : 'عميل'}
                                </Badge>
                              )}
                            </div>
                            {user.phone && (
                              <div className="text-xs text-gray-600 mr-6 font-mono">
                                📱 {user.phone}
                              </div>
                            )}
                            {user.email && (
                              <div className="text-xs text-gray-500 mr-6 truncate">
                                ✉️ {user.email}
                              </div>
                            )}
                          </div>
                        </label>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <Users className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                      <p className="text-gray-500 text-sm">لا توجد مستخدمين متاحين</p>
                      <p className="text-gray-400 text-xs mt-1">تأكد من وجود مستخدمين مسجلين في النظام</p>
                    </div>
                  )}
                </div>
                
                {/* عداد المستخدمين المحددين */}
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">
                    إجمالي المستخدمين: {users?.length || 0}
                  </span>
                  {selectedUsers.length > 0 && (
                    <div className="bg-purple-50 text-purple-700 px-3 py-1 rounded-full font-medium">
                      تم اختيار {selectedUsers.length} مستخدم
                    </div>
                  )}
                </div>
              </div>
            )}

            <Button 
              onClick={handleSendNotification}
              disabled={sendNotificationMutation.isPending}
              className="w-full"
            >
              {sendNotificationMutation.isPending ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin ml-2" />
                  جاري الإرسال...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4 ml-2" />
                  إرسال الإشعار
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* سجل الإشعارات */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="w-5 h-5" />
              سجل الإشعارات المُرسلة
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8">
                <div className="w-8 h-8 border-2 border-purple-600 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
                <p className="text-gray-600">جاري جلب سجل الإشعارات...</p>
              </div>
            ) : notifications && notifications.length > 0 ? (
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {notifications.map((notification: Notification) => (
                  <div key={notification.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        {getTypeIcon(notification.type)}
                        <h3 className="font-medium">{notification.title}</h3>
                      </div>
                      <div className="flex items-center gap-2">
                        {getStatusBadge(notification.status)}
                        <span className="text-sm text-gray-500">
                          {new Date(notification.createdAt).toLocaleDateString('ar-SA')}
                        </span>
                      </div>
                    </div>
                    <p className="text-gray-700 mb-3 text-sm">{notification.message}</p>
                    <div className="flex items-center gap-4 text-sm text-gray-600">
                      <span className="flex items-center gap-1">
                        <Users className="w-4 h-4" />
                        {notification.recipients?.length || 0} مستلم
                      </span>
                      {notification.sentAt && (
                        <span>
                          تم الإرسال: {new Date(notification.sentAt).toLocaleString('ar-SA')}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <MessageCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500">لا توجد إشعارات مُرسلة بعد</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default NotificationManagementPage;