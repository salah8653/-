import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Shield, LogOut, MessageCircle, LogIn } from 'lucide-react';
import { useLocation } from 'wouter';

export const BannedUserPage = () => {
  const [, setLocation] = useLocation();

  const handleLogout = () => {
    // مسح بيانات المستخدم من التخزين المحلي
    localStorage.removeItem('currentUser');
    localStorage.removeItem('userRole');
    localStorage.removeItem('authToken');
    
    // إعادة توجيه لصفحة تسجيل الدخول
    setLocation('/login');
  };

  const handleContactSupport = () => {
    const whatsappNumber = "9647801258110";
    const message = "مرحباً، أحتاج مساعدة حول حالة الحظر في حسابي";
    const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const handleLogin = () => {
    // مسح جميع بيانات المستخدم المحظور
    localStorage.removeItem('currentUser');
    localStorage.removeItem('userRole');
    localStorage.removeItem('authToken');
    
    // العودة إلى الصفحة الرئيسية (البداية)
    setLocation('/');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-100 flex items-center justify-center p-4">
      <Card className="max-w-md w-full border-red-200 shadow-lg">
        <CardContent className="p-8 text-center">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <Shield className="w-8 h-8 text-red-600" />
          </div>
          
          <h1 className="text-2xl font-bold text-red-700 mb-4">تم حظر حسابك نهائياً</h1>
          
          <div className="text-gray-600 mb-6 space-y-2">
            <p>عذراً، تم حظر حسابك نهائياً من قبل الإدارة.</p>
            <p>لا يمكنك الوصول إلى التطبيق.</p>
            <p>للاستفسار حول سبب الحظر، يرجى التواصل مع الدعم الفني.</p>
          </div>
          
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
            <h3 className="font-semibold text-red-700 mb-2">معلومات مهمة:</h3>
            <ul className="text-sm text-red-600 space-y-1 text-right">
              <li>• الحظر نهائي ولا يحتوي على تاريخ انتهاء</li>
              <li>• جميع جلسات التطبيق الخاصة بك تم إنهاؤها</li>
              <li>• يمكنك التواصل مع الدعم الفني للاستفسار</li>
            </ul>
          </div>
          
          <div className="space-y-3 mb-6">
            <Button
              onClick={handleContactSupport}
              className="w-full bg-green-600 hover:bg-green-700 text-white"
            >
              <MessageCircle className="w-4 h-4 ml-2" />
              تواصل عبر الواتساب
            </Button>
            
            <Button
              onClick={handleLogin}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white"
            >
              <LogIn className="w-4 h-4 ml-2" />
              الرجوع إلى تسجيل الدخول
            </Button>
            
            <Button
              onClick={handleLogout}
              variant="outline"
              className="w-full border-red-300 text-red-600 hover:bg-red-50"
            >
              <LogOut className="w-4 h-4 ml-2" />
              تسجيل الخروج
            </Button>
          </div>
          
          <div className="mt-4 text-center">
            <p className="text-sm text-gray-500">
              للدعم الفني عبر واتساب: +9647801258110
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};