import { CleanAdminDashboard } from '@/components/CleanAdminDashboard';

export const DashboardPage = () => {
  return <CleanAdminDashboard />;
};
