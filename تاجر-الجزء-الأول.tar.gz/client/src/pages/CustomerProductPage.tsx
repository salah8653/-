import { useState, useRef, useEffect } from "react";
import { useParams, Link, useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "@/contexts/LanguageContext";
import { 
  ArrowLeft, 
  Copy, 
  ShoppingCart, 
  Package,
  Download 
} from "lucide-react";

interface Product {
  id: number;
  name: string;
  description: string;
  price: string;
  minPrice?: string;
  maxPrice?: string;
  stock: number;
  imageUrl?: string;
  additionalImages?: string[];
  category?: {
    name: string;
  };
}

export const CustomerProductPage = () => {
  const { language, t, dir } = useLanguage();
  const { id } = useParams<{ id: string }>();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const imageContainerRef = useRef<HTMLDivElement>(null);
  const [touchStart, setTouchStart] = useState<number | null>(null);
  const [touchEnd, setTouchEnd] = useState<number | null>(null);

  // جلب بيانات المنتج
  const { data: product, isLoading } = useQuery<Product>({
    queryKey: [`/api/products/${id}`],
    enabled: !!id,
  });

  // إعادة تعيين فهرس الصورة عند تغيير المنتج
  useEffect(() => {
    if (product?.id) {
      setSelectedImageIndex(0);
    }
  }, [product?.id]);

  // وظائف التمرير باللمس
  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchEnd(null);
    setTouchStart(e.targetTouches[0].clientX);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const handleTouchEnd = () => {
    if (!touchStart || !touchEnd) return;
    
    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > 50;
    const isRightSwipe = distance < -50;

    if (product) {
      const allImages = [product.imageUrl, ...(product.additionalImages || [])].filter(Boolean);
      
      // عكس التمرير: اليمين للتالي، اليسار للسابق
      if (isRightSwipe && selectedImageIndex < allImages.length - 1) {
        setSelectedImageIndex(selectedImageIndex + 1);
      }
      
      if (isLeftSwipe && selectedImageIndex > 0) {
        setSelectedImageIndex(selectedImageIndex - 1);
      }
    }
  };



  // نسخ الوصف
  const copyDescription = () => {
    if (product?.description) {
      navigator.clipboard.writeText(product.description);
      toast({
        title: language === 'ar' ? "تم النسخ" : "Copied",
        description: language === 'ar' ? "تم نسخ وصف المنتج" : "Product description copied",
      });
    }
  };

  // تحميل الصورة
  const downloadImage = async () => {
    if (product?.imageUrl) {
      try {
        const response = await fetch(product.imageUrl);
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${product.name}.jpg`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        
        toast({
          title: language === 'ar' ? "تم التحميل" : "Downloaded",
          description: language === 'ar' ? "تم تحميل صورة المنتج بنجاح" : "Product image downloaded successfully",
        });
      } catch (error) {
        toast({
          title: language === 'ar' ? "خطأ" : "Error",
          description: language === 'ar' ? "فشل في تحميل الصورة" : "Failed to download image",
          variant: "destructive",
        });
      }
    }
  };



  // إضافة إلى السلة
  const addToCartMutation = useMutation({
    mutationFn: async () => {
      if (!product) return;
      const response = await fetch('/api/cart', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ productId: product.id, quantity: 1 }),
      });
      if (!response.ok) throw new Error('فشل في إضافة المنتج');
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: language === 'ar' ? "تم إضافة المنتج" : "Product Added",
        description: language === 'ar' ? "تم إضافة المنتج إلى السلة بنجاح" : "Product added to cart successfully",
      });
      // التوجه مباشرة إلى صفحة السلة
      setLocation('/cart');
    },
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            {language === 'ar' ? 'المنتج غير موجود' : 'Product not found'}
          </h3>
          <Link href="/store">
            <Button>{language === 'ar' ? 'العودة للمتجر' : 'Back to Store'}</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50" dir={dir}>
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 py-3">
        <div className="flex items-center justify-between">
          <Link href="/store">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="w-4 h-4 ml-2" />
            </Button>
          </Link>
          

        </div>
      </div>

      <div className="container mx-auto max-w-md p-4 space-y-4">
        {/* معرض الصور */}
        <Card className="overflow-hidden">
          <CardContent className="p-0 relative">
            {(() => {
              const allImages = [product.imageUrl, ...(product.additionalImages || [])].filter(Boolean);
              const currentImage = allImages[selectedImageIndex] || product.imageUrl;
              
              return (
                <>
                  <div className="relative">
                    {/* عرض صورة واحدة كبيرة */}
                    <div 
                      className="aspect-square bg-gray-100 relative"
                      onTouchStart={handleTouchStart}
                      onTouchMove={handleTouchMove}
                      onTouchEnd={handleTouchEnd}
                    >
                      <img
                        src={allImages[selectedImageIndex] || product.imageUrl}
                        alt={`${product.name} - صورة ${selectedImageIndex + 1}`}
                        className="w-full h-full object-cover select-none"
                        draggable={false}
                      />
                      
                      {/* زر تحميل الصورة */}
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          const currentImage = allImages[selectedImageIndex] || product.imageUrl;
                          if (currentImage) {
                            const link = document.createElement('a');
                            link.href = currentImage;
                            link.download = `${product.name}-${selectedImageIndex + 1}.jpg`;
                            link.click();
                          }
                        }}
                        className="absolute top-2 right-2 bg-white/80 hover:bg-white"
                      >
                        <Download className="w-4 h-4" />
                      </Button>
                      
                      {/* أزرار التنقل */}
                      {allImages.length > 1 && (
                        <>
                          {/* السهم الأيسر */}
                          {selectedImageIndex > 0 && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setSelectedImageIndex(selectedImageIndex - 1)}
                              className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-white/80 hover:bg-white"
                            >
                              ←
                            </Button>
                          )}
                          
                          {/* السهم الأيمن */}
                          {selectedImageIndex < allImages.length - 1 && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setSelectedImageIndex(selectedImageIndex + 1)}
                              className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-white/80 hover:bg-white"
                            >
                              →
                            </Button>
                          )}
                        </>
                      )}
                    </div>

                    {/* مؤشر النقاط */}
                    {allImages.length > 1 && (
                      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-2">
                        {allImages.map((_, index) => (
                          <div
                            key={index}
                            className={`w-2 h-2 rounded-full transition-all ${
                              selectedImageIndex === index 
                                ? 'bg-white' 
                                : 'bg-white/50'
                            }`}
                          />
                        ))}
                      </div>
                    )}

                    {/* عداد الصور */}
                    {allImages.length > 1 && (
                      <div className="absolute top-2 left-2 bg-black/60 text-white px-2 py-1 rounded-full text-xs">
                        {selectedImageIndex + 1} / {allImages.length}
                      </div>
                    )}
                  </div>

                  {/* الصور المصغرة */}
                  {allImages.length > 1 && (
                    <div className="p-3 bg-gray-50">
                      <div className="flex gap-2 overflow-x-auto">
                        {allImages.map((image, index) => (
                          <button
                            key={index}
                            onClick={() => setSelectedImageIndex(index)}
                            className={`flex-shrink-0 w-16 h-16 rounded-lg overflow-hidden border-2 transition-all ${
                              selectedImageIndex === index 
                                ? 'border-blue-500 ring-2 ring-blue-200' 
                                : 'border-gray-200 hover:border-gray-300'
                            }`}
                          >
                            <img
                              src={image}
                              alt={`${product.name} - صورة ${index + 1}`}
                              className="w-full h-full object-cover"
                            />
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </>
              );
            })()}
          </CardContent>
        </Card>

        {/* معلومات المنتج */}
        <Card>
          <CardContent className="p-4 space-y-4">
            {/* الاسم والفئة */}
            <div>
              <h1 className="text-xl font-bold text-gray-900 mb-2">{product.name}</h1>
              {product.category ? (
                <Badge variant="outline" className="text-sm bg-blue-50 text-blue-700 border-blue-200">
                  <Package className={`w-3 h-3 ${language === 'ar' ? 'ml-1' : 'mr-1'}`} />
                  {product.category.name}
                </Badge>
              ) : (
                <Badge variant="outline" className="text-sm bg-gray-50 text-gray-500 border-gray-200">
                  <Package className={`w-3 h-3 ${language === 'ar' ? 'ml-1' : 'mr-1'}`} />
                  {language === 'ar' ? 'غير مصنف' : 'Uncategorized'}
                </Badge>
              )}
            </div>

            {/* الأسعار */}
            <div className="space-y-2">
              {/* سعر الجملة */}
              <div>
                <div className="text-sm text-gray-600 mb-1">
                  {language === 'ar' ? 'سعر الجملة:' : 'Wholesale Price:'}
                </div>
                <div className="text-lg font-bold text-purple-600" style={{ direction: 'ltr' }}>
                  {parseInt(product.price).toLocaleString('en-US')} {language === 'ar' ? 'د.ع' : 'IQD'}
                </div>
              </div>

              {/* نطاق السعر */}
              {product.minPrice && product.maxPrice ? (
                <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                  <div className="text-xs text-red-600 mb-1 font-medium">
                    {language === 'ar' ? 'نطاق السعر المطلوب' : 'Required Price Range'}
                  </div>
                  <div className="text-sm flex items-center gap-2" style={{ direction: 'ltr' }}>
                    <span className="text-black">
                      {language === 'ar' ? 'الحد الأدنى:' : 'Min:'} {parseInt(product.minPrice).toLocaleString('en-US')} {language === 'ar' ? 'د.ع' : 'IQD'}
                    </span>
                    <span className="text-gray-400">-</span>
                    <span className="text-black">
                      {language === 'ar' ? 'الحد الأعلى:' : 'Max:'} {parseInt(product.maxPrice).toLocaleString('en-US')} {language === 'ar' ? 'د.ع' : 'IQD'}
                    </span>
                  </div>
                </div>
              ) : (
                <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                  <div className="text-xs text-red-600">
                    {language === 'ar' ? 'لم يتم تحديد نطاق السعر بعد' : 'Price range not set yet'}
                  </div>
                </div>
              )}
            </div>

            {/* حالة المخزون */}
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">
                {language === 'ar' ? 'المخزون:' : 'Stock:'}
              </span>
              <Badge 
                variant={product.stock > 0 ? "default" : "destructive"}
                className="text-xs"
              >
                {product.stock > 0 
                  ? language === 'ar' 
                    ? `متوفر (${product.stock})` 
                    : `Available (${product.stock})`
                  : language === 'ar' 
                    ? "غير متوفر" 
                    : "Out of stock"
                }
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* وصف المنتج */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-medium text-gray-900">
                {language === 'ar' ? 'وصف المنتج' : 'Product Description'}
              </h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={copyDescription}
                className="text-purple-600"
              >
                <Copy className={`w-4 h-4 ${language === 'ar' ? 'ml-1' : 'mr-1'}`} />
                {language === 'ar' ? 'نسخ' : 'Copy'}
              </Button>
            </div>
            <p className="text-gray-700 leading-relaxed">
              {product.description || (language === 'ar' ? "لا يوجد وصف متاح للمنتج" : "No description available for this product")}
            </p>
          </CardContent>
        </Card>

        {/* زر إضافة للسلة */}
        <Button
          onClick={() => addToCartMutation.mutate()}
          disabled={product.stock === 0}
          className="w-full bg-purple-600 hover:bg-purple-700 text-white py-4 text-lg"
        >
          <ShoppingCart className={`w-5 h-5 ${language === 'ar' ? 'ml-2' : 'mr-2'}`} />
          {language === 'ar' ? 'إضافة إلى السلة' : 'Add to Cart'}
        </Button>
      </div>
    </div>
  );
};