import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Home, ArrowLeft } from "lucide-react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";

export default function NotFound() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();

  const handleGoHome = () => {
    // توجيه المستخدم حسب دوره
    if (user?.role === 'admin') {
      setLocation('/dashboard');
    } else {
      setLocation('/');
    }
  };

  const handleGoBack = () => {
    window.history.back();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-xl">
        <CardContent className="p-8 text-center">
          {/* رقم الخطأ */}
          <div className="text-6xl font-bold text-gray-300 mb-4">404</div>
          
          {/* العنوان */}
          <h1 className="text-2xl font-bold text-gray-800 mb-4">
            الصفحة غير موجودة
          </h1>
          
          {/* الوصف */}
          <p className="text-gray-600 mb-8">
            عذراً، لا يمكن العثور على الصفحة التي تبحث عنها. 
            قد تكون قد تم حذفها أو نقلها أو أن الرابط غير صحيح.
          </p>
          
          {/* الأزرار */}
          <div className="space-y-3">
            <Button
              onClick={handleGoHome}
              className="w-full bg-blue-600 hover:bg-blue-700"
            >
              <Home className="w-4 h-4 ml-2" />
              العودة للرئيسية
            </Button>
            
            <Button
              onClick={handleGoBack}
              variant="outline"
              className="w-full"
            >
              <ArrowLeft className="w-4 h-4 ml-2" />
              الرجوع للخلف
            </Button>
          </div>
          
          {/* رسالة المساعدة */}
          <div className="mt-8 text-sm text-gray-500">
            إذا كنت تعتقد أن هذا خطأ، يرجى التواصل مع الدعم الفني
          </div>
        </CardContent>
      </Card>
    </div>
  );
}