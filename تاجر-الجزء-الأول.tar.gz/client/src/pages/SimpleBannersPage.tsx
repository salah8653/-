import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { Plus, Edit, Trash2, Upload, Save, Eye, EyeOff } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface Banner {
  id: number;
  title: string;
  description?: string;
  imageUrl?: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

interface BannerFormData {
  title: string;
  description: string;
  isActive: boolean;
  imageUrl: string;
}

export function SimpleBannersPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState<BannerFormData>({
    title: '',
    description: '',
    isActive: true,
    imageUrl: ''
  });
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadingImage, setUploadingImage] = useState(false);

  // جلب البانرات
  const { data: bannersData, isLoading } = useQuery({
    queryKey: ["/api/banners"],
  });

  const banners = (bannersData as Banner[]) || [];

  // رفع الصورة
  const uploadImage = async (file: File): Promise<string> => {
    const uploadFormData = new FormData();
    uploadFormData.append('image', file);
    
    const response = await fetch('/api/upload-image', {
      method: 'POST',
      body: uploadFormData
    });
    
    if (!response.ok) {
      throw new Error('فشل في رفع الصورة');
    }
    
    const result = await response.json();
    return result.url;
  };

  // إضافة بانر جديد
  const createMutation = useMutation({
    mutationFn: async (data: BannerFormData) => {
      let imageUrl = data.imageUrl;
      
      if (selectedFile) {
        setUploadingImage(true);
        try {
          imageUrl = await uploadImage(selectedFile);
        } finally {
          setUploadingImage(false);
        }
      }
      
      return await apiRequest("POST", "/api/banners", {
        ...data,
        imageUrl: imageUrl
      });
    },
    onSuccess: () => {
      toast({
        title: "تم إنشاء البانر",
        description: "تم إضافة البانر بنجاح",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/banners"] });
      resetForm();
    },
    onError: (error: any) => {
      const errorMessage = error?.response?.data?.message || "فشل في إضافة البانر";
      toast({
        title: "خطأ",
        description: errorMessage,
        variant: "destructive",
      });
    },
  });

  // تحديث بانر
  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: BannerFormData }) => {
      let imageUrl = data.imageUrl;
      
      if (selectedFile) {
        setUploadingImage(true);
        try {
          imageUrl = await uploadImage(selectedFile);
        } finally {
          setUploadingImage(false);
        }
      }
      
      return await apiRequest("PUT", `/api/banners/${id}`, {
        ...data,
        imageUrl: imageUrl
      });
    },
    onSuccess: () => {
      toast({
        title: "تم تحديث البانر",
        description: "تم تحديث البانر بنجاح",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/banners"] });
      resetForm();
    },
    onError: (error: any) => {
      const errorMessage = error?.response?.data?.message || "فشل في تحديث البانر";
      toast({
        title: "خطأ",
        description: errorMessage,
        variant: "destructive",
      });
    },
  });

  // حذف بانر
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/banners/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "تم حذف البانر",
        description: "تم حذف البانر بنجاح",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/banners"] });
    },
  });

  // تبديل حالة البانر
  const toggleBannerStatus = (banner: Banner) => {
    updateMutation.mutate({
      id: banner.id,
      data: { 
        title: banner.title,
        description: banner.description || '',
        imageUrl: banner.imageUrl || '',
        isActive: !banner.isActive 
      }
    });
  };

  const resetForm = () => {
    setFormData({
      title: '',
      description: '',
      isActive: true,
      imageUrl: ''
    });
    setSelectedFile(null);
    setUploadingImage(false);
    setEditingId(null);
    setIsFormOpen(false);
  };

  const handleEdit = (banner: Banner) => {
    setFormData({
      title: banner.title,
      description: banner.description || '',
      isActive: banner.isActive,
      imageUrl: banner.imageUrl || ''
    });
    setEditingId(banner.id);
    setIsFormOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title.trim()) {
      toast({
        title: "خطأ",
        description: "يرجى إدخال عنوان البانر",
        variant: "destructive",
      });
      return;
    }

    if (editingId) {
      updateMutation.mutate({ id: editingId, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleDelete = (id: number) => {
    if (confirm("هل أنت متأكد من حذف هذا البانر؟")) {
      deleteMutation.mutate(id);
    }
  };

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="text-center">جاري تحميل البانرات...</div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">إدارة البانرات</h1>
      </div>

      {/* زر إضافة بانر جديد */}
      {!isFormOpen && banners.length < 5 && (
        <Card className="mb-6">
          <CardContent className="pt-6">
            <Button onClick={() => setIsFormOpen(true)} className="w-full">
              <Plus className="w-4 h-4 ml-2" />
              إضافة بانر جديد ({banners.length}/5)
            </Button>
          </CardContent>
        </Card>
      )}
      
      {banners.length >= 5 && !isFormOpen && (
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="text-center text-orange-600">
              <p className="font-medium">تم الوصول للحد الأقصى (5 بانرات)</p>
              <p className="text-sm text-gray-500">احذف بانر لإضافة آخر جديد</p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* نموذج إضافة/تحديث البانر */}
      {isFormOpen && (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>{editingId ? 'تحرير البانر' : 'إضافة بانر جديد'}</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="title">عنوان البانر</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="عنوان البانر"
                  required
                />
              </div>

              <div>
                <Label htmlFor="description">وصف البانر</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="وصف البانر"
                  rows={3}
                />
              </div>

              <div>
                <Label>صورة البانر</Label>
                <div className="space-y-4">
                  <div>
                    <input
                      type="file"
                      id="imageFile"
                      accept="image/*"
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          setSelectedFile(file);
                          setUploadingImage(true);
                          
                          try {
                            const imageUrl = await uploadImage(file);
                            setFormData(prev => ({ ...prev, imageUrl }));
                            toast({
                              title: "نجح الرفع",
                              description: "تم رفع الصورة بنجاح"
                            });
                          } catch (error) {
                            console.error('خطأ في رفع الصورة:', error);
                            toast({
                              title: "خطأ",
                              description: "فشل في رفع الصورة",
                              variant: "destructive"
                            });
                          } finally {
                            setUploadingImage(false);
                          }
                        }
                      }}
                      className="hidden"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => document.getElementById('imageFile')?.click()}
                      disabled={uploadingImage}
                      className="w-full flex items-center gap-2"
                    >
                      <Upload className="w-4 h-4" />
                      {uploadingImage ? 'جاري رفع الصورة...' : 'رفع صورة من الجهاز'}
                    </Button>
                  </div>
                  
                  {formData.imageUrl && (
                    <div className="mt-3">
                      <img
                        src={formData.imageUrl}
                        alt="معاينة البانر"
                        className="w-full h-32 object-cover rounded-lg border"
                      />
                      <p className="text-xs text-green-600 mt-2">✓ تم رفع الصورة بنجاح</p>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex items-center space-x-2 space-x-reverse">
                <Switch
                  checked={formData.isActive}
                  onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked })}
                />
                <Label>البانر نشط</Label>
              </div>

              <div className="flex gap-2">
                <Button 
                  type="submit" 
                  disabled={createMutation.isPending || updateMutation.isPending || uploadingImage}
                  className="flex items-center gap-2"
                >
                  <Save className="w-4 h-4" />
                  {editingId ? 'تحديث البانر' : 'إضافة البانر'}
                </Button>
                <Button type="button" variant="outline" onClick={resetForm}>
                  إلغاء
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* قائمة البانرات */}
      <Card>
        <CardHeader>
          <CardTitle>البانرات المتوفرة ({banners.length}/5)</CardTitle>
        </CardHeader>
        <CardContent>
          {banners.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500">لا توجد بانرات حالياً</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {banners.map((banner, index) => (
                <div key={banner.id} className="border rounded-lg p-4 space-y-3">
                  {/* عداد البانرات */}
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-gray-400">
                      بانر {index + 1} من 5
                    </span>
                    {index === 4 && banners.length >= 5 && (
                      <span className="text-xs text-orange-500">الحد الأقصى</span>
                    )}
                  </div>
                  
                  {/* صورة البانر */}
                  <div className="aspect-video bg-gray-100 rounded-lg overflow-hidden">
                    {banner.imageUrl ? (
                      <img
                        src={banner.imageUrl}
                        alt={banner.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-gray-400">
                        <span>لا توجد صورة</span>
                      </div>
                    )}
                  </div>
                  
                  {/* معلومات البانر */}
                  <div>
                    <h3 className="font-semibold text-lg">{banner.title}</h3>
                    {banner.description && (
                      <p className="text-gray-600 text-sm mt-1">{banner.description}</p>
                    )}
                  </div>

                  {/* حالة البانر */}
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${banner.isActive ? 'bg-green-500' : 'bg-gray-400'}`} />
                    <span className="text-sm text-gray-600">
                      {banner.isActive ? 'نشط' : 'غير نشط'}
                    </span>
                  </div>

                  {/* أزرار التحكم */}
                  <div className="flex gap-2 pt-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleEdit(banner)}
                      className="flex items-center gap-1"
                    >
                      <Edit className="w-3 h-3" />
                      تحرير
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => toggleBannerStatus(banner)}
                      className="flex items-center gap-1"
                    >
                      {banner.isActive ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                      {banner.isActive ? 'إخفاء' : 'إظهار'}
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleDelete(banner.id)}
                      className="flex items-center gap-1"
                    >
                      <Trash2 className="w-3 h-3" />
                      حذف
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}