import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { 
  ArrowLeft, 
  Shield, 
  ShieldOff, 
  User, 
  AlertTriangle,
  CheckCircle
} from 'lucide-react';

interface UserBanManagementProps {
  userId?: string;
}

export const UserBanManagement = () => {
  const [, setLocation] = useLocation();
  const [userId, setUserId] = useState<string>('');
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // الحصول على معرف المستخدم من URL
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const id = urlParams.get('userId');
    if (id) {
      setUserId(id);
      fetchUser(id);
    }
  }, []);

  const fetchUser = async (id: string) => {
    setLoading(true);
    try {
      const response = await fetch(`/api/users/${id}`);
      if (response.ok) {
        const userData = await response.json();
        setUser(userData);
      }
    } catch (error) {
      console.error('خطأ في جلب بيانات المستخدم:', error);
    } finally {
      setLoading(false);
    }
  };

  const banUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      const response = await apiRequest('POST', '/api/users/ban', { userId });
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: 'تم حظر المستخدم',
        description: 'تم حظر المستخدم بنجاح'
      });
      if (userId) fetchUser(userId);
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
    },
    onError: () => {
      toast({
        title: 'خطأ',
        description: 'فشل في حظر المستخدم',
        variant: 'destructive'
      });
    }
  });

  const unbanUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      const response = await apiRequest('POST', '/api/users/unban', { userId });
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: 'تم إلغاء الحظر',
        description: 'تم إلغاء حظر المستخدم بنجاح'
      });
      if (userId) fetchUser(userId);
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
    },
    onError: () => {
      toast({
        title: 'خطأ',
        description: 'فشل في إلغاء حظر المستخدم',
        variant: 'destructive'
      });
    }
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-100 p-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
              <p className="text-gray-600">جاري تحميل بيانات المستخدم...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-100 p-4">
        <div className="max-w-4xl mx-auto">
          <Card className="border-red-200 bg-red-50">
            <CardContent className="p-8 text-center">
              <AlertTriangle className="w-16 h-16 text-red-500 mx-auto mb-4" />
              <h2 className="text-xl font-bold text-red-700 mb-2">لم يتم العثور على المستخدم</h2>
              <p className="text-red-600 mb-4">المستخدم المطلوب غير موجود أو تم حذفه</p>
              <Button onClick={() => setLocation('/admin-user-settings')}>
                <ArrowLeft className="w-4 h-4 ml-2" />
                العودة لإدارة المستخدمين
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-100 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
              <Shield className="w-6 h-6 text-purple-600" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">إدارة حظر المستخدم</h1>
              <p className="text-gray-600">حظر أو إلغاء حظر المستخدمين</p>
            </div>
          </div>
          
          <Button 
            variant="ghost" 
            onClick={() => setLocation('/admin-user-settings')}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            العودة لإدارة المستخدمين
          </Button>
        </div>

        {/* User Info Card */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="w-5 h-5" />
              معلومات المستخدم
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="text-sm font-medium text-gray-700">الاسم الكامل</label>
                <p className="text-lg font-semibold text-gray-900">{user.fullName}</p>
              </div>
              
              <div>
                <label className="text-sm font-medium text-gray-700">رقم الهاتف</label>
                <p className="text-lg font-semibold text-gray-900">{user.phone}</p>
              </div>
              
              <div>
                <label className="text-sm font-medium text-gray-700">تاريخ التسجيل</label>
                <p className="text-lg font-semibold text-gray-900">
                  {new Date(user.createdAt).toLocaleDateString('ar-SA')}
                </p>
              </div>
              
              <div>
                <label className="text-sm font-medium text-gray-700">الحالة الحالية</label>
                <div className="mt-1">
                  {user.status === 'banned' ? (
                    <Badge variant="destructive" className="flex items-center gap-1 w-fit">
                      <ShieldOff className="w-3 h-3" />
                      محظور
                    </Badge>
                  ) : (
                    <Badge variant="secondary" className="flex items-center gap-1 w-fit bg-green-100 text-green-700">
                      <CheckCircle className="w-3 h-3" />
                      نشط
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Action Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5" />
              إجراءات الحظر
            </CardTitle>
          </CardHeader>
          <CardContent>
            {user.status === 'banned' ? (
              <div className="text-center py-8">
                <ShieldOff className="w-16 h-16 text-red-500 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-red-700 mb-2">المستخدم محظور حالياً</h3>
                <p className="text-red-600 mb-6">
                  هذا المستخدم لا يمكنه تسجيل الدخول أو استخدام التطبيق
                </p>
                <Button
                  onClick={() => unbanUserMutation.mutate(user.id)}
                  disabled={unbanUserMutation.isPending}
                  className="bg-green-600 hover:bg-green-700 text-white"
                >
                  {unbanUserMutation.isPending ? 'جاري إلغاء الحظر...' : 'إلغاء الحظر'}
                  <CheckCircle className="w-4 h-4 mr-2" />
                </Button>
              </div>
            ) : (
              <div className="text-center py-8">
                <Shield className="w-16 h-16 text-green-500 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-green-700 mb-2">المستخدم نشط حالياً</h3>
                <p className="text-green-600 mb-6">
                  هذا المستخدم يمكنه تسجيل الدخول واستخدام التطبيق بشكل طبيعي
                </p>
                <Button
                  onClick={() => banUserMutation.mutate(user.id)}
                  disabled={banUserMutation.isPending}
                  variant="destructive"
                >
                  {banUserMutation.isPending ? 'جاري الحظر...' : 'حظر المستخدم'}
                  <ShieldOff className="w-4 h-4 mr-2" />
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};