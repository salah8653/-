import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Ban, Clock, AlertTriangle, LogIn } from "lucide-react";
import { useLocation } from "wouter";

interface BannedPageProps {
  banReason?: string;
  banExpiresAt?: string;
}

export default function BannedPage({ banReason = "حظر من لوحة التحكم", banExpiresAt }: BannedPageProps) {
  const [, setLocation] = useLocation();

  const handleLogin = () => {
    // إعادة تحميل الصفحة للعودة للبداية
    window.location.href = '/';
  };

  const formatBanExpiry = (expiryDate: string) => {
    try {
      const date = new Date(expiryDate);
      return date.toLocaleString('ar-SA', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch {
      return "غير محدد";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl border-red-200 shadow-xl">
        <CardContent className="p-8 text-center">
          {/* أيقونة الحظر */}
          <div className="flex justify-center mb-6">
            <div className="relative">
              <Ban className="w-20 h-20 text-red-500" />
              <AlertTriangle className="w-8 h-8 text-red-600 absolute -top-2 -right-2" />
            </div>
          </div>

          {/* العنوان الرئيسي */}
          <h1 className="text-3xl font-bold text-red-600 mb-4">
            تم حظر حسابك نهائياً
          </h1>

          {/* الرسالة التوضيحية */}
          <p className="text-lg text-gray-700 mb-6">
            تم حظر حسابك نهائياً بسبب انتهاك سياسة التطبيق
          </p>

          {/* تفاصيل الحظر */}
          <div className="bg-red-50 border border-red-200 rounded-lg p-6 mb-6 text-right">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-gray-600">سبب الحظر:</span>
                <span className="font-semibold text-red-700">{banReason}</span>
              </div>
              
              {banExpiresAt && (
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">نوع الحظر:</span>
                  <span className="font-semibold text-red-700">نهائي - لا يحتوي على تاريخ انتهاء</span>
                </div>
              )}
            </div>
          </div>

          {/* إرشادات للمستخدم */}
          <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 mb-6">
            <h3 className="font-semibold text-gray-800 mb-3">ماذا يمكنك فعله؟</h3>
            <ul className="text-sm text-gray-600 space-y-2 text-right">
              <li>• الحظر نهائي ولا يحتوي على تاريخ انتهاء</li>
              <li>• راجع سياسة الاستخدام لتجنب تكرار المخالفة</li>
              <li>• تواصل مع فريق الدعم إذا كنت تعتقد أن الحظر خطأ</li>
            </ul>
          </div>

          {/* أزرار الإجراءات */}
          <div className="flex flex-col gap-3 justify-center">
            <Button
              className="bg-green-600 hover:bg-green-700 text-white"
              onClick={() => window.open('https://wa.me/9647801258110?text=مرحبا، أريد الاستفسار عن حظر حسابي', '_blank')}
            >
              تواصل مع الدعم
            </Button>
            
            <Button
              variant="outline"
              className="border-gray-300"
              onClick={() => window.location.reload()}
            >
              تحديث الصفحة
            </Button>
          </div>

          {/* رسالة تحذيرية */}
          <div className="mt-6 text-xs text-gray-500">
            تذكر: الالتزام بسياسة التطبيق ضروري لضمان تجربة آمنة لجميع المستخدمين
          </div>
        </CardContent>
      </Card>
    </div>
  );
}