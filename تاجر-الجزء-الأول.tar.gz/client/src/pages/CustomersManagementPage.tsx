import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ArrowRight, User, Phone, Package, Clock, MapPin, DollarSign } from 'lucide-react';
import { ResponsiveTopNavbar } from '@/components/ResponsiveTopNavbar';

interface Customer {
  name: string;
  phone: string;
  ordersCount: number;
  totalAmount: number;
  lastOrderDate: string;
}

interface Order {
  id: number;
  total: string;
  status: string;
  customerDetails: {
    name: string;
    phone: string;
    governorate: string;
    area: string;
    address: string;
    notes?: string;
  };
  items: Array<{
    product: {
      name: string;
      price: number;
    };
    quantity: number;
  }>;
  customerPrice: number;
  deliveryFee: number;
  totalWithDelivery: number;
  profit: number;
  orderDate: string;
  createdAt: string;
}

const statusColors = {
  pending: 'bg-yellow-500',
  processing: 'bg-blue-500',
  completed: 'bg-green-500',
  rejected: 'bg-red-500',
  shipped: 'bg-purple-500'
};

const statusLabels = {
  pending: 'قيد المعالجة',
  processing: 'جاري التنفيذ',
  completed: 'مكتمل',
  rejected: 'مرفوض',
  shipped: 'تم الشحن'
};

export const CustomersManagementPage = () => {
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [customerOrders, setCustomerOrders] = useState<Order[]>([]);

  // جلب جميع الطلبات
  const { data: orders = [], isLoading } = useQuery({
    queryKey: ['/api/orders'],
    queryFn: async () => {
      const response = await fetch('/api/orders');
      if (!response.ok) throw new Error('فشل في جلب الطلبات');
      return response.json();
    }
  });

  // تجميع العملاء من الطلبات
  const customers: Customer[] = orders.reduce((acc: Customer[], order: Order) => {
    const customerPhone = order.customerDetails?.phone;
    const customerName = order.customerDetails?.name;
    
    if (!customerPhone || !customerName) return acc;
    
    const existingCustomer = acc.find(c => c.phone === customerPhone);
    
    if (existingCustomer) {
      existingCustomer.ordersCount += 1;
      existingCustomer.totalAmount += parseInt(order.total) || 0;
      if (new Date(order.createdAt) > new Date(existingCustomer.lastOrderDate)) {
        existingCustomer.lastOrderDate = order.createdAt;
      }
    } else {
      acc.push({
        name: customerName,
        phone: customerPhone,
        ordersCount: 1,
        totalAmount: parseInt(order.total) || 0,
        lastOrderDate: order.createdAt
      });
    }
    
    return acc;
  }, []);

  // ترتيب العملاء حسب آخر طلب
  customers.sort((a, b) => new Date(b.lastOrderDate).getTime() - new Date(a.lastOrderDate).getTime());

  const handleCustomerClick = (customer: Customer) => {
    setSelectedCustomer(customer);
    // فلترة الطلبات الخاصة بالعميل المحدد
    const filteredOrders = orders.filter((order: Order) => 
      order.customerDetails?.phone === customer.phone
    );
    setCustomerOrders(filteredOrders);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('ar-EG', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // استخدام دالة formatCurrency من ملف formatters لتنسيق الأرقام باللغة الإنجليزية
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US').format(amount);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <ResponsiveTopNavbar />
        <div className="container mx-auto px-4 pt-20">
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        </div>
      </div>
    );
  }

  if (selectedCustomer) {
    return (
      <div className="min-h-screen bg-gray-50">
        <ResponsiveTopNavbar />
        <div className="container mx-auto px-4 pt-20">
          <div className="mb-6">
            <Button
              onClick={() => setSelectedCustomer(null)}
              variant="outline"
              className="mb-4"
            >
              <ArrowRight className="w-4 h-4 ml-2" />
              العودة إلى قائمة العملاء
            </Button>
            
            <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <User className="w-6 h-6 text-blue-600" />
                  <div className="text-right">
                    <h2 className="text-xl font-bold text-blue-900">{selectedCustomer.name}</h2>
                    <p className="text-blue-700">{selectedCustomer.phone}</p>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">{selectedCustomer.ordersCount}</div>
                    <div className="text-sm text-gray-600">إجمالي الطلبات</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">{formatCurrency(selectedCustomer.totalAmount)} د.ع</div>
                    <div className="text-sm text-gray-600">إجمالي المبلغ</div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm font-medium text-gray-800">{formatDate(selectedCustomer.lastOrderDate)}</div>
                    <div className="text-sm text-gray-600">آخر طلب</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-bold">طلبات العميل ({customerOrders.length})</h3>
            {customerOrders.map((order) => (
              <Card key={order.id} className="border-r-4 border-blue-500">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Package className="w-5 h-5 text-blue-600" />
                      <span className="font-bold text-lg">طلب رقم #{order.id}</span>
                    </div>
                    <Badge 
                      className={`${statusColors[order.status as keyof typeof statusColors]} text-white`}
                    >
                      {statusLabels[order.status as keyof typeof statusLabels]}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-2 text-gray-600">
                    <Clock className="w-4 h-4" />
                    <span>{formatDate(order.createdAt)}</span>
                  </div>
                  
                  <div className="flex items-start gap-2">
                    <MapPin className="w-4 h-4 text-gray-500 mt-1" />
                    <div className="text-sm">
                      <div>{order.customerDetails.governorate} - {order.customerDetails.area}</div>
                      <div className="text-gray-600">{order.customerDetails.address}</div>
                      {order.customerDetails.notes && (
                        <div className="text-gray-500 mt-1">ملاحظات: {order.customerDetails.notes}</div>
                      )}
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <h4 className="font-medium">المنتجات ({order.items?.length || 0})</h4>
                    {order.items?.map((item, index) => (
                      <div key={index} className="flex justify-between text-sm bg-gray-50 p-2 rounded">
                        <span>{item.product?.name || 'منتج غير محدد'}</span>
                        <span>الكمية: {item.quantity}</span>
                      </div>
                    ))}
                  </div>

                  <Separator />

                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="space-y-1">
                      <div className="flex justify-between">
                        <span>سعر العميل:</span>
                        <span>{formatCurrency(order.customerPrice)} د.ع</span>
                      </div>
                      <div className="flex justify-between">
                        <span>رسوم التوصيل:</span>
                        <span>{formatCurrency(order.deliveryFee)} د.ع</span>
                      </div>
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between font-bold">
                        <span>المجموع:</span>
                        <span>{formatCurrency(order.totalWithDelivery)} د.ع</span>
                      </div>
                      <div className="flex justify-between text-green-600 font-medium">
                        <span>الربح:</span>
                        <span>{formatCurrency(order.profit)} د.ع</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <ResponsiveTopNavbar />
      <div className="container mx-auto px-4 pt-20">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">إدارة العملاء</h1>
          <p className="text-gray-600">إجمالي العملاء: {customers.length}</p>
        </div>

        <div className="grid gap-4">
          {customers.map((customer) => (
            <Card 
              key={customer.phone}
              className="cursor-pointer hover:shadow-lg transition-shadow border-r-4 border-blue-500"
              onClick={() => handleCustomerClick(customer)}
            >
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                      <User className="w-6 h-6 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-bold text-lg">{customer.name}</h3>
                      <div className="flex items-center gap-2 text-gray-600">
                        <Phone className="w-4 h-4" />
                        <span>{customer.phone}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-left space-y-2">
                    <div className="flex items-center gap-2">
                      <Package className="w-4 h-4 text-blue-600" />
                      <span className="font-medium">{customer.ordersCount} طلب</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <DollarSign className="w-4 h-4 text-green-600" />
                      <span className="font-medium text-green-600">{formatCurrency(customer.totalAmount)} د.ع</span>
                    </div>
                    <div className="text-sm text-gray-500">
                      آخر طلب: {formatDate(customer.lastOrderDate)}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
          
          {customers.length === 0 && (
            <Card>
              <CardContent className="p-8 text-center">
                <User className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-500 mb-2">لا توجد عملاء</h3>
                <p className="text-gray-400">لم يتم العثور على أي عملاء بعد</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};