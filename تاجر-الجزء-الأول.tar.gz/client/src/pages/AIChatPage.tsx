import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Send, Bot, User, MessageSquare, Search } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface ChatMessage {
  role: 'user' | 'ai';
  content: string;
  timestamp: any;
}

interface FAQItem {
  question: string;
  answer: string;
  category: string;
}

export default function AIChatPage() {
  const [question, setQuestion] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [userId] = useState(() => `user_${Date.now()}`);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();

  // جلب تاريخ المحادثات
  const { data: chatHistory = [], isLoading: isLoadingHistory } = useQuery({
    queryKey: ['/api/ai/chat-history', userId],
    queryFn: () => fetch(`/api/ai/chat-history/${userId}`).then(res => res.json()),
  });

  // جلب الأسئلة الشائعة
  const { data: faqList = [], isLoading: isLoadingFAQ } = useQuery({
    queryKey: ['/api/ai/faq'],
    queryFn: () => fetch('/api/ai/faq').then(res => res.json()),
  });

  // البحث في الأسئلة الشائعة
  const { data: searchResults = [], isLoading: isSearching } = useQuery({
    queryKey: ['/api/ai/faq/search', searchTerm],
    queryFn: () => searchTerm.trim() ? 
      fetch(`/api/ai/faq/search?q=${encodeURIComponent(searchTerm)}`).then(res => res.json()) : 
      [],
    enabled: !!searchTerm.trim(),
  });

  // إرسال سؤال جديد
  const askQuestionMutation = useMutation({
    mutationFn: (data: { question: string; userId: string }) => 
      apiRequest('/api/ai/ask', 'POST', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/ai/chat-history', userId] });
      setQuestion("");
    },
  });

  useEffect(() => {
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight;
    }
  }, [chatHistory]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (question.trim() && !askQuestionMutation.isPending) {
      askQuestionMutation.mutate({ question: question.trim(), userId });
    }
  };

  const handleFAQClick = (faqQuestion: string) => {
    setQuestion(faqQuestion);
  };

  const displayedFAQ = searchTerm.trim() ? searchResults : faqList;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 p-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-2">
            المساعد الذكي للتجارة الإلكترونية
          </h1>
          <p className="text-gray-600 dark:text-gray-300">
            اسأل أي سؤال حول التجارة الإلكترونية واحصل على إجابات ذكية ومفيدة
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* منطقة الدردشة */}
          <div className="lg:col-span-2">
            <Card className="h-[600px] flex flex-col">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="h-5 w-5" />
                  الدردشة مع المساعد الذكي
                </CardTitle>
              </CardHeader>
              <CardContent className="flex-1 flex flex-col p-0">
                <ScrollArea ref={scrollAreaRef} className="flex-1 p-4">
                  {isLoadingHistory ? (
                    <div className="flex justify-center py-8">
                      <div className="animate-pulse text-gray-500">جاري التحميل...</div>
                    </div>
                  ) : chatHistory.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      <Bot className="h-16 w-16 mx-auto mb-4 opacity-50" />
                      <p>مرحباً! أنا المساعد الذكي للتجارة الإلكترونية</p>
                      <p>اسأل أي سؤال وسأساعدك بإجابات مفيدة</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {chatHistory.map((message: ChatMessage, index: number) => (
                        <div
                          key={index}
                          className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                        >
                          <div
                            className={`max-w-[80%] rounded-lg p-3 ${
                              message.role === 'user'
                                ? 'bg-blue-500 text-white'
                                : 'bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-gray-100'
                            }`}
                          >
                            <div className="flex items-start gap-2">
                              {message.role === 'ai' ? (
                                <Bot className="h-4 w-4 mt-1 flex-shrink-0" />
                              ) : (
                                <User className="h-4 w-4 mt-1 flex-shrink-0" />
                              )}
                              <div className="whitespace-pre-wrap">{message.content}</div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
                
                <Separator />
                
                <form onSubmit={handleSubmit} className="p-4">
                  <div className="flex gap-2">
                    <Input
                      value={question}
                      onChange={(e) => setQuestion(e.target.value)}
                      placeholder="اكتب سؤالك هنا..."
                      disabled={askQuestionMutation.isPending}
                      className="flex-1"
                      dir="rtl"
                    />
                    <Button 
                      type="submit" 
                      disabled={!question.trim() || askQuestionMutation.isPending}
                      size="icon"
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* الأسئلة الشائعة */}
          <div className="lg:col-span-1">
            <Card className="h-[600px] flex flex-col">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Search className="h-5 w-5" />
                  الأسئلة الشائعة
                </CardTitle>
                <div className="mt-2">
                  <Input
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="ابحث في الأسئلة..."
                    dir="rtl"
                  />
                </div>
              </CardHeader>
              <CardContent className="flex-1 p-0">
                <ScrollArea className="h-full p-4">
                  {isLoadingFAQ || isSearching ? (
                    <div className="flex justify-center py-8">
                      <div className="animate-pulse text-gray-500">جاري التحميل...</div>
                    </div>
                  ) : displayedFAQ.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      {searchTerm.trim() ? 'لا توجد نتائج للبحث' : 'لا توجد أسئلة شائعة'}
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {displayedFAQ.map((faq: FAQItem, index: number) => (
                        <div key={index} className="border rounded-lg p-3 hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer transition-colors">
                          <div onClick={() => handleFAQClick(faq.question)}>
                            <Badge variant="secondary" className="mb-2 text-xs">
                              {faq.category}
                            </Badge>
                            <h4 className="font-medium text-sm mb-2 text-right">
                              {faq.question}
                            </h4>
                            <p className="text-xs text-gray-600 dark:text-gray-400 text-right line-clamp-2">
                              {faq.answer}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}