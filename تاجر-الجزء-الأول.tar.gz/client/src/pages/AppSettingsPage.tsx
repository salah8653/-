import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';
import { 
  Settings, 
  Globe, 
  Bell, 
  Shield, 
  Palette, 
  Database,
  Mail,
  Smartphone,
  CreditCard,
  Store,
  Users,
  Package,
  LogOut,
  ArrowLeft
} from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { useLocation } from 'wouter';

const settingsSchema = z.object({
  appName: z.string().min(1, 'اسم التطبيق مطلوب'),
  appDescription: z.string().optional(),
  currency: z.string().min(1, 'العملة مطلوبة'),
  language: z.string().min(1, 'اللغة مطلوبة'),
  enableNotifications: z.boolean(),
  enableEmailNotifications: z.boolean(),
  enableSMSNotifications: z.boolean(),
  maxOrdersPerDay: z.string(),
  allowGuestOrders: z.boolean(),
  requireEmailVerification: z.boolean(),
  enableUserRegistration: z.boolean(),
  maintenanceMode: z.boolean(),
  contactEmail: z.string().email('البريد الإلكتروني غير صحيح').optional().or(z.literal('')),
  contactPhone: z.string().optional(),
  supportEmail: z.string().email('البريد الإلكتروني غير صحيح').optional().or(z.literal('')),
  // إعدادات إضافية جديدة
  storeAddress: z.string().optional(),
  businessHours: z.string().optional(),
  taxRate: z.string().optional(),
  shippingCost: z.string().optional(),
  freeShippingThreshold: z.string().optional(),
  enableInventoryAlerts: z.boolean(),
  lowStockThreshold: z.string().optional(),
});

type SettingsFormData = z.infer<typeof settingsSchema>;

export const AppSettingsPage = () => {
  const { toast } = useToast();
  const { logout } = useAuth();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState('general');

  const handleLogout = () => {
    logout();
    toast({
      title: "تم تسجيل الخروج بنجاح",
      description: "شكراً لاستخدام تطبيق Zone",
    });
  };

  const form = useForm<SettingsFormData>({
    resolver: zodResolver(settingsSchema),
    defaultValues: {
      appName: 'Zone',
      appDescription: 'تطبيق التجارة الإلكترونية المتقدم',
      currency: 'IQD',
      language: 'ar',
      enableNotifications: true,
      enableEmailNotifications: true,
      enableSMSNotifications: false,
      maxOrdersPerDay: '100',
      allowGuestOrders: false,
      requireEmailVerification: true,
      enableUserRegistration: true,
      maintenanceMode: false,
      contactEmail: 'support@zone.com',
      contactPhone: '+964 770 123 4567',
      supportEmail: 'help@zone.com',
      // القيم الجديدة
      storeAddress: 'بغداد، العراق',
      businessHours: 'السبت - الخميس: 9:00 - 18:00',
      taxRate: '0',
      shippingCost: '5000',
      freeShippingThreshold: '50000',
      enableInventoryAlerts: true,
      lowStockThreshold: '10',
    },
  });

  const onSubmit = async (data: SettingsFormData) => {
    try {
      // محاكاة حفظ الإعدادات
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast({
        title: "تم حفظ الإعدادات بنجاح",
        description: "تم تطبيق جميع التغييرات على التطبيق",
      });
    } catch (error) {
      toast({
        title: "خطأ في حفظ الإعدادات",
        description: "حدث خطأ أثناء حفظ الإعدادات",
        variant: "destructive",
      });
    }
  };

  const tabs = [
    { id: 'general', label: 'الإعدادات العامة', icon: Settings },
    { id: 'store', label: 'إعدادات المتجر', icon: Store },
    { id: 'financial', label: 'الإعدادات المالية', icon: CreditCard },
    { id: 'notifications', label: 'الإشعارات', icon: Bell },
    { id: 'security', label: 'الأمان والخصوصية', icon: Shield },
    { id: 'integrations', label: 'التكاملات', icon: Globe },
  ];

  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
              <Settings className="w-6 h-6 text-purple-600" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-slate-900 mb-2">إعدادات التطبيق</h1>
              <p className="text-slate-600">التحكم في جميع جوانب وإعدادات تطبيق Zone</p>
            </div>
          </div>
          
          {/* Exit Button */}
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => setLocation('/store-management')}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="h-4 w-4" />
              العودة لإدارة المتجر
            </Button>
            
            <Button
              variant="outline"
              onClick={handleLogout}
              className="flex items-center gap-2 text-red-600 border-red-200 hover:bg-red-50 hover:border-red-300"
            >
              <LogOut className="w-4 h-4" />
              <span>تسجيل الخروج</span>
            </Button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Settings Navigation */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-lg">أقسام الإعدادات</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-right transition-colors ${
                    activeTab === tab.id
                      ? 'bg-purple-100 text-purple-700 border border-purple-200'
                      : 'hover:bg-slate-50 text-slate-600'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="text-sm font-medium">{tab.label}</span>
                </button>
              );
            })}
          </CardContent>
        </Card>

        {/* Settings Content */}
        <div className="lg:col-span-3">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              
              {/* General Settings */}
              {activeTab === 'general' && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Settings className="w-5 h-5" />
                      الإعدادات العامة
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="appName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>اسم التطبيق</FormLabel>
                            <FormControl>
                              <Input placeholder="اسم التطبيق" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="currency"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>العملة الافتراضية</FormLabel>
                            <FormControl>
                              <Input placeholder="IQD" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="appDescription"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>وصف التطبيق</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="وصف مختصر عن التطبيق" 
                              {...field} 
                              rows={3}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="contactEmail"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>البريد الإلكتروني للتواصل</FormLabel>
                            <FormControl>
                              <Input placeholder="contact@zone.com" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="contactPhone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>رقم الهاتف للتواصل</FormLabel>
                            <FormControl>
                              <Input placeholder="+964xxxxxxxxx" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Store Settings */}
              {activeTab === 'store' && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Store className="w-5 h-5" />
                      إعدادات المتجر
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="storeAddress"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>عنوان المتجر</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="أدخل عنوان المتجر الكامل"
                                {...field}
                                rows={3}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="businessHours"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>ساعات العمل</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="مثال: السبت - الخميس: 9:00 - 18:00"
                                {...field}
                                rows={3}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <FormField
                        control={form.control}
                        name="contactEmail"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>البريد الإلكتروني للتواصل</FormLabel>
                            <FormControl>
                              <Input
                                type="email"
                                placeholder="contact@store.com"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="contactPhone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>رقم الهاتف</FormLabel>
                            <FormControl>
                              <Input
                                type="tel"
                                placeholder="+964 770 123 4567"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="supportEmail"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>بريد الدعم الفني</FormLabel>
                            <FormControl>
                              <Input
                                type="email"
                                placeholder="support@store.com"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="enableInventoryAlerts"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-base">تنبيهات المخزون</FormLabel>
                            <FormDescription>
                              إرسال تنبيهات عند انخفاض المخزون
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch checked={field.value} onCheckedChange={field.onChange} />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="lowStockThreshold"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>حد التنبيه للمخزون المنخفض</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              placeholder="10"
                              {...field}
                            />
                          </FormControl>
                          <FormDescription>
                            عندما يصل المخزون لهذا الرقم سيتم إرسال تنبيه
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>
              )}

              {/* Financial Settings */}
              {activeTab === 'financial' && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <CreditCard className="w-5 h-5" />
                      الإعدادات المالية والشحن
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="currency"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>العملة الأساسية</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="IQD"
                                {...field}
                                disabled
                              />
                            </FormControl>
                            <FormDescription>
                              الدينار العراقي هو العملة الافتراضية
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="taxRate"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>معدل الضريبة (%)</FormLabel>
                            <FormControl>
                              <Input
                                type="number"
                                placeholder="0"
                                {...field}
                                min="0"
                                max="100"
                                step="0.1"
                              />
                            </FormControl>
                            <FormDescription>
                              اتركه 0 إذا كنت لا تحصل ضرائب
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <FormField
                        control={form.control}
                        name="shippingCost"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>تكلفة الشحن (دينار)</FormLabel>
                            <FormControl>
                              <Input
                                type="number"
                                placeholder="5000"
                                {...field}
                                min="0"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="freeShippingThreshold"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>حد الشحن المجاني (دينار)</FormLabel>
                            <FormControl>
                              <Input
                                type="number"
                                placeholder="50000"
                                {...field}
                                min="0"
                              />
                            </FormControl>
                            <FormDescription>
                              شحن مجاني للطلبات أكثر من هذا المبلغ
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="maxOrdersPerDay"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>الحد الأقصى للطلبات يومياً</FormLabel>
                            <FormControl>
                              <Input
                                type="number"
                                placeholder="100"
                                {...field}
                                min="1"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <h4 className="font-semibold text-blue-900 mb-2">معلومات مهمة</h4>
                      <ul className="text-sm text-blue-800 space-y-1">
                        <li>• جميع الأسعار بالدينار العراقي</li>
                        <li>• يمكن تغيير أسعار الشحن في أي وقت</li>
                        <li>• الشحن المجاني ينطبق تلقائياً عند تجاوز الحد المحدد</li>
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Appearance Settings */}
              {activeTab === 'appearance' && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Palette className="w-5 h-5" />
                      المظهر والتخصيص
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <h3 className="font-semibold text-slate-900">إعدادات اللون</h3>
                        <div className="grid grid-cols-3 gap-3">
                          <div className="w-full h-12 bg-purple-600 rounded-lg border-2 border-purple-300 cursor-pointer"></div>
                          <div className="w-full h-12 bg-blue-600 rounded-lg border cursor-pointer"></div>
                          <div className="w-full h-12 bg-green-600 rounded-lg border cursor-pointer"></div>
                        </div>
                      </div>
                      
                      <div className="space-y-4">
                        <h3 className="font-semibold text-slate-900">خط التطبيق</h3>
                        <div className="space-y-2">
                          <button className="w-full p-3 text-right border rounded-lg hover:bg-slate-50">
                            Cairo - القاهرة
                          </button>
                          <button className="w-full p-3 text-right border rounded-lg hover:bg-slate-50">
                            Tajawal - تجوال
                          </button>
                        </div>
                      </div>
                    </div>

                    <div className="border-t pt-6">
                      <h3 className="font-semibold text-slate-900 mb-4">معاينة التطبيق</h3>
                      <div className="bg-slate-100 rounded-lg p-6">
                        <div className="bg-white rounded-lg p-4 shadow-sm">
                          <div className="flex items-center gap-2 mb-3">
                            <div className="w-8 h-8 bg-purple-600 rounded-lg flex items-center justify-center">
                              <Store className="w-4 h-4 text-white" />
                            </div>
                            <span className="font-bold">Zone</span>
                          </div>
                          <p className="text-sm text-slate-600">مرحباً بك في متجر Zone</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Notifications Settings */}
              {activeTab === 'notifications' && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Bell className="w-5 h-5" />
                      إعدادات الإشعارات
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <FormField
                      control={form.control}
                      name="enableNotifications"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-base flex items-center gap-2">
                              <Bell className="w-4 h-4" />
                              تفعيل الإشعارات
                            </FormLabel>
                            <FormDescription>
                              تلقي إشعارات حول الطلبات الجديدة والتحديثات
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch checked={field.value} onCheckedChange={field.onChange} />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="enableEmailNotifications"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-base flex items-center gap-2">
                              <Mail className="w-4 h-4" />
                              إشعارات البريد الإلكتروني
                            </FormLabel>
                            <FormDescription>
                              إرسال إشعارات عبر البريد الإلكتروني
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch checked={field.value} onCheckedChange={field.onChange} />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="enableSMSNotifications"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-base flex items-center gap-2">
                              <Smartphone className="w-4 h-4" />
                              إشعارات الرسائل النصية
                            </FormLabel>
                            <FormDescription>
                              إرسال إشعارات عبر الرسائل النصية (SMS)
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch checked={field.value} onCheckedChange={field.onChange} />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>
              )}

              {/* Security Settings */}
              {activeTab === 'security' && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Shield className="w-5 h-5" />
                      الأمان والخصوصية
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <FormField
                      control={form.control}
                      name="requireEmailVerification"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-base">تأكيد البريد الإلكتروني</FormLabel>
                            <FormDescription>
                              يتطلب من المستخدمين تأكيد البريد الإلكتروني عند التسجيل
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch checked={field.value} onCheckedChange={field.onChange} />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="enableUserRegistration"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-base">السماح بالتسجيل</FormLabel>
                            <FormDescription>
                              السماح للمستخدمين الجدد بإنشاء حسابات
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch checked={field.value} onCheckedChange={field.onChange} />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="allowGuestOrders"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-base">طلبات الضيوف</FormLabel>
                            <FormDescription>
                              السماح للمستخدمين بالطلب بدون إنشاء حساب
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch checked={field.value} onCheckedChange={field.onChange} />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="maintenanceMode"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4 border-orange-200 bg-orange-50">
                          <div className="space-y-0.5">
                            <FormLabel className="text-base text-orange-800">وضع الصيانة</FormLabel>
                            <FormDescription className="text-orange-600">
                              تعطيل التطبيق مؤقتاً للصيانة
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch checked={field.value} onCheckedChange={field.onChange} />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>
              )}

              {/* Integrations Settings */}
              {activeTab === 'integrations' && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Globe className="w-5 h-5" />
                      التكاملات والخدمات الخارجية
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="border rounded-lg p-4">
                        <div className="flex items-center gap-3 mb-3">
                          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                            <CreditCard className="w-5 h-5 text-blue-600" />
                          </div>
                          <div>
                            <h3 className="font-semibold">بوابات الدفع</h3>
                            <p className="text-sm text-slate-600">تكامل مع بوابات الدفع</p>
                          </div>
                        </div>
                        <Button variant="outline" className="w-full">
                          إعداد بوابات الدفع
                        </Button>
                      </div>

                      <div className="border rounded-lg p-4">
                        <div className="flex items-center gap-3 mb-3">
                          <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                            <Smartphone className="w-5 h-5 text-green-600" />
                          </div>
                          <div>
                            <h3 className="font-semibold">خدمات الرسائل</h3>
                            <p className="text-sm text-slate-600">تكامل مع خدمات SMS</p>
                          </div>
                        </div>
                        <Button variant="outline" className="w-full">
                          إعداد خدمات الرسائل
                        </Button>
                      </div>

                      <div className="border rounded-lg p-4">
                        <div className="flex items-center gap-3 mb-3">
                          <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                            <Mail className="w-5 h-5 text-purple-600" />
                          </div>
                          <div>
                            <h3 className="font-semibold">خدمات البريد الإلكتروني</h3>
                            <p className="text-sm text-slate-600">تكامل مع SMTP</p>
                          </div>
                        </div>
                        <Button variant="outline" className="w-full">
                          إعداد البريد الإلكتروني
                        </Button>
                      </div>

                      <div className="border rounded-lg p-4">
                        <div className="flex items-center gap-3 mb-3">
                          <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                            <Database className="w-5 h-5 text-orange-600" />
                          </div>
                          <div>
                            <h3 className="font-semibold">النسخ الاحتياطي</h3>
                            <p className="text-sm text-slate-600">إعداد النسخ الاحتياطي</p>
                          </div>
                        </div>
                        <Button variant="outline" className="w-full">
                          إعداد النسخ الاحتياطي
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Save Button */}
              <div className="flex justify-end gap-3">
                <Button type="button" variant="outline">
                  إعادة تعيين
                </Button>
                <Button type="submit" className="bg-purple-600 hover:bg-purple-700">
                  حفظ الإعدادات
                </Button>
              </div>
            </form>
          </Form>
        </div>
      </div>
    </div>
  );
};