import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  CreditCard, 
  Clock, 
  Check, 
  X,
  Calendar,
  User,
  Phone,
  DollarSign,
  FileText,
  Edit,
  AlertCircle,
  Trash2
} from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';
import { useToast } from '@/hooks/use-toast';
import { useState } from 'react';

interface WithdrawRequest {
  id: string;
  userPhone: string;
  userName: string;
  amount: number;
  bankDetails: {
    bankName: string;
    accountNumber: string;
    accountHolderName: string;
  };
  status: 'pending' | 'completed' | 'rejected';
  rejectionReason?: string;
  createdAt: string;
  updatedAt?: string;
}

export const WithdrawManagementPage = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [editingRequest, setEditingRequest] = useState<WithdrawRequest | null>(null);
  const [newStatus, setNewStatus] = useState<string>('');
  const [rejectionReason, setRejectionReason] = useState<string>('');
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);

  const { data: withdrawRequests = [], isLoading } = useQuery({
    queryKey: ['/api/withdraw-requests'],
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status, rejectionReason }: { 
      id: string; 
      status: string; 
      rejectionReason?: string 
    }) => {
      const response = await fetch(`/api/withdraw-requests/${id}/status`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status, rejectionReason }),
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/withdraw-requests'] });
      toast({
        title: "تم التحديث بنجاح",
        description: "تم تحديث حالة طلب السحب",
      });
      setIsEditDialogOpen(false);
      setEditingRequest(null);
      setNewStatus('');
      setRejectionReason('');
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "حدث خطأ أثناء تحديث حالة الطلب",
        variant: "destructive",
      });
    },
  });

  const deleteWithdrawRequestMutation = useMutation({
    mutationFn: (id: string) => apiRequest('DELETE', `/api/withdraw-requests/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/withdraw-requests'] });
      toast({
        title: 'تم الحذف',
        description: 'تم حذف طلب السحب بنجاح',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'خطأ',
        description: error.message || 'حدث خطأ أثناء حذف طلب السحب',
        variant: 'destructive',
      });
    },
  });

  const filteredRequests = (withdrawRequests as WithdrawRequest[]).filter((request) => {
    if (selectedStatus === 'all') return true;
    return request.status === selectedStatus;
  });

  const handleEditStatus = (request: WithdrawRequest) => {
    setEditingRequest(request);
    setNewStatus(request.status);
    setRejectionReason(request.rejectionReason || '');
    setIsEditDialogOpen(true);
  };

  const handleUpdateStatus = () => {
    if (!editingRequest || !newStatus) return;

    updateStatusMutation.mutate({
      id: editingRequest.id,
      status: newStatus,
      rejectionReason: newStatus === 'rejected' ? rejectionReason : undefined,
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-800">قيد المعالجة</Badge>;
      case 'completed':
        return <Badge className="bg-green-100 text-green-800">مكتمل</Badge>;
      case 'rejected':
        return <Badge className="bg-red-100 text-red-800">مرفوض</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="text-center">جاري التحميل...</div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">إدارة طلبات السحب</h1>
        
        <Select value={selectedStatus} onValueChange={setSelectedStatus}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="تصفية حسب الحالة" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">جميع الطلبات</SelectItem>
            <SelectItem value="pending">قيد المعالجة</SelectItem>
            <SelectItem value="completed">مكتملة</SelectItem>
            <SelectItem value="rejected">مرفوضة</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* إحصائيات */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">الطلبات المعلقة</p>
                <p className="text-2xl font-bold text-yellow-600">
                  {(withdrawRequests as WithdrawRequest[]).filter((r: WithdrawRequest) => r.status === 'pending').length}
                </p>
              </div>
              <Clock className="w-8 h-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">الطلبات المكتملة</p>
                <p className="text-2xl font-bold text-green-600">
                  {(withdrawRequests as WithdrawRequest[]).filter((r: WithdrawRequest) => r.status === 'completed').length}
                </p>
              </div>
              <Check className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">الطلبات المرفوضة</p>
                <p className="text-2xl font-bold text-red-600">
                  {(withdrawRequests as WithdrawRequest[]).filter((r: WithdrawRequest) => r.status === 'rejected').length}
                </p>
              </div>
              <X className="w-8 h-8 text-red-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">إجمالي الطلبات</p>
                <p className="text-2xl font-bold text-purple-600">
                  {(withdrawRequests as WithdrawRequest[]).length}
                </p>
              </div>
              <CreditCard className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* قائمة طلبات السحب */}
      <div className="space-y-4">
        {filteredRequests.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-gray-500">لا توجد طلبات سحب</p>
            </CardContent>
          </Card>
        ) : (
          filteredRequests.map((request: WithdrawRequest) => (
            <Card key={request.id}>
              <CardContent className="p-6">
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  <div className="space-y-3">
                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-2">
                        <User className="w-4 h-4 text-gray-500" />
                        <span className="font-semibold">{request.userName}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Phone className="w-4 h-4 text-gray-500" />
                        <span className="text-sm text-gray-600">{request.userPhone}</span>
                      </div>
                      {getStatusBadge(request.status)}
                    </div>

                    <div className="flex items-center gap-4 text-sm text-gray-600">
                      <div className="flex items-center gap-2">
                        <DollarSign className="w-4 h-4" />
                        <span>{request.amount.toLocaleString()} د.ع</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        <span>
                          {format(new Date(request.createdAt), 'dd/MM/yyyy HH:mm', { locale: ar })}
                        </span>
                      </div>
                    </div>

                    {/* تفاصيل البنك */}
                    {request.bankDetails && (
                      <div className="bg-gray-50 p-3 rounded-lg">
                        <p className="text-sm font-medium text-gray-700 mb-2">تفاصيل البنك:</p>
                        <div className="space-y-1 text-sm text-gray-600">
                          <p><strong>البنك:</strong> {request.bankDetails.bankName || 'غير محدد'}</p>
                          <p><strong>رقم الحساب:</strong> {request.bankDetails.accountNumber || 'غير محدد'}</p>
                          <p><strong>اسم صاحب الحساب:</strong> {request.bankDetails.accountHolderName || 'غير محدد'}</p>
                        </div>
                      </div>
                    )}

                    {/* سبب الرفض */}
                    {request.status === 'rejected' && request.rejectionReason && (
                      <div className="bg-red-50 p-3 rounded-lg">
                        <div className="flex items-center gap-2 mb-2">
                          <AlertCircle className="w-4 h-4 text-red-500" />
                          <p className="text-sm font-medium text-red-700">سبب الرفض:</p>
                        </div>
                        <p className="text-sm text-red-600">{request.rejectionReason}</p>
                      </div>
                    )}
                  </div>

                  <div className="flex gap-2">
                    <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
                      <DialogTrigger asChild>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEditStatus(request)}
                          className="flex items-center gap-2"
                        >
                          <Edit className="w-4 h-4" />
                          تحديث الحالة
                        </Button>
                      </DialogTrigger>
                      
                    {/* زر حذف طلب السحب */}
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="destructive" size="sm" className="flex items-center gap-2">
                          <Trash2 className="w-4 h-4" />
                          حذف
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>تأكيد حذف طلب السحب</AlertDialogTitle>
                          <AlertDialogDescription>
                            هل أنت متأكد من حذف طلب السحب هذا؟ هذا الإجراء لا يمكن التراجع عنه.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>إلغاء</AlertDialogCancel>
                          <AlertDialogAction 
                            onClick={() => deleteWithdrawRequestMutation.mutate(request.id)}
                            className="bg-red-600 hover:bg-red-700"
                          >
                            حذف
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>تحديث حالة طلب السحب</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="status">الحالة الجديدة</Label>
                            <Select value={newStatus} onValueChange={setNewStatus}>
                              <SelectTrigger>
                                <SelectValue placeholder="اختر الحالة" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="pending">قيد المعالجة</SelectItem>
                                <SelectItem value="completed">مكتمل</SelectItem>
                                <SelectItem value="rejected">مرفوض</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          {newStatus === 'rejected' && (
                            <div>
                              <Label htmlFor="rejectionReason">سبب الرفض</Label>
                              <Textarea
                                id="rejectionReason"
                                value={rejectionReason}
                                onChange={(e) => setRejectionReason(e.target.value)}
                                placeholder="اكتب سبب رفض الطلب..."
                                className="min-h-[80px]"
                              />
                            </div>
                          )}

                          <div className="flex gap-2 justify-end">
                            <Button
                              variant="outline"
                              onClick={() => setIsEditDialogOpen(false)}
                            >
                              إلغاء
                            </Button>
                            <Button
                              onClick={handleUpdateStatus}
                              disabled={updateStatusMutation.isPending || !newStatus}
                              className="bg-purple-600 hover:bg-purple-700"
                            >
                              {updateStatusMutation.isPending ? 'جاري الحفظ...' : 'حفظ التغييرات'}
                            </Button>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};