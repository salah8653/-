import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ChevronRight, User, Phone, MapPin, FileText, Gift } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

interface CartItem {
  id: number;
  productId: number;
  quantity: number;
  product: {
    id: number;
    name: string;
    price: string;
    imageUrl: string;
    description: string;
    minPrice?: string;
    maxPrice?: string;
  };
}

export const CheckoutPage = () => {
  const { language, t, dir } = useLanguage();
  const [, setLocation] = useLocation();
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [customerPrice, setCustomerPrice] = useState(0);
  const [cartData, setCartData] = useState<any>(null);
  const [currentStep, setCurrentStep] = useState(1);
  const [deliveryFee, setDeliveryFee] = useState(0);
  const [customerInfo, setCustomerInfo] = useState({
    name: '',
    phone: '',
    governorate: '',
    area: '',
    address: '',
    notes: ''
  });


  useEffect(() => {
    fetchCartData();
  }, []);

  const fetchCartData = async () => {
    try {
      // جلب بيانات السلة
      const cartResponse = await fetch('/api/cart');
      if (cartResponse.ok) {
        const cartItems = await cartResponse.json();
        setCartItems(cartItems);
      }

      // جلب سعر الزبون المحفوظ من localStorage
      const savedPrice = localStorage.getItem('customerPrice');
      if (savedPrice) {
        setCustomerPrice(parseFloat(savedPrice));
      }
    } catch (error) {
      console.error('خطأ في جلب بيانات السلة:', error);
    }
  };

  const getWholesaleTotal = () => {
    return cartItems.reduce((total, item) => {
      return total + (parseFloat(item.product.price) * item.quantity);
    }, 0);
  };

  const getProfit = () => {
    const wholesaleTotal = getWholesaleTotal();
    const profit = customerPrice - wholesaleTotal;
    return profit < 0 ? 0 : profit;
  };

  const calculateDeliveryFee = (governorate: string) => {
    if (governorate.toLowerCase().includes('بغداد')) {
      return 4000;
    }
    return 5000;
  };

  const getTotalWithDelivery = () => {
    return customerPrice + deliveryFee;
  };

  const handleGovernorateChange = (value: string) => {
    setCustomerInfo(prev => ({ ...prev, governorate: value }));
    const fee = calculateDeliveryFee(value);
    setDeliveryFee(fee);
  };

  const handleNextStep = () => {
    // حفظ البيانات في localStorage للصفحة التالية
    localStorage.setItem('deliveryFee', deliveryFee.toString());
    localStorage.setItem('customerInfo', JSON.stringify(customerInfo));
    
    // الانتقال لصفحة تثبيت الطلب
    setLocation('/order-confirmation');
  };

  const governorates = [
    'بغداد', 'البصرة', 'نينوى', 'أربيل', 'النجف', 'كربلاء', 'الأنبار', 'دهوك', 'ديالى', 'بابل',
    'كركوك', 'واسط', 'صلاح الدين', 'المثنى', 'القادسية', 'ذي قار', 'ميسان', 'السليمانية'
  ];

  const isValidPhoneNumber = (phone: string) => {
    // التحقق من أن رقم الهاتف يحتوي على 11 رقماً فقط
    const phoneRegex = /^[0-9]{11}$/;
    return phoneRegex.test(phone);
  };

  const isFormValid = customerInfo.name && isValidPhoneNumber(customerInfo.phone) && 
                     customerInfo.governorate && customerInfo.area && customerInfo.address && 
                     customerPrice > 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-white" dir={dir}>
      {/* Header */}
      <div className="bg-white border-b border-purple-100 px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLocation('/cart')}
              className="p-1"
            >
              <ChevronRight className="w-5 h-5" />
            </Button>
            <h1 className="text-lg font-semibold text-gray-800">
              {language === 'ar' ? 'إتمام الشراء' : 'Complete Purchase'}
            </h1>
          </div>
          <div className="flex items-center gap-2 text-sm text-purple-600">
            <span className="bg-purple-100 text-purple-700 px-2 py-1 rounded-full text-xs font-medium">
              {language === 'ar' ? 'الخطوة 2' : 'Step 2'}
            </span>
          </div>
        </div>
      </div>

      {/* Progress Steps */}
      <div className="px-4 py-6">
        <div className="flex items-center justify-center gap-4 mb-8">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-orange-500 text-white rounded-full flex items-center justify-center text-sm font-bold">
              1
            </div>
            <span className="text-sm font-medium text-gray-600">
              {language === 'ar' ? 'التوصيل' : 'Delivery'}
            </span>
          </div>
          <div className="w-12 h-1 bg-orange-500 rounded"></div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gray-300 text-gray-600 rounded-full flex items-center justify-center text-sm font-bold">
              2
            </div>
            <span className="text-sm font-medium text-gray-600">
              {language === 'ar' ? 'تثبيت الطلب' : 'Confirm Order'}
            </span>
          </div>
        </div>

        <div className="space-y-6">
          {/* Customer Name */}
          <Card className="bg-white rounded-2xl shadow-sm border border-purple-100">
            <CardContent className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <User className="w-5 h-5 text-orange-500" />
                <Label className="text-lg font-semibold text-gray-800">
                  {language === 'ar' ? 'اسم الزبون' : 'Customer Name'}
                </Label>
              </div>
              <Input
                value={customerInfo.name}
                onChange={(e) => setCustomerInfo(prev => ({ ...prev, name: e.target.value }))}
                placeholder={language === 'ar' ? 'أدخل اسم الزبون' : 'Enter customer name'}
                className="text-lg border-gray-200 focus:border-purple-400 focus:ring-purple-400"
              />
            </CardContent>
          </Card>

          {/* Phone Number */}
          <Card className="bg-white rounded-2xl shadow-sm border border-purple-100">
            <CardContent className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <Phone className="w-5 h-5 text-orange-500" />
                <Label className="text-lg font-semibold text-gray-800">
                  {language === 'ar' ? 'رقم الهاتف (11 رقماً)' : 'Phone Number (11 digits)'}
                </Label>
              </div>
              <Input
                type="tel"
                value={customerInfo.phone}
                onChange={(e) => {
                  const value = e.target.value.replace(/[^0-9]/g, '');
                  if (value.length <= 11) {
                    setCustomerInfo(prev => ({ ...prev, phone: value }));
                  }
                }}
                placeholder="07722222222"
                className="text-lg border-gray-200 focus:border-purple-400 focus:ring-purple-400"
                dir="ltr"
                maxLength={11}
              />
              <p className="text-sm text-gray-500 mt-1">
                {language === 'ar' ? `أدخل ${customerInfo.phone.length}/11 رقماً` : `Enter ${customerInfo.phone.length}/11 digits`}
              </p>
            </CardContent>
          </Card>

          {/* Governorate */}
          <Card className="bg-white rounded-2xl shadow-sm border border-purple-100">
            <CardContent className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <MapPin className="w-5 h-5 text-orange-500" />
                <Label className="text-lg font-semibold text-gray-800">محافظة الزبون</Label>
              </div>
              <Select value={customerInfo.governorate} onValueChange={(value) => 
                handleGovernorateChange(value)
              }>
                <SelectTrigger className="text-lg border-gray-200 focus:border-purple-400 focus:ring-purple-400">
                  <SelectValue placeholder="اختر المحافظة" />
                </SelectTrigger>
                <SelectContent>
                  {governorates.map((gov) => (
                    <SelectItem key={gov} value={gov}>{gov}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardContent>
          </Card>

          {/* Area */}
          <Card className="bg-white rounded-2xl shadow-sm border border-purple-100">
            <CardContent className="p-6">
              <Label className="text-lg font-semibold text-gray-800 block mb-4">المنطقة</Label>
              <Input
                value={customerInfo.area}
                onChange={(e) => setCustomerInfo(prev => ({ ...prev, area: e.target.value }))}
                placeholder="مثال: بغداد المنصور"
                className="text-lg border-gray-200 focus:border-purple-400 focus:ring-purple-400"
              />
            </CardContent>
          </Card>

          {/* Address */}
          <Card className="bg-white rounded-2xl shadow-sm border border-purple-100">
            <CardContent className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <MapPin className="w-5 h-5 text-orange-500" />
                <Label className="text-lg font-semibold text-gray-800">أقرب نقطة دالة</Label>
              </div>
              <Input
                value={customerInfo.address}
                onChange={(e) => setCustomerInfo(prev => ({ ...prev, address: e.target.value }))}
                placeholder="مثال: قرب جامعة بغداد"
                className="text-lg border-gray-200 focus:border-purple-400 focus:ring-purple-400"
              />
            </CardContent>
          </Card>

          {/* Notes */}
          <Card className="bg-white rounded-2xl shadow-sm border border-purple-100">
            <CardContent className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <FileText className="w-5 h-5 text-orange-500" />
                <Label className="text-lg font-semibold text-gray-800">الملاحظات</Label>
              </div>
              <Input
                value={customerInfo.notes}
                onChange={(e) => setCustomerInfo(prev => ({ ...prev, notes: e.target.value }))}
                placeholder="مثال: اللون الأسود، وقت التسليم الساعة 4 عصراً"
                className="text-lg border-gray-200 focus:border-purple-400 focus:ring-purple-400"
              />
            </CardContent>
          </Card>
        </div>

        {/* Submit Button */}
        <div className="mt-8">
          <Button
            onClick={handleNextStep}
            disabled={!isFormValid}
            className="w-full bg-orange-500 hover:bg-orange-600 text-white py-4 text-lg font-bold rounded-2xl disabled:bg-gray-300"
          >
            {language === 'ar' ? 'التالي' : 'Next'}
          </Button>
        </div>
      </div>
    </div>
  );
};