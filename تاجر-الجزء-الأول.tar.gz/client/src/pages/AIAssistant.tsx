import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useMutation } from '@tanstack/react-query';
import { Brain, TrendingUp, Users, MessageSquare, FileText, Sparkles, BarChart3, Search, ArrowLeft } from 'lucide-react';
import { useLocation } from 'wouter';

export default function AIAssistant() {
  const [, setLocation] = useLocation();
  const [productName, setProductName] = useState('');
  const [productCategory, setProductCategory] = useState('');
  const [productPrice, setProductPrice] = useState('');
  const [customerQuestion, setCustomerQuestion] = useState('');
  const [sentimentText, setSentimentText] = useState('');
  const [salesAnalysis, setSalesAnalysis] = useState<any>(null);
  const [generatedDescription, setGeneratedDescription] = useState('');
  const [customerBehavior, setCustomerBehavior] = useState<any>(null);
  const [customerResponse, setCustomerResponse] = useState('');
  const [sentimentResult, setSentimentResult] = useState<any>(null);
  const [appPerformance, setAppPerformance] = useState<any>(null);
  const [userBaseAnalysis, setUserBaseAnalysis] = useState<any>(null);
  const { toast } = useToast();

  // تحليل المبيعات
  const salesAnalysisMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/ai/analyze-sales');
      return await response.json();
    },
    onSuccess: (data: any) => {
      console.log('بيانات تحليل المبيعات:', data);
      setSalesAnalysis(data);
      toast({
        title: 'تم التحليل',
        description: 'تم تحليل بيانات المبيعات بنجاح'
      });
    },
    onError: (error: any) => {
      console.error('خطأ في تحليل المبيعات:', error);
      toast({
        title: 'خطأ',
        description: 'فشل في تحليل البيانات',
        variant: 'destructive'
      });
    }
  });

  // إنشاء وصف المنتج
  const generateDescriptionMutation = useMutation({
    mutationFn: async (data: { productName: string; category: string; price: number }) => {
      const response = await apiRequest('POST', '/api/ai/generate-description', data);
      return await response.json();
    },
    onSuccess: (data: any) => {
      console.log('بيانات وصف المنتج:', data);
      setGeneratedDescription(data.description);
      toast({
        title: 'تم الإنشاء',
        description: 'تم إنشاء وصف المنتج بنجاح'
      });
    },
    onError: () => {
      toast({
        title: 'خطأ',
        description: 'فشل في إنشاء الوصف. تأكد من إعداد مفتاح OpenAI',
        variant: 'destructive'
      });
    }
  });

  // تحليل سلوك العملاء
  const customerBehaviorMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/ai/analyze-customers');
      return await response.json();
    },
    onSuccess: (data: any) => {
      setCustomerBehavior(data);
      toast({
        title: 'تم التحليل',
        description: 'تم تحليل سلوك العملاء بنجاح'
      });
    },
    onError: () => {
      toast({
        title: 'خطأ',
        description: 'فشل في تحليل سلوك العملاء',
        variant: 'destructive'
      });
    }
  });

  // مساعد خدمة العملاء
  const customerServiceMutation = useMutation({
    mutationFn: async (data: { question: string; context?: string }) => {
      const response = await apiRequest('POST', '/api/ai/customer-support', data);
      return await response.json();
    },
    onSuccess: (data: any) => {
      setCustomerResponse(data.response);
      toast({
        title: 'تم إنشاء الرد',
        description: 'تم إنشاء رد العميل بنجاح'
      });
    },
    onError: () => {
      toast({
        title: 'خطأ',
        description: 'فشل في إنشاء رد العميل',
        variant: 'destructive'
      });
    }
  });

  // تحليل المشاعر
  const sentimentAnalysisMutation = useMutation({
    mutationFn: async (data: { text: string }) => {
      const response = await apiRequest('POST', '/api/ai/sentiment-analysis', data);
      return await response.json();
    },
    onSuccess: (data: any) => {
      setSentimentResult(data);
      toast({
        title: 'تم التحليل',
        description: 'تم تحليل المشاعر بنجاح'
      });
    },
    onError: () => {
      toast({
        title: 'خطأ',
        description: 'فشل في تحليل المشاعر',
        variant: 'destructive'
      });
    }
  });

  // تحليل أداء التطبيق الشامل
  const appPerformanceMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/ai/analyze-app-performance');
      return await response.json();
    },
    onSuccess: (data: any) => {
      setAppPerformance(data);
      toast({
        title: 'تم التحليل',
        description: 'تم تحليل أداء التطبيق بنجاح'
      });
    },
    onError: (error: any) => {
      console.error('خطأ في تحليل أداء التطبيق:', error);
      toast({
        title: 'خطأ',
        description: 'فشل في تحليل أداء التطبيق',
        variant: 'destructive'
      });
    }
  });

  // تحليل قاعدة المستخدمين
  const userBaseAnalysisMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/ai/analyze-user-base');
      return await response.json();
    },
    onSuccess: (data: any) => {
      setUserBaseAnalysis(data);
      toast({
        title: 'تم التحليل',
        description: 'تم تحليل قاعدة المستخدمين بنجاح'
      });
    },
    onError: (error: any) => {
      console.error('خطأ في تحليل قاعدة المستخدمين:', error);
      toast({
        title: 'خطأ',
        description: 'فشل في تحليل قاعدة المستخدمين',
        variant: 'destructive'
      });
    }
  });

  const handleGenerateDescription = () => {
    if (!productName || !productCategory || !productPrice) {
      toast({
        title: 'معلومات ناقصة',
        description: 'يرجى ملء جميع حقول المنتج',
        variant: 'destructive'
      });
      return;
    }

    generateDescriptionMutation.mutate({
      productName,
      category: productCategory,
      price: parseFloat(productPrice)
    });
  };

  const handleCustomerService = () => {
    if (!customerQuestion) {
      toast({
        title: 'معلومات ناقصة',
        description: 'يرجى إدخال سؤال العميل',
        variant: 'destructive'
      });
      return;
    }

    customerServiceMutation.mutate({
      question: customerQuestion,
      context: 'متجر إلكتروني عربي'
    });
  };

  const handleSentimentAnalysis = () => {
    if (!sentimentText) {
      toast({
        title: 'معلومات ناقصة',
        description: 'يرجى إدخال النص للتحليل',
        variant: 'destructive'
      });
      return;
    }

    sentimentAnalysisMutation.mutate({ text: sentimentText });
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3 space-x-reverse">
          <Brain className="w-8 h-8 text-purple-600" />
          <div>
            <h1 className="text-3xl font-bold text-gray-900">مساعد الذكاء الاصطناعي</h1>
            <p className="text-gray-600">استخدم قوة الذكاء الاصطناعي لتحسين أداء متجرك</p>
          </div>
        </div>
        
        <Button 
          variant="ghost" 
          size="sm"
          onClick={() => setLocation('/store-management')}
          className="flex items-center gap-2"
        >
          <ArrowLeft className="h-4 w-4" />
          العودة لإدارة المتجر
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* تحليل أداء المبيعات */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 space-x-reverse">
              <TrendingUp className="w-5 h-5 text-green-600" />
              <span>تحليل أداء المبيعات</span>
            </CardTitle>
            <CardDescription>
              احصل على رؤى ذكية حول أداء مبيعاتك وتوصيات للتحسين
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button
              onClick={() => salesAnalysisMutation.mutate()}
              disabled={salesAnalysisMutation.isPending}
              className="w-full"
            >
              {salesAnalysisMutation.isPending ? 'جاري التحليل...' : 'تحليل المبيعات'}
            </Button>
            
            {salesAnalysis && (
              <div className="bg-green-50 p-4 rounded-lg">
                <h4 className="font-semibold text-green-800 mb-2">نتائج التحليل:</h4>
                <div className="space-y-2 text-sm text-green-700">
                  {salesAnalysis.insights && salesAnalysis.insights.length > 0 ? (
                    salesAnalysis.insights.map((insight: string, index: number) => (
                      <p key={index}>• {insight}</p>
                    ))
                  ) : (
                    <p>• {salesAnalysis.summary || 'تم تحليل البيانات بنجاح'}</p>
                  )}
                </div>
                {salesAnalysis.recommendations && salesAnalysis.recommendations.length > 0 && (
                  <div className="mt-3">
                    <h5 className="font-medium text-green-800">التوصيات:</h5>
                    {salesAnalysis.recommendations.map((rec: string, index: number) => (
                      <p key={index} className="text-sm text-green-700">• {rec}</p>
                    ))}
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* مولد أوصاف المنتجات */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 space-x-reverse">
              <FileText className="w-5 h-5 text-blue-600" />
              <span>مولد أوصاف المنتجات</span>
            </CardTitle>
            <CardDescription>
              أنشئ أوصافاً جذابة ومهنية لمنتجاتك تلقائياً
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Input
              placeholder="اسم المنتج"
              value={productName}
              onChange={(e) => setProductName(e.target.value)}
            />
            <Input
              placeholder="فئة المنتج"
              value={productCategory}
              onChange={(e) => setProductCategory(e.target.value)}
            />
            <Input
              placeholder="السعر (دينار)"
              type="number"
              value={productPrice}
              onChange={(e) => setProductPrice(e.target.value)}
            />
            <Button
              onClick={handleGenerateDescription}
              disabled={generateDescriptionMutation.isPending}
              className="w-full"
            >
              {generateDescriptionMutation.isPending ? 'جاري الإنشاء...' : 'إنشاء الوصف'}
            </Button>
            
            {generatedDescription && (
              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-semibold text-blue-800 mb-2">الوصف المُنشأ:</h4>
                <p className="text-blue-700 text-sm leading-relaxed">{generatedDescription}</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* تحليل سلوك العملاء */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 space-x-reverse">
              <Users className="w-5 h-5 text-purple-600" />
              <span>تحليل سلوك العملاء</span>
            </CardTitle>
            <CardDescription>
              فهم أعمق لسلوك عملائك وتوقعاتهم
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button
              onClick={() => customerBehaviorMutation.mutate()}
              disabled={customerBehaviorMutation.isPending}
              className="w-full"
            >
              {customerBehaviorMutation.isPending ? 'جاري التحليل...' : 'تحليل سلوك العملاء'}
            </Button>
            
            {customerBehavior && (
              <div className="bg-purple-50 p-4 rounded-lg">
                <h4 className="font-semibold text-purple-800 mb-2">تحليل السلوك:</h4>
                <div className="space-y-2 text-sm text-purple-700">
                  {customerBehavior.patterns && customerBehavior.patterns.length > 0 ? (
                    customerBehavior.patterns.map((pattern: string, index: number) => (
                      <p key={index}>• {pattern}</p>
                    ))
                  ) : (
                    <p>• {customerBehavior.summary || 'تم تحليل سلوك العملاء بنجاح'}</p>
                  )}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* مساعد خدمة العملاء */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 space-x-reverse">
              <MessageSquare className="w-5 h-5 text-orange-600" />
              <span>مساعد خدمة العملاء</span>
            </CardTitle>
            <CardDescription>
              احصل على ردود ذكية ومهنية لاستفسارات العملاء
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea
              placeholder="اكتب سؤال العميل هنا..."
              value={customerQuestion}
              onChange={(e) => setCustomerQuestion(e.target.value)}
              rows={3}
            />
            <Button
              onClick={handleCustomerService}
              disabled={customerServiceMutation.isPending}
              className="w-full"
            >
              {customerServiceMutation.isPending ? 'جاري إنشاء الرد...' : 'إنشاء رد ذكي'}
            </Button>
            
            {customerResponse && (
              <div className="bg-orange-50 p-4 rounded-lg">
                <h4 className="font-semibold text-orange-800 mb-2">الرد المقترح:</h4>
                <p className="text-orange-700 text-sm leading-relaxed">{customerResponse}</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* تحليل المشاعر */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 space-x-reverse">
            <Search className="w-5 h-5 text-indigo-600" />
            <span>تحليل المشاعر</span>
          </CardTitle>
          <CardDescription>
            حلل مشاعر النصوص والتعليقات لفهم آراء العملاء
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            placeholder="أدخل النص للتحليل (تعليق، مراجعة، رسالة عميل...)"
            value={sentimentText}
            onChange={(e) => setSentimentText(e.target.value)}
            rows={3}
          />
          <Button
            onClick={handleSentimentAnalysis}
            disabled={sentimentAnalysisMutation.isPending}
            className="w-full"
          >
            {sentimentAnalysisMutation.isPending ? 'جاري تحليل المشاعر...' : 'تحليل المشاعر'}
          </Button>
          
          {sentimentResult && (
            <div className="bg-indigo-50 p-4 rounded-lg">
              <h4 className="font-semibold text-indigo-800 mb-2">نتيجة التحليل:</h4>
              <div className="space-y-2">
                <div className="flex items-center space-x-2 space-x-reverse">
                  <span className="text-indigo-700 text-sm">التقييم:</span>
                  <div className="flex space-x-1 space-x-reverse">
                    {[...Array(5)].map((_, i) => (
                      <span
                        key={i}
                        className={`text-lg ${
                          i < (sentimentResult.rating || 0) ? 'text-yellow-400' : 'text-gray-300'
                        }`}
                      >
                        ★
                      </span>
                    ))}
                  </div>
                  <Badge variant="secondary" className="mr-2">
                    {sentimentResult.rating || 0}/5
                  </Badge>
                </div>
                <div className="flex items-center space-x-2 space-x-reverse">
                  <span className="text-indigo-700 text-sm">الثقة:</span>
                  <Badge variant="outline">
                    {Math.round((sentimentResult.confidence || 0) * 100)}%
                  </Badge>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* الميزات المتقدمة لإدارة التطبيق */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* تحليل أداء التطبيق الشامل */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 space-x-reverse">
              <BarChart3 className="w-5 h-5 text-blue-600" />
              <span>تحليل أداء التطبيق الشامل</span>
            </CardTitle>
            <CardDescription>
              تحليل متقدم لأداء التطبيق، المستخدمين، الأرباح والتشغيل
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button 
              onClick={() => appPerformanceMutation.mutate()} 
              disabled={appPerformanceMutation.isPending}
              className="w-full"
            >
              {appPerformanceMutation.isPending ? 'جاري التحليل...' : 'تحليل الأداء الشامل'}
            </Button>
            
            {appPerformance && (
              <div className="bg-blue-50 p-4 rounded-lg space-y-4">
                <h4 className="font-semibold text-blue-800 mb-2">تقرير الأداء الشامل:</h4>
                
                {/* صحة الأعمال */}
                <div>
                  <h5 className="font-medium text-blue-700 mb-1">صحة الأعمال:</h5>
                  <div className="space-y-1 text-sm text-blue-600">
                    {appPerformance.businessHealth?.map((item: string, index: number) => (
                      <p key={index}>• {item}</p>
                    ))}
                  </div>
                </div>

                {/* تفاعل المستخدمين */}
                <div>
                  <h5 className="font-medium text-blue-700 mb-1">تفاعل المستخدمين:</h5>
                  <div className="space-y-1 text-sm text-blue-600">
                    {appPerformance.userEngagement?.map((item: string, index: number) => (
                      <p key={index}>• {item}</p>
                    ))}
                  </div>
                </div>

                {/* تحليل الإيرادات */}
                <div>
                  <h5 className="font-medium text-blue-700 mb-1">تحليل الإيرادات:</h5>
                  <div className="space-y-1 text-sm text-blue-600">
                    {appPerformance.revenueAnalysis?.map((item: string, index: number) => (
                      <p key={index}>• {item}</p>
                    ))}
                  </div>
                </div>

                {/* التوصيات الاستراتيجية */}
                <div>
                  <h5 className="font-medium text-green-700 mb-1">التوصيات الاستراتيجية:</h5>
                  <div className="space-y-1 text-sm text-green-600">
                    {appPerformance.strategicRecommendations?.map((item: string, index: number) => (
                      <p key={index}>• {item}</p>
                    ))}
                  </div>
                </div>

                {/* تقييم المخاطر */}
                <div>
                  <h5 className="font-medium text-red-700 mb-1">تقييم المخاطر:</h5>
                  <div className="space-y-1 text-sm text-red-600">
                    {appPerformance.riskAssessment?.map((item: string, index: number) => (
                      <p key={index}>• {item}</p>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* إدارة المستخدمين الذكية */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 space-x-reverse">
              <Users className="w-5 h-5 text-purple-600" />
              <span>إدارة المستخدمين الذكية</span>
            </CardTitle>
            <CardDescription>
              تحليل شامل لقاعدة المستخدمين مع توصيات ذكية
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button 
              onClick={() => userBaseAnalysisMutation.mutate()} 
              disabled={userBaseAnalysisMutation.isPending}
              className="w-full"
            >
              {userBaseAnalysisMutation.isPending ? 'جاري التحليل...' : 'تحليل المستخدمين'}
            </Button>
            
            {userBaseAnalysis && (
              <div className="bg-purple-50 p-4 rounded-lg space-y-4">
                <h4 className="font-semibold text-purple-800 mb-2">تقرير إدارة المستخدمين:</h4>
                
                {/* البيانات الديموغرافية */}
                <div>
                  <h5 className="font-medium text-purple-700 mb-1">البيانات الديموغرافية:</h5>
                  <div className="space-y-1 text-sm text-purple-600">
                    {userBaseAnalysis.demographics?.map((item: string, index: number) => (
                      <p key={index}>• {item}</p>
                    ))}
                  </div>
                </div>

                {/* أنماط السلوك */}
                <div>
                  <h5 className="font-medium text-purple-700 mb-1">أنماط السلوك:</h5>
                  <div className="space-y-1 text-sm text-purple-600">
                    {userBaseAnalysis.behaviorPatterns?.map((item: string, index: number) => (
                      <p key={index}>• {item}</p>
                    ))}
                  </div>
                </div>

                {/* تقسيم المستخدمين */}
                <div>
                  <h5 className="font-medium text-purple-700 mb-1">تقسيم المستخدمين:</h5>
                  <div className="space-y-1 text-sm text-purple-600">
                    {userBaseAnalysis.segmentation?.map((item: string, index: number) => (
                      <p key={index}>• {item}</p>
                    ))}
                  </div>
                </div>

                {/* استراتيجيات النمو */}
                <div>
                  <h5 className="font-medium text-green-700 mb-1">استراتيجيات النمو:</h5>
                  <div className="space-y-1 text-sm text-green-600">
                    {userBaseAnalysis.growthOpportunities?.map((item: string, index: number) => (
                      <p key={index}>• {item}</p>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="text-center text-gray-500 text-sm">
        <p>🤖 نظام الذكاء الاصطناعي المتقدم لإدارة التطبيق بالكامل - يعمل بنماذج Hugging Face المجانية</p>
      </div>
    </div>
  );
}