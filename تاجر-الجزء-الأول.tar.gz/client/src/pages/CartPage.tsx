import { useState, useEffect } from 'react';
import { ShoppingCart, Plus, Minus, Trash2, ArrowRight, ChevronRight, Truck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { useLocation } from 'wouter';
import { useLanguage } from '@/contexts/LanguageContext';

interface CartItem {
  id: number;
  productId: number;
  quantity: number;
  product: {
    id: number;
    name: string;
    price: string;
    imageUrl: string;
    description: string;
    minPrice?: string;
    maxPrice?: string;
  };
}

export const CartPage = () => {
  const { language, t, dir } = useLanguage();
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [customerPrice, setCustomerPrice] = useState<number>(0);
  const [discount, setDiscount] = useState<number>(0);
  const [deliveryFee, setDeliveryFee] = useState<number>(5000); // سعر التوصيل الافتراضي
  const [, setLocation] = useLocation();

  useEffect(() => {
    fetchCartItems();
  }, []);

  const fetchCartItems = async () => {
    try {
      const response = await fetch('/api/cart');
      if (response.ok) {
        const data = await response.json();
        setCartItems(data);
      }
    } catch (error) {
      console.error('خطأ في جلب السلة:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateQuantity = async (productId: number, newQuantity: number) => {
    if (newQuantity <= 0) {
      removeItem(productId);
      return;
    }

    // تحديد الحد الأقصى للكمية بـ 3 منتجات
    if (newQuantity > 3) {
      newQuantity = 3;
    }

    try {
      const response = await fetch(`/api/cart/${productId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ quantity: newQuantity })
      });

      if (response.ok) {
        setCartItems(prev => 
          prev.map(item => 
            item.productId === productId 
              ? { ...item, quantity: newQuantity }
              : item
          )
        );
        // حفظ البيانات بعد تحديث الكمية
        setTimeout(saveCartData, 100);
      }
    } catch (error) {
      console.error('خطأ في تحديث الكمية:', error);
    }
  };

  const removeItem = async (productId: number) => {
    try {
      const response = await fetch(`/api/cart/${productId}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        setCartItems(prev => prev.filter(item => item.productId !== productId));
      }
    } catch (error) {
      console.error('خطأ في حذف المنتج:', error);
    }
  };

  // حذف جميع المنتجات من السلة مع تأكيد
  const clearCart = async () => {
    const isConfirmed = window.confirm('هل أنت متأكد من حذف جميع المنتجات من السلة؟');
    
    if (!isConfirmed) {
      return;
    }

    try {
      const response = await fetch('/api/cart', {
        method: 'DELETE'
      });

      if (response.ok) {
        setCartItems([]);
        setCustomerPrice(0);
      }
    } catch (error) {
      console.error('خطأ في حذف جميع المنتجات:', error);
    }
  };

  // حساب سعر الجملة الإجمالي
  const getWholesaleTotal = () => {
    return cartItems.reduce((total, item) => {
      return total + (parseFloat(item.product.price) * item.quantity);
    }, 0);
  };

  // حساب الربح (الفرق بين سعر الزبون وسعر الجملة)
  const getProfit = () => {
    const wholesaleTotal = getWholesaleTotal();
    const profit = customerPrice - wholesaleTotal;
    // إذا كان الربح سالباً، أعرضه كصفر
    return profit < 0 ? 0 : profit;
  };

  // التحكم في سعر التوصيل مع تأثيره على الربح
  const handleDeliveryFeeChange = (value: number[]) => {
    const newDeliveryFee = value[0];
    setDeliveryFee(newDeliveryFee);
    localStorage.setItem('deliveryFee', newDeliveryFee.toString());
    saveCartData();
  };

  // حفظ بيانات السلة في Firebase
  const saveCartData = async () => {
    try {
      const response = await fetch('/api/cart/save', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          items: cartItems,
          customerPrice,
          discount
        }),
      });

      if (response.ok) {
        const result = await response.json();
        console.log('تم حفظ بيانات السلة بنجاح:', result);
      }
    } catch (error) {
      console.error('خطأ في حفظ بيانات السلة:', error);
    }
  };

  // التحقق من صحة سعر العميل باستخدام الحدود المحددة في المنتج
  const validateCustomerPrice = (price: number) => {
    if (cartItems.length === 0) return true;
    
    const totalQuantity = cartItems.reduce((sum, item) => sum + item.quantity, 0);
    const minPricePerUnit = cartItems[0].product.minPrice ? parseFloat(cartItems[0].product.minPrice) : parseFloat(cartItems[0].product.price);
    const maxPricePerUnit = cartItems[0].product.maxPrice ? parseFloat(cartItems[0].product.maxPrice) : parseFloat(cartItems[0].product.price) * 2;
    
    const minTotalPrice = minPricePerUnit * totalQuantity;
    const maxTotalPrice = maxPricePerUnit * totalQuantity;
    
    return price >= minTotalPrice && price <= maxTotalPrice;
  };

  // الحصول على حدود السعر الحالية
  const getPriceLimits = () => {
    if (cartItems.length === 0) return { min: 0, max: 0 };
    
    const totalQuantity = cartItems.reduce((sum, item) => sum + item.quantity, 0);
    const minPricePerUnit = cartItems[0].product.minPrice ? parseFloat(cartItems[0].product.minPrice) : parseFloat(cartItems[0].product.price);
    const maxPricePerUnit = cartItems[0].product.maxPrice ? parseFloat(cartItems[0].product.maxPrice) : parseFloat(cartItems[0].product.price) * 2;
    
    return {
      min: minPricePerUnit * totalQuantity,
      max: maxPricePerUnit * totalQuantity
    };
  };

  // التحقق من إمكانية إتمام الشراء
  const canCompletePurchase = () => {
    return cartItems.length > 0 && customerPrice > 0 && validateCustomerPrice(customerPrice);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50" dir={dir}>
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLocation('/store')}
              className="p-1"
            >
              <ChevronRight className="w-5 h-5" />
            </Button>
            <h1 className="text-lg font-semibold text-gray-800">{language === 'ar' ? 'سلة التسوق' : 'Shopping Cart'}</h1>
          </div>
          {cartItems.length > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={clearCart}
              className="p-1 text-red-500 hover:text-red-700 hover:bg-red-50"
            >
              <Trash2 className="w-5 h-5" />
            </Button>
          )}
        </div>
      </div>

      <div className="p-4">
        {cartItems.length === 0 ? (
          <div className="text-center py-20">
            <ShoppingCart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-gray-600 mb-2">
              {language === 'ar' ? 'سلة التسوق فارغة' : 'Shopping cart is empty'}
            </h2>
            <p className="text-gray-500">
              {language === 'ar' ? 'لم تقم بإضافة أي منتجات بعد' : 'You haven\'t added any products yet'}
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {/* ملخص السلة في الأعلى */}
            <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl shadow-sm border-0">
              <CardContent className="p-4">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="text-lg font-bold text-gray-800">
                      {language === 'ar' ? 'سعر الزبون الإجمالي' : 'Total Customer Price'}
                    </h3>
                    <p className="text-3xl font-bold text-blue-600">
                      {customerPrice.toLocaleString()} {language === 'ar' ? 'د.ع' : 'IQD'}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-600">{language === 'ar' ? 'الربح' : 'Profit'}</p>
                    <p className="text-xl font-semibold text-green-600">
                      {getProfit().toLocaleString()} {language === 'ar' ? 'د.ع' : 'IQD'}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Cart Items */}
            {cartItems.map((item) => (
              <Card key={item.id} className="bg-white rounded-2xl shadow-sm border-0">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    {/* Product Image */}
                    <div className="w-16 h-16 rounded-xl overflow-hidden bg-gray-100 flex-shrink-0">
                      <img
                        src={item.product.imageUrl || '/placeholder-image.jpg'}
                        alt={item.product.name}
                        className="w-full h-full object-cover"
                      />
                    </div>

                    {/* Product Info */}
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-800 mb-1">
                        {item.product.name}
                      </h3>
                      <div className="text-lg font-bold text-purple-600 mb-3">
                        {language === 'ar' ? 'سعر الجملة:' : 'Wholesale Price:'} {parseFloat(item.product.price).toLocaleString()} {language === 'ar' ? 'د.ع' : 'IQD'}
                      </div>
                    </div>
                  </div>

                  {/* Quantity Controls */}
                  <div className="flex items-center justify-between mt-4">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => removeItem(item.productId)}
                      className="w-10 h-10 p-0 text-red-500 border-red-200 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                    
                    <div className="flex items-center gap-3">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => updateQuantity(item.productId, item.quantity + 1)}
                        className="w-8 h-8 p-0 rounded-full"
                        disabled={item.quantity >= 3}
                      >
                        <Plus className="w-4 h-4" />
                      </Button>
                      
                      <span className="w-8 text-center font-semibold text-lg">
                        {item.quantity}
                      </span>
                      
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => updateQuantity(item.productId, item.quantity - 1)}
                        className="w-8 h-8 p-0 rounded-full"
                      >
                        <Minus className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}

            {/* Customer Price Section */}
            <Card className="bg-white rounded-2xl shadow-sm border-0 mt-6">
              <CardContent className="p-6">
                <h3 className="font-medium text-gray-800 mb-4">
                  {language === 'ar' ? 'سعر الزبون' : 'Customer Price'}
                </h3>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="customer-price" className="text-sm text-gray-600">
                      {language === 'ar' ? 'سعر البيع للزبون' : 'Selling Price to Customer'}
                    </Label>
                    <Input
                      id="customer-price"
                      type="number"
                      value={customerPrice || ''}
                      onChange={(e) => {
                        const price = parseFloat(e.target.value) || 0;
                        setCustomerPrice(price);
                        localStorage.setItem('customerPrice', price.toString());
                        saveCartData();
                      }}
                      placeholder={language === 'ar' ? 'أدخل سعر البيع' : 'Enter selling price'}
                      className="mt-1 text-lg font-medium"
                    />
                  </div>
                  
                  {cartItems.length > 0 && (
                    <div className={`rounded-xl p-4 ${validateCustomerPrice(customerPrice) ? 'bg-gray-50' : 'bg-red-50 border border-red-200'}`}>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-gray-600">
                          {language === 'ar' ? 'نطاق السعر المطلوب:' : 'Required Price Range:'}
                        </span>
                        <span className="text-sm font-medium">
                          {getPriceLimits().min.toLocaleString()} - {getPriceLimits().max.toLocaleString()} {language === 'ar' ? 'د.ع' : 'IQD'}
                        </span>
                      </div>
                      <div className={`text-xs leading-relaxed ${validateCustomerPrice(customerPrice) ? 'text-gray-500' : 'text-red-600'}`}>
                        {validateCustomerPrice(customerPrice) 
                          ? language === 'ar' ? 'السعر ضمن النطاق المسموح' : 'Price is within allowed range'
                          : language === 'ar' ? 'السعر خارج النطاق المسموح! يجب أن يكون بين الحد الأدنى والأعلى' : 'Price is out of allowed range! Must be between minimum and maximum'}
                      </div>
                    </div>
                  )}
                  
                  {/* Profit Summary */}
                  {customerPrice > 0 && (
                    <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-xl p-4 border border-green-200 mt-4">
                      <h4 className="font-semibold text-gray-800 mb-3">
                        {language === 'ar' ? 'ملخص الربح' : 'Profit Summary'}
                      </h4>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">
                            {language === 'ar' ? 'إجمالي سعر الجملة:' : 'Total Wholesale Price:'}
                          </span>
                          <span className="font-semibold text-gray-800">
                            {getWholesaleTotal().toLocaleString()} {language === 'ar' ? 'د.ع' : 'IQD'}
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">
                            {language === 'ar' ? 'سعر البيع للزبون:' : 'Customer Selling Price:'}
                          </span>
                          <span className="font-semibold text-purple-600">
                            {customerPrice.toLocaleString()} {language === 'ar' ? 'د.ع' : 'IQD'}
                          </span>
                        </div>
                        <hr className="border-gray-200" />
                        <div className="flex justify-between items-center">
                          <span className="text-lg font-bold text-gray-800">
                            {language === 'ar' ? 'الربح المحقق:' : 'Total Profit:'}
                          </span>
                          <span className="text-xl font-bold text-green-600">
                            {getProfit().toLocaleString()} {language === 'ar' ? 'د.ع' : 'IQD'}
                          </span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

          </div>
        )}

        {/* Complete Purchase Button */}
        {cartItems.length > 0 && (
          <div className="fixed bottom-4 left-4 right-4">
            <Button 
              className={`w-full py-4 text-lg rounded-2xl shadow-lg ${
                canCompletePurchase() 
                  ? 'bg-purple-500 hover:bg-purple-600 text-white' 
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              }`}
              size="lg"
              disabled={!canCompletePurchase()}
              onClick={() => canCompletePurchase() && setLocation('/checkout')}
            >
              {canCompletePurchase() 
                ? language === 'ar' ? 'إتمام الشراء' : 'Complete Purchase'
                : language === 'ar' ? 'يجب تصحيح السعر أولاً' : 'Please correct price first'
              }
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};