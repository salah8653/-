import { useState, useEffect } from 'react';
import { useParams, useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { 
  Save, 
  Eye, 
  Plus, 
  X, 
  ArrowLeft,
  Upload,
  Palette,
  Layout,
  Camera
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

interface ProductPageSettings {
  productId: number;
  settings: {
    showDescription: boolean;
    showPrice: boolean;
    showStock: boolean;
    showCategory: boolean;
    showImages: boolean;
    layout: string;
    primaryColor: string;
    backgroundColor: string;
    customCSS: string;
    seoTitle: string;
    seoDescription: string;
    showReviews: boolean;
    showRelatedProducts: boolean;
  };
  customSections: CustomSection[];
  imageGallery: string[];
  updatedAt: string;
}

interface CustomSection {
  id: number;
  title: string;
  content: string;
  type: string;
  visible: boolean;
  order: number;
}

export const ProductPageCustomizer = () => {
  const { id } = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [settings, setSettings] = useState<ProductPageSettings>({
    productId: parseInt(id || '0'),
    settings: {
      showDescription: true,
      showPrice: true,
      showStock: true,
      showCategory: true,
      showImages: true,
      layout: 'default',
      primaryColor: '#8B5CF6',
      backgroundColor: '#FFFFFF',
      customCSS: '',
      seoTitle: '',
      seoDescription: '',
      showReviews: false,
      showRelatedProducts: true,
    },
    customSections: [],
    imageGallery: [],
    updatedAt: new Date().toISOString(),
  });

  const [editableProduct, setEditableProduct] = useState({
    name: '',
    description: '',
    price: 0,
    stock: 0,
    sku: '',
    imageUrl: '',
    categoryId: ''
  });

  const [selectedImageFile, setSelectedImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const [newSection, setNewSection] = useState<Partial<CustomSection>>({
    title: '',
    content: '',
    type: 'text',
    visible: true,
    order: 0
  });

  // جلب بيانات المنتج
  const { data: product, isLoading: productLoading } = useQuery({
    queryKey: ['/api/products', id],
    enabled: !!id,
  });

  // جلب إعدادات صفحة المنتج
  const { data: pageSettings, isLoading: settingsLoading } = useQuery({
    queryKey: ['/api/product-pages', id],
    enabled: !!id,
  });

  // جلب الفئات
  const { data: categories = [] } = useQuery({
    queryKey: ['/api/categories'],
  });

  // حفظ الإعدادات
  const saveSettingsMutation = useMutation({
    mutationFn: (data: ProductPageSettings) => 
      apiRequest(`/api/product-pages/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data),
      }),
    onSuccess: () => {
      toast({
        title: "تم الحفظ",
        description: "تم حفظ إعدادات صفحة المنتج بنجاح",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/product-pages', id] });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "فشل في حفظ الإعدادات",
        variant: "destructive",
      });
    },
  });

  // تحديث الإعدادات عند تحميل البيانات
  useEffect(() => {
    if (pageSettings) {
      setSettings(pageSettings);
    }
    if (product) {
      setEditableProduct({
        name: product.name || '',
        description: product.description || '',
        price: parseFloat(product.price) || 0,
        stock: product.stock || 0,
        imageUrl: product.imageUrl || '',
        categoryId: product.categoryId?.toString() || ''
      });
    }
  }, [pageSettings, product]);

  const handleSaveSettings = () => {
    saveSettingsMutation.mutate(settings);
  };

  // حفظ تعديلات المنتج
  const saveProductMutation = useMutation({
    mutationFn: async (productData: typeof editableProduct) => {
      console.log('إرسال بيانات المنتج:', productData);
      const response = await fetch(`/api/products/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: productData.name,
          description: productData.description,
          wholesalePrice: productData.price,
          stock: productData.stock,
          categoryId: parseInt(productData.categoryId) || null,
          imageUrl: productData.imageUrl
        }),
      });
      
      if (!response.ok) {
        const errorData = await response.text();
        console.error('خطأ في الاستجابة:', errorData);
        throw new Error(`فشل في حفظ البيانات: ${response.status}`);
      }
      return response.json();
    },
    onSuccess: (data) => {
      console.log('تم حفظ المنتج بنجاح:', data);
      toast({
        title: "تم الحفظ",
        description: "تم حفظ بيانات المنتج بنجاح",
      });
      // تحديث جميع استعلامات المنتجات
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      queryClient.refetchQueries({ queryKey: ['/api/products', id] });
    },
    onError: (error) => {
      console.error('خطأ في حفظ المنتج:', error);
      toast({
        title: "خطأ",
        description: "فشل في حفظ بيانات المنتج - تحقق من الاتصال",
        variant: "destructive",
      });
    },
  });

  const addCustomSection = () => {
    if (!newSection.title || !newSection.content) return;
    
    const section: CustomSection = {
      id: Date.now(),
      title: newSection.title,
      content: newSection.content,
      type: newSection.type || 'text',
      visible: newSection.visible !== false,
      order: settings.customSections.length,
    };

    setSettings(prev => ({
      ...prev,
      customSections: [...prev.customSections, section]
    }));

    setNewSection({ title: '', content: '', type: 'text', visible: true, order: 0 });
  };

  const removeCustomSection = (sectionId: number) => {
    setSettings(prev => ({
      ...prev,
      customSections: prev.customSections.filter(section => section.id !== sectionId)
    }));
  };

  const updateSetting = (key: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      settings: {
        ...prev.settings,
        [key]: value
      }
    }));
  };

  const previewProduct = () => {
    window.open(`/product/${id}`, '_blank');
  };

  // رفع الصورة
  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedImageFile(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        setImagePreview(result);
        setEditableProduct(prev => ({ ...prev, imageUrl: result }));
      };
      reader.readAsDataURL(file);
    }
  };

  if (productLoading || settingsLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* رأس الصفحة */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLocation('/products')}
          >
            <ArrowLeft className="w-4 h-4 ml-2" />
            العودة للمنتجات
          </Button>
          <div>
            <h1 className="text-3xl font-bold">تخصيص صفحة المنتج</h1>
            {product && (
              <p className="text-muted-foreground">
                إدارة صفحة منتج: {product.name}
              </p>
            )}
          </div>
        </div>
        
        <div className="flex gap-2">
          <Button
            onClick={previewProduct}
            variant="outline"
          >
            <Eye className="w-4 h-4 ml-2" />
            معاينة
          </Button>
          <Button
            onClick={handleSaveSettings}
            disabled={saveSettingsMutation.isPending}
          >
            <Save className="w-4 h-4 ml-2" />
            حفظ التغييرات
          </Button>
        </div>
      </div>

      {/* معلومات المنتج */}
      {product && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Layout className="w-5 h-5" />
              معلومات المنتج
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* معلومات المنتج الأساسية */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-4">
                <div>
                  <Label>صورة المنتج</Label>
                  <div className="flex items-center gap-3 mt-2">
                    {(imagePreview || editableProduct.imageUrl) ? (
                      <img 
                        src={imagePreview || editableProduct.imageUrl} 
                        alt={editableProduct.name || 'منتج'}
                        className="w-20 h-20 object-cover rounded-lg border"
                      />
                    ) : (
                      <div className="w-20 h-20 bg-gray-200 rounded-lg flex items-center justify-center">
                        <Camera className="w-8 h-8 text-gray-400" />
                      </div>
                    )}
                    <div>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageUpload}
                        id="image-upload"
                        className="hidden"
                      />
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => document.getElementById('image-upload')?.click()}
                      >
                        <Upload className="w-4 h-4 ml-2" />
                        تغيير الصورة
                      </Button>
                    </div>
                  </div>
                </div>

                <div>
                  <Label>اسم المنتج</Label>
                  <Input 
                    value={editableProduct.name} 
                    onChange={(e) => setEditableProduct(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="أدخل اسم المنتج"
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label>وصف المنتج</Label>
                  <Textarea 
                    value={editableProduct.description} 
                    onChange={(e) => setEditableProduct(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="لا يوجد وصف متاح للمنتج"
                    rows={4}
                    className="mt-1"
                  />
                  <Button variant="ghost" size="sm" className="mt-2">
                    <Plus className="w-4 h-4 ml-2" />
                    نسخ الوصف
                  </Button>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <Label>سعر الجملة</Label>
                  <div className="flex items-center gap-2 mt-1">
                    <input 
                      type="number"
                      value={editableProduct.price || ""} 
                      onChange={(e) => setEditableProduct(prev => ({ ...prev, price: parseFloat(e.target.value) || 0 }))}
                      placeholder="أدخل السعر"
                      className="w-full px-3 py-2 border border-gray-300 rounded-md text-lg font-bold text-purple-600 focus:outline-none focus:ring-2 focus:ring-purple-500"
                    />
                    <span className="text-sm text-muted-foreground">د.ع</span>
                  </div>
                </div>

                <div>
                  <Label>حالة التوفر</Label>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant={editableProduct.stock > 0 ? "default" : "secondary"}>
                      {editableProduct.stock > 0 ? `متوفر (${editableProduct.stock})` : 'غير متوفر'}
                    </Badge>
                    <input 
                      type="number"
                      value={editableProduct.stock || ""}
                      onChange={(e) => setEditableProduct(prev => ({ ...prev, stock: parseInt(e.target.value) || 0 }))}
                      className="w-24 px-2 py-1 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                      min="0"
                      placeholder="الكمية"
                    />
                  </div>
                </div>

                <div>
                  <Label>الفئة</Label>
                  <div className="mt-1">
                    <select 
                      value={editableProduct.categoryId}
                      onChange={(e) => setEditableProduct(prev => ({ ...prev, categoryId: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                    >
                      <option value="">اختر الفئة</option>
                      {categories.map((category: any) => (
                        <option key={category.id} value={category.id}>
                          {category.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>


              </div>
            </div>

            {/* زر الحفظ */}
            <div className="flex justify-end">
              <Button 
                onClick={() => saveProductMutation.mutate(editableProduct)}
                disabled={saveProductMutation.isPending}
                className="bg-purple-600 hover:bg-purple-700"
              >
                <Save className="w-4 h-4 ml-2" />
                حفظ بيانات المنتج
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* تبويبات التخصيص */}
      <Tabs defaultValue="layout" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="layout">التخطيط</TabsTrigger>
          <TabsTrigger value="content">المحتوى</TabsTrigger>
          <TabsTrigger value="design">التصميم</TabsTrigger>
          <TabsTrigger value="seo">SEO</TabsTrigger>
        </TabsList>

        {/* تبويب التخطيط */}
        <TabsContent value="layout" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>إعدادات العرض</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center justify-between">
                  <Label>عرض الوصف</Label>
                  <Switch
                    checked={settings.settings.showDescription}
                    onCheckedChange={(checked) => updateSetting('showDescription', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label>عرض السعر</Label>
                  <Switch
                    checked={settings.settings.showPrice}
                    onCheckedChange={(checked) => updateSetting('showPrice', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label>عرض المخزون</Label>
                  <Switch
                    checked={settings.settings.showStock}
                    onCheckedChange={(checked) => updateSetting('showStock', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label>عرض الفئة</Label>
                  <Switch
                    checked={settings.settings.showCategory}
                    onCheckedChange={(checked) => updateSetting('showCategory', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label>عرض الصور</Label>
                  <Switch
                    checked={settings.settings.showImages}
                    onCheckedChange={(checked) => updateSetting('showImages', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label>عرض المنتجات ذات الصلة</Label>
                  <Switch
                    checked={settings.settings.showRelatedProducts}
                    onCheckedChange={(checked) => updateSetting('showRelatedProducts', checked)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* تبويب المحتوى */}
        <TabsContent value="content" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>الأقسام المخصصة</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* إضافة قسم جديد */}
              <div className="p-4 border rounded-lg space-y-3">
                <h4 className="font-medium">إضافة قسم جديد</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <Label>عنوان القسم</Label>
                    <Input
                      value={newSection.title || ''}
                      onChange={(e) => setNewSection(prev => ({ ...prev, title: e.target.value }))}
                      placeholder="مثال: تفاصيل إضافية"
                    />
                  </div>
                  <div>
                    <Label>نوع القسم</Label>
                    <select
                      className="w-full p-2 border rounded"
                      value={newSection.type || 'text'}
                      onChange={(e) => setNewSection(prev => ({ ...prev, type: e.target.value }))}
                    >
                      <option value="text">نص</option>
                      <option value="html">HTML</option>
                      <option value="image">صورة</option>
                    </select>
                  </div>
                </div>
                <div>
                  <Label>محتوى القسم</Label>
                  <Textarea
                    value={newSection.content || ''}
                    onChange={(e) => setNewSection(prev => ({ ...prev, content: e.target.value }))}
                    placeholder="أدخل محتوى القسم..."
                    rows={3}
                  />
                </div>
                <Button onClick={addCustomSection} size="sm">
                  <Plus className="w-4 h-4 ml-2" />
                  إضافة القسم
                </Button>
              </div>

              {/* قائمة الأقسام المخصصة */}
              <div className="space-y-3">
                {settings.customSections.map((section) => (
                  <div key={section.id} className="p-3 border rounded-lg">
                    <div className="flex items-center justify-between">
                      <div>
                        <h5 className="font-medium">{section.title}</h5>
                        <p className="text-sm text-muted-foreground">{section.type}</p>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeCustomSection(section.id)}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* تبويب التصميم */}
        <TabsContent value="design" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Palette className="w-5 h-5" />
                الألوان والتصميم
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>اللون الأساسي</Label>
                  <div className="flex gap-2">
                    <Input
                      type="color"
                      value={settings.settings.primaryColor}
                      onChange={(e) => updateSetting('primaryColor', e.target.value)}
                      className="w-16 h-10"
                    />
                    <Input
                      value={settings.settings.primaryColor}
                      onChange={(e) => updateSetting('primaryColor', e.target.value)}
                      placeholder="#8B5CF6"
                    />
                  </div>
                </div>
                <div>
                  <Label>لون الخلفية</Label>
                  <div className="flex gap-2">
                    <Input
                      type="color"
                      value={settings.settings.backgroundColor}
                      onChange={(e) => updateSetting('backgroundColor', e.target.value)}
                      className="w-16 h-10"
                    />
                    <Input
                      value={settings.settings.backgroundColor}
                      onChange={(e) => updateSetting('backgroundColor', e.target.value)}
                      placeholder="#FFFFFF"
                    />
                  </div>
                </div>
              </div>
              
              <div>
                <Label>CSS مخصص</Label>
                <Textarea
                  value={settings.settings.customCSS}
                  onChange={(e) => updateSetting('customCSS', e.target.value)}
                  placeholder="أدخل CSS مخصص هنا..."
                  rows={6}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* تبويب SEO */}
        <TabsContent value="seo" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>تحسين محركات البحث</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>عنوان SEO</Label>
                <Input
                  value={settings.settings.seoTitle}
                  onChange={(e) => updateSetting('seoTitle', e.target.value)}
                  placeholder="عنوان الصفحة في محركات البحث"
                />
              </div>
              <div>
                <Label>وصف SEO</Label>
                <Textarea
                  value={settings.settings.seoDescription}
                  onChange={(e) => updateSetting('seoDescription', e.target.value)}
                  placeholder="وصف الصفحة في محركات البحث"
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};