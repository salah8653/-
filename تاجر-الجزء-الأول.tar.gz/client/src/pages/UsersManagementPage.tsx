import { EnhancedUsersManager } from '@/components/EnhancedUsersManager';

export const UsersManagementPage = () => {
  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">إدارة العملاء والمديرين</h1>
            <p className="text-blue-100">إدارة شاملة لجميع المستخدمين المسجلين في النظام</p>
          </div>
          <div className="text-center">
            <div className="text-sm text-blue-200">المستخدمين النشطين</div>
            <div className="text-2xl font-bold">متنوعة</div>
          </div>
        </div>
      </div>

      <EnhancedUsersManager />
    </div>
  );
};