import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Upload, Save, ArrowLeft, Trash2 } from "lucide-react";
import { Link, useRoute } from "wouter";

export default function EditProductPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [match, params] = useRoute('/products/:id/edit');
  const productId = params?.id;

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: '',
    minPrice: '',
    maxPrice: '',
    stock: '0',
    imageUrl: ''
  });

  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string>('');

  // جلب بيانات المنتج
  const { data: product, isLoading } = useQuery({
    queryKey: ['/api/products', productId],
    queryFn: async () => {
      const response = await fetch(`/api/products/${productId}`);
      if (!response.ok) throw new Error('فشل في جلب بيانات المنتج');
      return response.json();
    },
    enabled: !!productId
  });

  // تحميل بيانات المنتج في النموذج
  useEffect(() => {
    if (product) {
      setFormData({
        name: product.name || '',
        description: product.description || '',
        price: product.price?.toString() || '',
        minPrice: product.minPrice?.toString() || '',
        maxPrice: product.maxPrice?.toString() || '',
        stock: product.stock?.toString() || '0',
        imageUrl: product.imageUrl || ''
      });
      setPreviewUrl(product.imageUrl || '');
    }
  }, [product]);

  // رفع الصورة
  const uploadImageMutation = useMutation({
    mutationFn: async (file: File) => {
      const formDataUpload = new FormData();
      formDataUpload.append('image', file);
      
      const response = await fetch('/api/upload-image', {
        method: 'POST',
        body: formDataUpload
      });
      
      if (!response.ok) throw new Error('فشل في رفع الصورة');
      return response.json();
    },
    onSuccess: (data) => {
      setFormData(prev => ({ ...prev, imageUrl: data.url }));
      setPreviewUrl(data.url);
      toast({
        title: "تم رفع الصورة! ✅",
        description: "يمكنك الآن حفظ التعديلات",
      });
    },
    onError: () => {
      toast({
        title: "خطأ في رفع الصورة ❌",
        description: "حاول مرة أخرى",
        variant: "destructive",
      });
    }
  });

  // تحديث المنتج
  const updateProductMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await fetch(`/api/products/${productId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      
      if (!response.ok) throw new Error('فشل في تحديث المنتج');
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم تحديث المنتج! ✅",
        description: "تم حفظ التعديلات بنجاح",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
    },
    onError: () => {
      toast({
        title: "خطأ في التحديث ❌",
        description: "حاول مرة أخرى",
        variant: "destructive",
      });
    }
  });

  // حذف المنتج
  const deleteProductMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch(`/api/products/${productId}`, {
        method: 'DELETE'
      });
      
      if (!response.ok) throw new Error('فشل في حذف المنتج');
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم حذف المنتج! ✅",
        description: "تم حذف المنتج نهائياً",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      // إعادة توجيه إلى صفحة المنتجات
      window.location.href = '/products';
    },
    onError: () => {
      toast({
        title: "خطأ في الحذف ❌",
        description: "حاول مرة أخرى",
        variant: "destructive",
      });
    }
  });

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedImage(file);
      const reader = new FileReader();
      reader.onload = () => setPreviewUrl(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleImageUpload = () => {
    if (selectedImage) {
      uploadImageMutation.mutate(selectedImage);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim() || !formData.price) {
      toast({
        title: "بيانات ناقصة ⚠️",
        description: "يرجى ملء اسم المنتج والسعر",
        variant: "destructive",
      });
      return;
    }

    updateProductMutation.mutate({
      name: formData.name.trim(),
      description: formData.description.trim(),
      price: parseFloat(formData.price),
      stock: parseInt(formData.stock) || 0,
      imageUrl: formData.imageUrl
    });
  };

  const handleDelete = () => {
    if (confirm('هل أنت متأكد من حذف هذا المنتج؟ لا يمكن التراجع عن هذا الإجراء.')) {
      deleteProductMutation.mutate();
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 p-4">
        <div className="max-w-2xl mx-auto">
          <div className="text-center py-12">
            <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full mx-auto"></div>
            <p className="mt-4 text-gray-600">جاري تحميل بيانات المنتج...</p>
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-gray-50 p-4">
        <div className="max-w-2xl mx-auto">
          <div className="text-center py-12">
            <p className="text-red-600">لم يتم العثور على المنتج</p>
            <Link href="/products">
              <Button className="mt-4">العودة للمنتجات</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-2xl mx-auto">
        {/* رأس الصفحة */}
        <div className="mb-6">
          <div className="flex items-center gap-4 mb-4">
            <Link href="/products">
              <Button variant="outline" size="sm">
                <ArrowLeft className="h-4 w-4 ml-2" />
                العودة للمنتجات
              </Button>
            </Link>
            <h1 className="text-2xl font-bold text-gray-900">تعديل المنتج</h1>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>تعديل بيانات المنتج</span>
              <Button 
                variant="destructive" 
                size="sm"
                onClick={handleDelete}
                disabled={deleteProductMutation.isPending}
              >
                <Trash2 className="h-4 w-4 ml-2" />
                حذف المنتج
              </Button>
            </CardTitle>
          </CardHeader>

          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* معلومات أساسية */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">اسم المنتج *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => handleInputChange('name', e.target.value)}
                    placeholder="أدخل اسم المنتج"
                    className="text-right"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="price" className="text-purple-600 font-semibold">
                    سعر الجملة (دينار) *
                  </Label>
                  <Input
                    id="price"
                    type="number"
                    value={formData.price}
                    onChange={(e) => handleInputChange('price', e.target.value)}
                    placeholder="0"
                    min="0"
                    step="0.01"
                    className="border-purple-200 focus:border-purple-500 focus:ring-purple-500 text-purple-700 font-semibold text-left"
                    style={{ direction: 'ltr' }}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="stock">الكمية المتاحة</Label>
                  <Input
                    id="stock"
                    type="text"
                    value={formData.stock}
                    onChange={(e) => {
                      const value = e.target.value.replace(/[^\d]/g, '');
                      handleInputChange('stock', value);
                    }}
                    placeholder="0"
                    className="text-left"
                    style={{ direction: 'ltr', fontFamily: 'monospace' }}
                    inputMode="numeric"
                  />
                </div>
              </div>

              {/* الوصف */}
              <div className="space-y-2">
                <Label htmlFor="description">وصف المنتج</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  placeholder="أدخل وصف المنتج..."
                  rows={3}
                  className="text-right"
                />
              </div>

              {/* رفع الصورة */}
              <div className="space-y-4">
                <Label>صورة المنتج</Label>
                
                {/* معاينة الصورة الحالية */}
                {previewUrl && (
                  <div className="relative">
                    <img 
                      src={previewUrl} 
                      alt="معاينة" 
                      className="w-full max-w-xs h-32 object-cover rounded-lg border"
                    />
                  </div>
                )}

                {/* رفع صورة جديدة */}
                <div className="flex items-center gap-4">
                  <Input
                    type="file"
                    accept="image/*"
                    onChange={handleImageSelect}
                    className="flex-1"
                  />
                  {selectedImage && (
                    <Button
                      type="button"
                      onClick={handleImageUpload}
                      disabled={uploadImageMutation.isPending}
                      className="shrink-0"
                    >
                      <Upload className="h-4 w-4 ml-2" />
                      {uploadImageMutation.isPending ? 'جاري الرفع...' : 'رفع الصورة'}
                    </Button>
                  )}
                </div>
              </div>

              {/* أزرار الحفظ */}
              <div className="flex gap-4 pt-4">
                <Button
                  type="submit"
                  disabled={updateProductMutation.isPending}
                  className="flex-1"
                >
                  <Save className="h-4 w-4 ml-2" />
                  {updateProductMutation.isPending ? 'جاري الحفظ...' : 'حفظ التعديلات'}
                </Button>
                
                <Link href="/products">
                  <Button variant="outline" type="button">
                    إلغاء
                  </Button>
                </Link>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}