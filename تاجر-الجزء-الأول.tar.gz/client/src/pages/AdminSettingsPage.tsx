import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { useLocation } from "wouter";
import { 
  ArrowRight, 
  ArrowLeft,
  Settings,
  Globe,
  Shield,
  Languages,
  Moon,
  Sun,
  User,
  Database
} from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { LanguageSettings } from "@/components/LanguageSettings";
import { AdminLanguageToggle } from "@/components/AdminLanguageToggle";

export const AdminSettingsPage = () => {
  const [, setLocation] = useLocation();
  const { language, dir } = useLanguage();
  const [isDarkMode, setIsDarkMode] = useState(false);

  useEffect(() => {
    const darkModeStored = localStorage.getItem('darkMode');
    if (darkModeStored) {
      setIsDarkMode(darkModeStored === 'true');
    }
  }, []);

  const toggleDarkMode = () => {
    const newMode = !isDarkMode;
    setIsDarkMode(newMode);
    localStorage.setItem('darkMode', newMode.toString());
    if (newMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900" dir={dir}>
      {/* Header */}
      <div className="bg-white dark:bg-slate-800 shadow-sm border-b border-slate-200 dark:border-slate-700">
        <div className="p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => setLocation("/admin")}
            >
              {dir === 'rtl' ? (
                <ArrowRight className="h-5 w-5" />
              ) : (
                <ArrowLeft className="h-5 w-5" />
              )}
            </Button>
            <Shield className="h-6 w-6 text-blue-600" />
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">
              {language === 'ar' ? 'إعدادات المدير' : 'Admin Settings'}
            </h1>
          </div>
          <AdminLanguageToggle />
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-6">
        {/* نظام إدارة اللغة */}
        <Card className="border-orange-200 bg-orange-50 dark:border-orange-700 dark:bg-orange-900/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-3 text-orange-800 dark:text-orange-200">
              <Languages className="w-6 h-6" />
              {language === 'ar' ? 'إدارة اللغة المتقدمة' : 'Advanced Language Management'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-4 bg-white dark:bg-slate-800 rounded-lg border">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="font-semibold text-slate-900 dark:text-white">
                      {language === 'ar' ? 'اللغة الحالية' : 'Current Language'}
                    </h3>
                    <p className="text-sm text-slate-600 dark:text-slate-400">
                      {language === 'ar' ? 'لغة واجهة التطبيق النشطة' : 'Active application interface language'}
                    </p>
                  </div>
                  <Badge variant={language === 'ar' ? 'default' : 'secondary'} className="text-lg px-4 py-2">
                    {language === 'ar' ? 'العربية 🇰🇼' : 'English 🇺🇸'}
                  </Badge>
                </div>
                <LanguageSettings />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* إعدادات العرض للمدير */}
        <Card className="dark:bg-slate-800 dark:border-slate-700">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-slate-900 dark:text-white">
              <Settings className="w-5 h-5" />
              {language === 'ar' ? 'إعدادات المظهر' : 'Appearance Settings'}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* الوضع المظلم */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {isDarkMode ? (
                  <Moon className="w-5 h-5 text-slate-600 dark:text-slate-400" />
                ) : (
                  <Sun className="w-5 h-5 text-slate-600 dark:text-slate-400" />
                )}
                <div>
                  <p className="font-medium text-slate-900 dark:text-white">
                    {language === 'ar' ? 'الوضع المظلم' : 'Dark Mode'}
                  </p>
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    {isDarkMode ? 
                      (language === 'ar' ? 'مُفعل - واجهة داكنة' : 'Enabled - Dark interface') : 
                      (language === 'ar' ? 'غير مُفعل - واجهة فاتحة' : 'Disabled - Light interface')
                    }
                  </p>
                </div>
              </div>
              <Switch
                checked={isDarkMode}
                onCheckedChange={toggleDarkMode}
              />
            </div>
          </CardContent>
        </Card>

        {/* معلومات النظام */}
        <Card className="border-blue-200 bg-blue-50 dark:border-blue-700 dark:bg-blue-900/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-3 text-blue-800 dark:text-blue-200">
              <Database className="w-6 h-6" />
              {language === 'ar' ? 'معلومات النظام' : 'System Information'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-white dark:bg-slate-800 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Globe className="h-4 w-4 text-blue-600" />
                  <span className="font-medium text-slate-900 dark:text-white">
                    {language === 'ar' ? 'دعم اللغات' : 'Language Support'}
                  </span>
                </div>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  {language === 'ar' ? 'العربية والإنجليزية متاحتان' : 'Arabic and English available'}
                </p>
              </div>
              <div className="p-4 bg-white dark:bg-slate-800 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <User className="h-4 w-4 text-green-600" />
                  <span className="font-medium text-slate-900 dark:text-white">
                    {language === 'ar' ? 'مستوى الصلاحية' : 'Access Level'}
                  </span>
                </div>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  {language === 'ar' ? 'مدير النظام' : 'System Administrator'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* حفظ الإعدادات */}
        <Card className="border-green-200 bg-green-50 dark:border-green-700 dark:bg-green-900/20">
          <CardContent className="pt-6">
            <Button
              className="w-full bg-green-600 hover:bg-green-700 text-white py-4 text-lg font-bold shadow-lg"
              onClick={() => {
                localStorage.setItem('darkMode', isDarkMode.toString());
                localStorage.setItem('language', language);
                alert(language === 'ar' ? 'تم حفظ الإعدادات بنجاح!' : 'Settings saved successfully!');
              }}
            >
              {language === 'ar' ? '💾 حفظ جميع الإعدادات' : '💾 Save All Settings'}
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};