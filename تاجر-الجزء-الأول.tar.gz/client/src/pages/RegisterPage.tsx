import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Store, UserPlus, ArrowRight, AlertTriangle, X, ShoppingBag } from 'lucide-react';
import { Link, useLocation } from 'wouter';
import { registerSchema } from '@shared/schema';
import { TermsAndConditions } from '@/components/TermsAndConditions';

// إضافة تأكيد كلمة المرور والموافقة على الشروط للنموذج
const registerWithConfirmSchema = registerSchema.extend({
  confirmPassword: z.string(),
  agreeToTerms: z.boolean().refine((val) => val === true, {
    message: "يجب الموافقة على الشروط والأحكام",
  }),
}).refine((data) => data.password === data.confirmPassword, {
  message: "كلمة المرور غير متطابقة",
  path: ["confirmPassword"],
});

type RegisterFormData = z.infer<typeof registerWithConfirmSchema>;

export const RegisterPage = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [showWarning, setShowWarning] = useState(true);
  const [agreeToTerms, setAgreeToTerms] = useState(false);
  const { toast } = useToast();

  const [, setLocation] = useLocation();

  const form = useForm<RegisterFormData>({
    resolver: zodResolver(registerWithConfirmSchema),
    defaultValues: {
      phone: '',
      password: '',
      confirmPassword: '',
      fullName: '',
      email: '',
      address: '',
      agreeToTerms: false,
    },
  });

  const onSubmit = async (data: RegisterFormData) => {
    setIsLoading(true);
    try {
      await apiRequest('POST', '/api/auth/register', {
        phone: data.phone,
        password: data.password,
        fullName: data.fullName,
        email: data.email || undefined,
        address: data.address || undefined,
        role: 'customer'
      });

      toast({
        title: "تم إنشاء الحساب بنجاح!",
        description: "سيتم توجيهك لصفحة تسجيل الدخول",
      });

      // توجيه المستخدم لصفحة تسجيل الدخول بعد النجاح
      setTimeout(() => {
        setLocation('/login');
      }, 1500);
    } catch (error: any) {
      toast({
        title: "خطأ في إنشاء الحساب",
        description: error.message || "حدث خطأ أثناء إنشاء الحساب",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-100 via-white to-slate-50 flex items-center justify-center p-4" dir="rtl">
      <div className="w-full max-w-md">
        {/* تاجر Logo Header */}
        <div className="text-center mb-8">
          <div className="flex flex-col items-center mb-6">
            {/* Zone Logo */}
            <div className="w-24 h-24 bg-gradient-to-br from-purple-600 to-purple-800 rounded-3xl flex items-center justify-center mb-4 shadow-2xl border-4 border-purple-200">
              <ShoppingBag className="w-12 h-12 text-white" />
            </div>
            <h1 className="text-lg text-slate-600 font-medium">انضم إلى تاجر</h1>
            <p className="text-slate-500 text-sm mt-1">إنشاء حساب جديد للتسوق والطلب</p>
          </div>
        </div>

        {/* Registration Form */}
        <Card className="shadow-xl border-0">
          <CardHeader className="text-center pb-4">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <UserPlus className="w-8 h-8 text-green-600" />
            </div>
            <CardTitle className="text-xl text-slate-900">إنشاء حساب جديد</CardTitle>
          </CardHeader>
          <CardContent>
            {/* رسالة التحذير */}
            {showWarning && (
              <div className="mb-6 p-4 bg-amber-50 border border-amber-200 rounded-lg relative">
                <button
                  onClick={() => setShowWarning(false)}
                  className="absolute top-2 left-2 p-1 hover:bg-amber-100 rounded-full transition-colors"
                  aria-label="إغلاق التحذير"
                >
                  <X className="w-4 h-4 text-amber-600" />
                </button>
                <div className="flex items-start gap-3 pr-6">
                  <AlertTriangle className="w-5 h-5 text-amber-600 mt-0.5 flex-shrink-0" />
                  <div className="text-right">
                    <p className="text-amber-800 text-sm font-medium mb-1">
                      تحذير مهم
                    </p>
                    <p className="text-amber-700 text-sm leading-relaxed">
                      رقم الهاتف والبريد الإلكتروني مطلوبان في حال نسيت كلمه المرور وعدم تذكرهما لن تستطيع ارجاع حسابك من فضلك حافظ عليهما
                    </p>
                    <p className="text-amber-700 text-sm mt-2 font-medium">
                      شكرا لك
                    </p>
                  </div>
                </div>
              </div>
            )}

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="fullName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>الاسم الكامل</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="أدخل اسمك الكامل"
                          {...field}
                          className="h-11"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />



                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>رقم الهاتف</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="رقم الهاتف"
                          {...field}
                          className="h-11"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>البريد الإلكتروني</FormLabel>
                      <FormControl>
                        <Input 
                          type="email"
                          placeholder="البريد الإلكتروني"
                          {...field}
                          className="h-11"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="address"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>العنوان (اختياري)</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="العنوان"
                          {...field}
                          className="h-11"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>كلمة المرور</FormLabel>
                      <FormControl>
                        <Input 
                          type="password"
                          placeholder="كلمة المرور"
                          {...field}
                          className="h-11"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="confirmPassword"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>تأكيد كلمة المرور</FormLabel>
                      <FormControl>
                        <Input 
                          type="password"
                          placeholder="تأكيد كلمة المرور"
                          {...field}
                          className="h-11"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* مكون الشروط والأحكام */}
                <FormField
                  control={form.control}
                  name="agreeToTerms"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <TermsAndConditions
                          checked={field.value}
                          onCheckedChange={(checked) => {
                            field.onChange(checked);
                            setAgreeToTerms(checked);
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button 
                  type="submit" 
                  disabled={!agreeToTerms || isLoading}
                  className="w-full h-11 bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 disabled:opacity-50"
                >
                  {isLoading ? "جاري إنشاء الحساب..." : "إنشاء حساب"}
                  <ArrowRight className="w-4 h-4 mr-2" />
                </Button>
              </form>
            </Form>

            <div className="mt-6 text-center">
              <p className="text-sm text-slate-600">
                لديك حساب بالفعل؟{' '}
                <Link href="/login">
                  <span className="text-blue-600 hover:text-blue-700 font-medium cursor-pointer">
                    تسجيل الدخول
                  </span>
                </Link>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};