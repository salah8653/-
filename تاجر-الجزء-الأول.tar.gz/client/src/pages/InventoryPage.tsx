import { InventoryManager } from '@/components/InventoryManager';

export const InventoryPage = () => {
  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <h1 className="text-3xl font-bold text-slate-900 mb-2">إدارة المخزون</h1>
        <p className="text-slate-600">مراقبة مستويات المخزون وإدارة الكميات</p>
      </div>

      <InventoryManager />
    </div>
  );
};
