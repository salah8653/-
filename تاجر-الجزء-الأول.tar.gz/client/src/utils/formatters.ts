// دوال تنسيق الأرقام والعملة
export const formatCurrency = (amount: number | string): string => {
  const numAmount = typeof amount === 'string' ? parseFloat(amount) : amount;
  return new Intl.NumberFormat('en-US').format(numAmount || 0);
};

export const formatNumber = (num: number | string): string => {
  const numValue = typeof num === 'string' ? parseFloat(num) : num;
  return new Intl.NumberFormat('en-US').format(numValue || 0);
};

// دالة لتحويل حالة الطلبات
export const getOrderStatus = (status: string): string => {
  const statusMap: { [key: string]: string } = {
    'pending': 'في الانتظار',
    'confirmed': 'مؤكد',
    'processing': 'قيد التحضير',
    'shipped': 'تم الشحن',
    'delivered': 'تم التسليم',
    'completed': 'مكتمل',
    'cancelled': 'ملغي',
    'undefined': 'مكتمل',
    '': 'مكتمل'
  };
  
  return statusMap[status] || 'مكتمل';
};

// دالة لتحديد لون حالة الطلب
export const getOrderStatusColor = (status: string): string => {
  const colorMap: { [key: string]: string } = {
    'pending': 'bg-yellow-100 text-yellow-800',
    'confirmed': 'bg-blue-100 text-blue-800',
    'processing': 'bg-orange-100 text-orange-800',
    'shipped': 'bg-purple-100 text-purple-800',
    'delivered': 'bg-green-100 text-green-800',
    'completed': 'bg-green-100 text-green-800',
    'cancelled': 'bg-red-100 text-red-800',
    'undefined': 'bg-green-100 text-green-800',
    '': 'bg-green-100 text-green-800'
  };
  
  return colorMap[status] || 'bg-green-100 text-green-800';
};