import { useAuth } from './AuthProvider';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Chrome } from 'lucide-react';

export function LoginPage() {
  const { signInWithGoogle, loading } = useAuth();

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      <Card className="w-full max-w-md mx-4">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold">مرحباً بك</CardTitle>
          <CardDescription>
            سجل دخولك للوصول إلى منصة إدارة المتجر
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Button
            onClick={signInWithGoogle}
            disabled={loading}
            className="w-full"
            size="lg"
          >
            <Chrome className="mr-2 h-5 w-5" />
            تسجيل الدخول بـ Google
          </Button>
          
          <div className="text-center text-sm text-muted-foreground">
            بالتسجيل أنت توافق على شروط الاستخدام وسياسة الخصوصية
          </div>
        </CardContent>
      </Card>
    </div>
  );
}